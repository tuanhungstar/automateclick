import sys
import os
import inspect
import importlib
import time
import csv
import io
from datetime import datetime
import json
import base64
import re
import ast
import urllib.request
import zipfile
import shutil
import subprocess
import webbrowser # <<< ADD THIS LINE
from PIL import ImageGrab
import PIL.Image
from PIL.ImageQt import ImageQt
from PyQt6.QtGui import QPixmap, QColor, QFont, QPainter, QPen, QIcon, QPolygonF, QCursor, QAction
from PyQt6.QtCore import Qt, QThread, pyqtSignal, QVariant, QObject, QSize, QPoint, QRegularExpression,QRect,QDateTime, QTimer, QPointF, QTime
from PyQt6 import QtWidgets, QtGui, QtCore
from typing import Optional, List, Dict, Any, Tuple, Union
import pandas as pd
from openpyxl.worksheet.worksheet import Worksheet as OpenpyxlWorksheet
from PyQt6.QtWidgets import QTableView
from PyQt6.QtGui import QStandardItemModel, QStandardItem
 #hung comment
# Ensure my_lib is in the Python path
script_dir = os.path.dirname(os.path.abspath(__file__))
my_lib_dir = os.path.join(script_dir, "my_lib")
if my_lib_dir not in sys.path:
    sys.path.insert(0, my_lib_dir)

from PyQt6.QtWidgets import (
    QApplication, QWidget, QVBoxLayout, QHBoxLayout, QMainWindow,
    QComboBox, QListWidget, QLabel, QPushButton, QListWidgetItem,
    QMessageBox, QProgressBar, QFileDialog, QDialog,
    QLineEdit, QVBoxLayout as QVBoxLayoutDialog, QFormLayout,
    QDialogButtonBox,
    QRadioButton, QGroupBox, QCheckBox, QTextEdit,
    QTreeWidget, QTreeWidgetItem, QGridLayout, QHeaderView, QSplitter, QInputDialog,
    QStackedLayout, QBoxLayout,QMenu,QPlainTextEdit,QSizePolicy, QTextBrowser,QDateTimeEdit,QTreeWidgetItemIterator,
    QScrollArea, QTabWidget, QFrame, QMenu, QTimeEdit
)

from PyQt6.QtGui import QIntValidator
from PyQt6.QtGui import QSyntaxHighlighter, QTextCharFormat, QColor, QFont, QPainter, QPen, QTextCursor,QTextFormat,QKeyEvent,QTextDocument

# Use the actual libraries from the my_lib folder
from my_lib.shared_context import ExecutionContext, GuiCommunicator
from my_lib.BOT_take_image import MainWindow as BotTakeImageWindow
from my_lib.Emailer import Emailer


class SecondWindow(QtWidgets.QDialog): # Or QtWidgets.QMainWindow if you prefer a full window

    screenshot_saved = pyqtSignal(str)

    def __init__(self, image: str, base_dir: str, parent: Optional[QWidget] = None):
        super().__init__(parent)
        self.setWindowTitle("Take and Manage Screenshots")

        # Use the 'base_dir' argument directly
        icon_path = os.path.join(base_dir, "app_icon.png")
        if os.path.exists(icon_path):
            self.setWindowIcon(QIcon(icon_path))
                
        self.setMinimumSize(700, 300) # Set a minimum size to match the original GUI

        self.bot_take_image_ui = BotTakeImageWindow(image)

        self.bot_take_image_ui.screenshotSaved.connect(self._handle_screenshot_saved)

        self.bot_take_image_ui.exit_BOT_butt.clicked.connect(self.accept) # Accept the dialog when exit is clicked

        layout = QVBoxLayout(self)
        layout.addWidget(self.bot_take_image_ui.centralwidget)
        self.setLayout(layout)

        self.finished.connect(self._on_dialog_closed)

    def _handle_screenshot_saved(self, filename: str):
        """Pass through the signal from the embedded UI."""
        self.screenshot_saved.emit(filename)

    def _on_dialog_closed(self, result: int):
        """Handles dialog closure, including via 'X' button."""

        if result == QDialog.DialogCode.Rejected: # Closed via 'X' or Escape
            self.screenshot_saved.emit("") # No specific file was saved/selected

# --- ExecutionStepCard ---
class ExecutionStepCard(QWidget):
    edit_requested = pyqtSignal(dict)
    delete_requested = pyqtSignal(dict)
    move_up_requested = pyqtSignal(dict)
    move_down_requested = pyqtSignal(dict)
    save_as_template_requested = pyqtSignal(dict)
    execute_this_requested = pyqtSignal(dict)
    # NEW SIGNALS FOR DRAG AND DROP
    step_drag_started = pyqtSignal(dict, int)
    step_reorder_requested = pyqtSignal(int, int)

    def __init__(self, step_data: Dict[str, Any], step_number: int, parent: Optional[QWidget] = None):
        super().__init__(parent)
        self.step_data = step_data
        self.step_number = step_number
        
        # Drag and drop attributes
        self.dragging = False
        self.drag_start_position = QPoint()
        self.original_index = step_data.get("original_listbox_row_index", -1)
        self.drag_widget = None  # For visual feedback during drag
        
        self.init_ui()
        
        # Enable drag and drop
        self.setAcceptDrops(True)

    def init_ui(self):
        main_layout = QVBoxLayout(self)
        main_layout.setContentsMargins(8, 8, 8, 8)
        main_layout.setSpacing(5)
        self.setObjectName("ExecutionStepCard")
        self.set_status("#dcdcdc")

        top_row_layout = QHBoxLayout()
        step_label_text = self._get_formatted_title()
        self.step_label = QLabel(step_label_text)
        
        step_type = self.step_data.get("type")
        if step_type == 'group_start':
            self.step_label.setStyleSheet("font-weight: bold; background-color: #D6EAF8; padding: 4px; border-radius: 3px;")
        else:
            self.step_label.setStyleSheet("font-weight: bold; background-color: #EAEAEA; padding: 4px; border-radius: 3px;")

        top_row_layout.addWidget(self.step_label)
        top_row_layout.addStretch()

        self.up_button = QPushButton("↑")
        self.down_button = QPushButton("↓")
        self.edit_button = QPushButton("Edit")
        self.delete_button = QPushButton("Delete")
        self.save_template_button = QPushButton("Save Template")
        self.execute_this_button = QPushButton("Execute This")

        card_button_style = """
            QPushButton {
                background-color: #f0f0f0;
                color: #333333;
                border: 1px solid #c0c0c0;
                border-radius: 4px;
                padding: 4px 8px;
                font-size: 12px;
            }
            QPushButton:hover {
                background-color: #e0e0e0;
                border-color: #a0a0a0;
            }
            QPushButton:pressed {
                background-color: #d0d0d0;
            }
        """
        
        for button in [self.up_button, self.down_button, self.edit_button, self.delete_button, self.save_template_button, self.execute_this_button]:
            button.setStyleSheet(card_button_style)

        button_font = self.up_button.font()
        button_font.setBold(True)
        self.up_button.setFont(button_font)
        self.down_button.setFont(button_font)

        self.up_button.setFixedSize(25, 25)
        self.down_button.setFixedSize(25, 25)
        self.edit_button.setFixedSize(60, 25)
        self.delete_button.setFixedSize(60, 25)
        self.save_template_button.setFixedSize(100, 25)
        self.execute_this_button.setFixedSize(100, 25)

        self.up_button.clicked.connect(lambda: self.move_up_requested.emit(self.step_data))
        self.down_button.clicked.connect(lambda: self.move_down_requested.emit(self.step_data))
        self.edit_button.clicked.connect(lambda: self.edit_requested.emit(self.step_data))
        self.delete_button.clicked.connect(lambda: self.delete_requested.emit(self.step_data))
        self.save_template_button.clicked.connect(lambda: self.save_as_template_requested.emit(self.step_data))
        self.execute_this_button.clicked.connect(lambda: self.execute_this_requested.emit(self.step_data))

        if self.step_data.get("type") not in ["loop_start", "IF_START", "group_start"]:
            self.save_template_button.hide()
        
        if self.step_data.get("type") in ["loop_end", "ELSE", "IF_END", "group_end"]:
            self.up_button.hide()
            self.down_button.hide()
            self.edit_button.hide()
            self.delete_button.hide()
            self.execute_this_button.hide()

        top_row_layout.addWidget(self.up_button)
        top_row_layout.addWidget(self.down_button)
        top_row_layout.addWidget(self.edit_button)
        top_row_layout.addWidget(self.delete_button)
        top_row_layout.addWidget(self.save_template_button)
        top_row_layout.addWidget(self.execute_this_button)

        main_layout.addLayout(top_row_layout)

        self._original_method_text = self._get_formatted_method_name()
        if self._original_method_text:
            self.method_label = QLabel(self._original_method_text)
            self.method_label.setStyleSheet("font-size: 10pt; padding: 5px; background-color: white; border: 1px solid #E0E0E0; border-radius: 3px;")
            self.method_label.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
            main_layout.addWidget(self.method_label)
        else:
            self.method_label = None

        if self.step_data.get("type") == "step":
            parameters_config = self.step_data.get("parameters_config", {})
            if parameters_config:
                params_group = QGroupBox("Parameters")
                params_layout = QFormLayout()
                params_layout.setContentsMargins(8, 5, 8, 5)
                for param_name, config in parameters_config.items():
                    if param_name == "original_listbox_row_index": continue
                    value_str = ""
                    if config.get('type') == 'hardcoded': value_str = repr(config['value'])
                    elif config.get('type') == 'hardcoded_file':
                        full_path_value = config['value']
                        base_name = os.path.basename(full_path_value)
                        value_str = f"File: '{base_name}'"
                    elif config.get('type') == 'variable': value_str = f"Variable: @{config['value']}"
                    param_label = QLabel(f"{param_name}:")
                    value_label = QLineEdit(value_str)
                    value_label.setReadOnly(True)
                    value_label.setStyleSheet("background-color: #FFFFFF; font-size: 9pt; padding: 2px; border: 1px solid #D3D3D3;")
                    params_layout.addRow(param_label, value_label)
                params_group.setLayout(params_layout)
                main_layout.addWidget(params_group)

    # FIXED DRAG AND DROP METHODS
# In main_app.py, inside the WorkflowCanvas class

# In main_app.py, inside the WorkflowCanvas class

    def mousePressEvent(self, event: QtGui.QMouseEvent):
        if event.button() == Qt.MouseButton.LeftButton:
            clicked_pos = event.pos() - self.canvas_offset
            
            # --- CORRECTED LOGIC STARTS HERE ---
            # 1. Check for icon click first
            for hotspot_rect, group_id in self.icon_hotspots:
                if hotspot_rect.contains(clicked_pos):
                    
                    # 2. Toggle the group's expansion state in the main window
                    current_state = self.main_window.group_expansion_states.get(group_id, True)
                    self.main_window.group_expansion_states[group_id] = not current_state
                    
                    # 3. Find the data for the group_start step that was toggled
                    group_start_data_to_focus = None
                    for step_data in self.main_window.added_steps_data:
                        if step_data.get("type") == "group_start" and step_data.get("group_id") == group_id:
                            group_start_data_to_focus = step_data
                            break
                    
                    # 4. Trigger a full, targeted rebuild of the UI
                    # This will automatically handle redrawing the canvas AND centering on the specified item.
                    if group_start_data_to_focus:
                        self.main_window._rebuild_execution_tree(item_to_focus_data=group_start_data_to_focus)
                    else:
                        # Fallback to a general redraw if the specific item isn't found
                        self.main_window._rebuild_execution_tree()
                    
                    # 5. Save the new layout state to the temp file
                    self.main_window._save_workflow_to_temp_file()
                    
                    return # Stop further processing
            # --- CORRECTED LOGIC ENDS HERE ---

            # The rest of the method (node dragging and canvas panning) remains unchanged
            node_clicked = False
            for i in range(len(self.nodes) - 1, -1, -1):
                rect, _, _, _ = self.nodes[i]
                if rect.contains(clicked_pos):
                    self.dragging_node_index = i
                    self.drag_offset = clicked_pos - rect.topLeft()
                    self.setCursor(Qt.CursorShape.ClosedHandCursor)
                    # ... (rest of drag logic is the same)
                    node = self.nodes.pop(i)
                    self.nodes.append(node)
                    self._remap_edges_for_drag(i, len(self.nodes) - 1)
                    self.dragging_node_index = len(self.nodes) - 1
                    self.update()
                    node_clicked = True
                    break
            
            if not node_clicked:
                self.dragging_canvas = True
                self.last_pan_point = event.pos()
                self.setCursor(Qt.CursorShape.ClosedHandCursor)
        
        elif event.button() == Qt.MouseButton.RightButton:
            clicked_pos_local = event.pos() - self.canvas_offset
            clicked_node_data = None
            for rect, _, _, step_data in self.nodes:
                if rect.contains(clicked_pos_local):
                    clicked_node_data = step_data
                    break
            self._show_context_menu(event.pos(), clicked_node_data)
            
        super().mousePressEvent(event)
    def mouseMoveEvent(self, event: QtGui.QMoveEvent):
        if not (event.buttons() & Qt.MouseButton.LeftButton):
            return
        
        if not self.dragging:
            # Check if we've moved far enough to start dragging
            if ((event.pos() - self.drag_start_position).manhattanLength() >= 
                QApplication.startDragDistance()):
                self.start_drag()
        super().mouseMoveEvent(event)

    def start_drag(self):
        """Start the drag operation with proper Qt drag and drop."""
        self.dragging = True
        
        # Create drag object
        drag = QtGui.QDrag(self)
        mime_data = QtCore.QMimeData()
        
        # Store the source index in mime data
        mime_data.setText(str(self.original_index))
        drag.setMimeData(mime_data)
        
        # Create drag pixmap for visual feedback
        pixmap = self.grab()
        drag.setPixmap(pixmap)
        drag.setHotSpot(self.drag_start_position)
        
        # Visual feedback on source
        self.setStyleSheet("""
            #ExecutionStepCard { 
                background-color: #E3F2FD; 
                border: 3px dashed #2196F3; 
                border-radius: 6px; 
                opacity: 0.7;
            }
        """)
        
        # Emit signal
        self.step_drag_started.emit(self.step_data, self.original_index)
        
        # Execute drag
        drop_action = drag.exec(Qt.DropAction.MoveAction)
        
        # Reset visual feedback
        self.set_status("#dcdcdc")
        self.dragging = False

    def mouseReleaseEvent(self, event: QtGui.QMouseEvent):
        if self.dragging:
            self.dragging = False
            self.set_status("#dcdcdc")
        super().mouseReleaseEvent(event)

    # Drag and drop event handlers
    def dragEnterEvent(self, event: QtGui.QDragEnterEvent):
        if event.mimeData().hasText():
            event.acceptProposedAction()
            # Visual feedback for drop target
            self.setStyleSheet("""
                #ExecutionStepCard { 
                    background-color: #FFF3E0; 
                    border: 2px solid #FF9800; 
                    border-radius: 6px; 
                }
            """)

    def dragMoveEvent(self, event: QtGui.QDragMoveEvent):
        if event.mimeData().hasText():
            event.acceptProposedAction()

    def dragLeaveEvent(self, event: QtGui.QDragLeaveEvent):
        # Reset visual feedback
        self.set_status("#dcdcdc")

    def dropEvent(self, event: QtGui.QDropEvent):
        # Reset visual feedback
        self.set_status("#dcdcdc")
        
        if event.mimeData().hasText():
            source_index = int(event.mimeData().text())
            target_index = self.original_index
            
            # Determine if dropping above or below based on position
            drop_pos = event.position() if hasattr(event, 'position') else event.pos()
            if drop_pos.y() < self.height() / 2:
                # Drop above (before)
                target_index = self.original_index
            else:
                # Drop below (after)
                target_index = self.original_index + 1
            
            if source_index != target_index:
                self.step_reorder_requested.emit(source_index, target_index)
            
            event.acceptProposedAction()

    # Keep all existing methods (unchanged)
    def _get_formatted_title(self) -> str:
        step_type = self.step_data.get("type", "Unknown")
        if step_type == "group_start":
            return f"Group: {self.step_data.get('group_name', 'Unnamed')}"
        
        if step_type == "step":
            method_name = self.step_data.get("method_name", "UnknownMethod")
            return f"Step {self.step_number}: {method_name}"
            
        step_type_display = step_type.replace("_", " ").title()
        return f"Step {self.step_number}: {step_type_display}"

    def _get_formatted_method_name(self) -> str:
        step_type = self.step_data["type"]
        if step_type == "step":
            class_name, method_name = self.step_data["class_name"], self.step_data["method_name"]
            assign_to_variable_name = self.step_data["assign_to_variable_name"]
            display_text = f"{class_name}.{method_name}"
            if assign_to_variable_name:
                display_text = f"@{assign_to_variable_name} = " + display_text
            return display_text
        elif step_type == "loop_start":
            loop_config = self.step_data["loop_config"]
            custom_loop_name = loop_config.get("loop_name")
            name_display = f"'{custom_loop_name}'" if custom_loop_name else f"(ID: {self.step_data['loop_id']})"
            count_config = loop_config["iteration_count_config"]
            loop_info = f"@{count_config['value']}" if count_config["type"] == "variable" else f"{count_config['value']} times"
            assign_var = loop_config.get("assign_iteration_to_variable")
            if assign_var: loop_info += f", assign iter to @{assign_var}"
            return f"{name_display} - {loop_info}"
        elif step_type in ["loop_end", "ELSE", "IF_END", "group_start", "group_end"]:
            return ""
        elif step_type == "IF_START":
            condition_config = self.step_data["condition_config"]
            block_name = condition_config.get("block_name")
            name_display = f"'{block_name}'" if block_name else f"(ID: {self.step_data['if_id']})"
            left_op, right_op, op = condition_config["condition"]["left_operand"], condition_config["condition"]["right_operand"], condition_config["condition"]["operator"]
            left_str = f"@{left_op['value']}" if left_op['type'] == 'variable' else repr(left_op['value'])
            right_str = f"@{right_op['value']}" if right_op['type'] == 'variable' else repr(right_op['value'])
            return f"{name_display} ({left_str} {op} {right_str})"
        return ""
        

    def set_status(self, border_color: str, is_running: bool = False, is_error: bool = False):
        if is_running:
            border_color = "#FFD700"
            background_color = "#FFFBF0"
            border_thickness = 4
        elif is_error:
            border_color = "#DC3545"
            background_color = "#FFF5F5"
            border_thickness = 4
        elif border_color == "darkGreen" or border_color == "#28a745":
            border_color = "#28a745"
            background_color = "#F8FFF8"
            border_thickness = 2
        else:
            background_color = "#F8F8F8"
            border_thickness = 2
        
        self.setStyleSheet(f"""
            #ExecutionStepCard {{ 
                background-color: {background_color}; 
                border: {border_thickness}px solid {border_color}; 
                border-radius: 6px; 
            }}
        """)
# In main_app.py, inside the ExecutionStepCard class
# ADD this method as well:

    def clear_result(self):
        if self.method_label:
            self.method_label.setText(self._original_method_text)
            self.method_label.setStyleSheet("font-size: 10pt; padding: 5px; background-color: white; border: 1px solid #E0E0E0; border-radius: 3px;")
    def set_result_text(self, result_message: str):
        #print(f"DEBUG: set_result_text called with message: '{result_message}'")
        #print(f"DEBUG: method_label exists: {self.method_label is not None}")
        if not self.method_label:
            #print("DEBUG: method_label is None!")  # ADD THIS
            return

        if len(result_message) > 300:
             result_message = result_message[:297] + "..."

        assign_to_var = self.step_data.get("assign_to_variable_name")
        
        if self.step_data.get("type") == "step" and assign_to_var and "Result: " in result_message:
            try:
                if " (Assigned to @" in result_message:
                    result_val_str = result_message.split("Result: ")[1].split(" (Assigned to @")[0]
                elif " (Assigned to" in result_message:
                    result_val_str = result_message.split("Result: ")[1].split(" (Assigned to")[0]
                else:
                    result_val_str = result_message.split("Result: ")[1]
            except IndexError:
                result_val_str = "Error parsing result"
            
            display_text = f"@{assign_to_var} = {result_val_str}"
            self.method_label.setText(display_text)
            self.method_label.setStyleSheet("font-size: 10pt; font-style: italic; color: #155724; padding: 5px; background-color: #d4edda; border: 1px solid #c3e6cb; border-radius: 3px;")
        
        else:
            self.method_label.setText(f"✓ {result_message}")
            self.method_label.setStyleSheet("font-size: 10pt; font-style: italic; color: #155724; padding: 5px; background-color: #d4edda; border: 1px solid #c3e6cb; border-radius: 3px;")

    def clear_result(self):
        if self.method_label:
            self.method_label.setText(self._original_method_text)
            self.method_label.setStyleSheet("font-size: 10pt; padding: 5px; background-color: white; border: 1px solid #E0E0E0; border-radius: 3px;")
class LoopConfigDialog(QDialog):
    def __init__(self, global_variables: Dict[str, Any], parent: Optional[QWidget] = None, initial_config: Optional[Dict[str, Any]] = None):
        super().__init__(parent)
        self.setWindowTitle("Configure Loop Group")
        self.setMinimumWidth(300)
        self.global_variables = global_variables
        main_layout, form_layout = QVBoxLayout(), QFormLayout()
        self.loop_name_editor = QLineEdit()
        self.loop_name_editor.setPlaceholderText("Optional: Enter a name for this loop")
        form_layout.addRow("Loop Name:", self.loop_name_editor)
        self.repeat_count_editor = QLineEdit("1")
        self.repeat_count_editor.setValidator(QIntValidator(1, 999999, self))
        form_layout.addRow("Loop Count:", self.repeat_count_editor)
        self.use_var_checkbox = QCheckBox("Use Global Variable for Loop Count")
        self.use_var_checkbox.stateChanged.connect(self._toggle_count_var_input)
        form_layout.addRow("", self.use_var_checkbox)
        self.global_var_combo_count = QComboBox()
        self.global_var_combo_count.addItem("-- Select Global Variable --")
        self.global_var_combo_count.addItems(sorted(global_variables.keys()))
        self.global_var_combo_count.setEnabled(False)
        form_layout.addRow("Variable for Loop Count:", self.global_var_combo_count)
        self.assign_iter_checkbox = QCheckBox("Assign Current Iteration to Global Variable")
        self.assign_iter_checkbox.stateChanged.connect(self._toggle_assign_iter_input)
        form_layout.addRow("", self.assign_iter_checkbox)
        self.global_var_combo_assign_iter = QComboBox()
        self.global_var_combo_assign_iter.addItem("-- Select Global Variable --")
        self.global_var_combo_assign_iter.addItems(sorted(global_variables.keys()))
        self.global_var_combo_assign_iter.setEnabled(False)
        form_layout.addRow("Assign Iteration To:", self.global_var_combo_assign_iter)
        self.new_var_iter_editor = QLineEdit()
        self.new_var_iter_editor.setPlaceholderText("Enter new variable name")
        self.new_var_iter_editor.setEnabled(False)
        form_layout.addRow("New Var Name for Iter:", self.new_var_iter_editor)
        main_layout.addLayout(form_layout)
        button_box = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        button_box.accepted.connect(self.accept)
        button_box.rejected.connect(self.reject)
        main_layout.addWidget(button_box)
        self.setLayout(main_layout)
        if initial_config: self.set_config(initial_config)
        else: self._toggle_count_var_input(); self._toggle_assign_iter_input()

    def _toggle_count_var_input(self) -> None:
        is_using_var = self.use_var_checkbox.isChecked()
        self.repeat_count_editor.setEnabled(not is_using_var)
        self.repeat_count_editor.setVisible(not is_using_var)
        self.global_var_combo_count.setEnabled(is_using_var)
        self.global_var_combo_count.setVisible(is_using_var)
        if is_using_var: self.repeat_count_editor.clear()
        else: self.global_var_combo_count.setCurrentIndex(0)

    def _toggle_assign_iter_input(self) -> None:
        is_assigning_iter = self.assign_iter_checkbox.isChecked()
        self.global_var_combo_assign_iter.setEnabled(is_assigning_iter)
        self.global_var_combo_assign_iter.setVisible(is_assigning_iter)
        self.new_var_iter_editor.setEnabled(is_assigning_iter and self.global_var_combo_assign_iter.currentIndex() == 0)
        self.new_var_iter_editor.setVisible(is_assigning_iter)
        self.global_var_combo_assign_iter.currentIndexChanged.connect(self._update_new_var_iter_editor_state)
        self._update_new_var_iter_editor_state()

    def _update_new_var_iter_editor_state(self) -> None:
        is_assigning_iter = self.assign_iter_checkbox.isChecked()
        is_selecting_new = self.global_var_combo_assign_iter.currentIndex() == 0
        self.new_var_iter_editor.setEnabled(is_assigning_iter and is_selecting_new)
        if not (is_assigning_iter and is_selecting_new): self.new_var_iter_editor.clear()

    def get_config(self) -> Optional[Dict[str, Any]]:
        loop_name = self.loop_name_editor.text().strip()
        count_config = {}
        if self.use_var_checkbox.isChecked():
            global_var_name = self.global_var_combo_count.currentText()
            if global_var_name == "-- Select Global Variable --": QMessageBox.warning(self, "Input Error", "Please select a global variable for loop count."); return None
            count_config = {"type": "variable", "value": global_var_name}
        else:
            try:
                repeat_count_str = self.repeat_count_editor.text()
                if not repeat_count_str: QMessageBox.warning(self, "Input Error", "Please enter a value for loop count."); return None
                repeat_count = int(repeat_count_str)
                if repeat_count < 1: raise ValueError("Loop count must be at least 1.")
            except ValueError: QMessageBox.warning(self, "Input Error", "Please enter a valid positive integer for loop count."); return None
            count_config = {"type": "hardcoded", "value": repeat_count}
        assign_iter_var_name: Optional[str] = None
        if self.assign_iter_checkbox.isChecked():
            if self.global_var_combo_assign_iter.currentIndex() == 0:
                new_var_name = self.new_var_iter_editor.text().strip()
                if not new_var_name: QMessageBox.warning(self, "Input Error", "Please enter a new variable name to assign the iteration count to."); return None
                assign_iter_var_name = new_var_name
            else: assign_iter_var_name = self.global_var_combo_assign_iter.currentText()
            if count_config["type"] == "variable" and count_config["value"] == assign_iter_var_name: QMessageBox.warning(self, "Input Error", "The variable for Loop Count cannot be the same as the variable for assigning Current Iteration."); return None
        return {"loop_name": loop_name if loop_name else None, "iteration_count_config": count_config, "assign_iteration_to_variable": assign_iter_var_name}

    def set_config(self, config: Dict[str, Any]) -> None:
        self.loop_name_editor.setText(config.get("loop_name", "") or "")
        count_config = config.get("iteration_count_config", {})
        if count_config.get("type") == "variable":
            self.use_var_checkbox.setChecked(True)
            idx = self.global_var_combo_count.findText(count_config["value"])
            if idx != -1: self.global_var_combo_count.setCurrentIndex(idx)
        else:
            self.use_var_checkbox.setChecked(False)
            self.repeat_count_editor.setText(str(count_config.get("value", 1)))
        self._toggle_count_var_input()
        assign_iter_var_name = config.get("assign_iteration_to_variable")
        if assign_iter_var_name:
            self.assign_iter_checkbox.setChecked(True)
            idx = self.global_var_combo_assign_iter.findText(assign_iter_var_name)
            if idx != -1: self.global_var_combo_assign_iter.setCurrentIndex(idx); self.new_var_iter_editor.clear()
            else: self.global_var_combo_assign_iter.setCurrentIndex(0); self.new_var_iter_editor.setText(assign_iter_var_name)
        else: self.assign_iter_checkbox.setChecked(False)
        self._toggle_assign_iter_input()

class ConditionalConfigDialog(QDialog):
    def __init__(self, global_variables: Dict[str, Any], parent: Optional[QWidget] = None, initial_config: Optional[Dict[str, Any]] = None):
        super().__init__(parent)
        self.setWindowTitle("Configure Conditional Block (IF-ELSE)")
        self.setMinimumWidth(400)
        self.global_variables = global_variables
        main_layout, form_layout = QVBoxLayout(), QFormLayout()
        self.block_name_editor = QLineEdit()
        self.block_name_editor.setPlaceholderText("Optional: Enter a name for this conditional block")
        form_layout.addRow("Block Name:", self.block_name_editor)
        condition_group, condition_layout = QGroupBox("Condition"), QGridLayout()
        self.left_operand_source_combo = QComboBox(); self.left_operand_source_combo.addItems(["Hardcoded Value", "Global Variable"])
        self.left_operand_editor = QLineEdit()
        self.left_operand_var_combo = QComboBox(); self.left_operand_var_combo.addItem("-- Select Variable --"); self.left_operand_var_combo.addItems(sorted(global_variables.keys()))
        self.left_operand_source_combo.currentIndexChanged.connect(self._toggle_left_operand_input)
        condition_layout.addWidget(QLabel("Left Operand:"), 0, 0); condition_layout.addWidget(self.left_operand_source_combo, 0, 1); condition_layout.addWidget(self.left_operand_editor, 0, 2); condition_layout.addWidget(self.left_operand_var_combo, 0, 2)
        self.operator_combo = QComboBox(); self.operator_combo.addItems(['==', '!=', '<', '>', '<=', '>=', 'in', 'not in', 'is', 'is not'])
        condition_layout.addWidget(QLabel("Operator:"), 1, 0); condition_layout.addWidget(self.operator_combo, 1, 1, 1, 2)
        self.right_operand_source_combo = QComboBox(); self.right_operand_source_combo.addItems(["Hardcoded Value", "Global Variable"])
        self.right_operand_editor = QLineEdit()
        self.right_operand_var_combo = QComboBox(); self.right_operand_var_combo.addItem("-- Select Variable --"); self.right_operand_var_combo.addItems(sorted(global_variables.keys()))
        self.right_operand_source_combo.currentIndexChanged.connect(self._toggle_right_operand_input)
        condition_layout.addWidget(QLabel("Right Operand:"), 2, 0); condition_layout.addWidget(self.right_operand_source_combo, 2, 1); condition_layout.addWidget(self.right_operand_editor, 2, 2); condition_layout.addWidget(self.right_operand_var_combo, 2, 2)
        condition_group.setLayout(condition_layout)
        main_layout.addWidget(condition_group)
        button_box = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        button_box.accepted.connect(self.accept); button_box.rejected.connect(self.reject)
        main_layout.addLayout(form_layout); main_layout.addWidget(button_box)
        self.setLayout(main_layout)
        self._toggle_left_operand_input(); self._toggle_right_operand_input()
        if initial_config: self.set_config(initial_config)

    def _toggle_left_operand_input(self) -> None:
        is_using_var = (self.left_operand_source_combo.currentIndex() == 1)
        self.left_operand_editor.setVisible(not is_using_var)
        self.left_operand_var_combo.setVisible(is_using_var)
        if not is_using_var: self.left_operand_var_combo.setCurrentIndex(0)
        else: self.left_operand_editor.clear()

    def _toggle_right_operand_input(self) -> None:
        is_using_var = (self.right_operand_source_combo.currentIndex() == 1)
        self.right_operand_editor.setVisible(not is_using_var)
        self.right_operand_var_combo.setVisible(is_using_var)
        if not is_using_var: self.right_operand_var_combo.setCurrentIndex(0)
        else: self.right_operand_editor.clear()

    def _parse_value_from_string(self, value_str: str) -> Any:
        try:
            if value_str.lower() == 'none': return None
            if value_str.lower() == 'true': return True
            if value_str.lower() == 'false': return False
            if value_str.isdigit(): return int(value_str)
            if value_str.replace('.', '', 1).isdigit(): return float(value_str)
            if (value_str.startswith('{') and value_str.endswith('}')) or (value_str.startswith('[') and value_str.endswith(']')): return json.loads(value_str)
            return value_str
        except (ValueError, json.JSONDecodeError): return value_str

    def get_config(self) -> Optional[Dict[str, Any]]:
        block_name = self.block_name_editor.text().strip()
        left_op_config: Dict[str, Any] = {}
        if self.left_operand_source_combo.currentIndex() == 1:
            var_name = self.left_operand_var_combo.currentText()
            if var_name == "-- Select Variable --": QMessageBox.warning(self, "Input Error", "Please select a global variable for the left operand."); return None
            left_op_config = {"type": "variable", "value": var_name}
        else:
            value_str = self.left_operand_editor.text().strip()
            if not value_str and self.operator_combo.currentText() not in ['is', 'is not']: QMessageBox.information(self, "Input Hint", "Left operand is empty. It will be treated as an empty string.", QMessageBox.StandardButton.Ok)
            left_op_config = {"type": "hardcoded", "value": self._parse_value_from_string(value_str)}
        right_op_config: Dict[str, Any] = {}
        if self.right_operand_source_combo.currentIndex() == 1:
            var_name = self.right_operand_var_combo.currentText()
            if var_name == "-- Select Variable --": QMessageBox.warning(self, "Input Error", "Please select a global variable for the right operand."); return None
            right_op_config = {"type": "variable", "value": var_name}
        else:
            value_str = self.right_operand_editor.text().strip()
            if not value_str and self.operator_combo.currentText() not in ['is', 'is not']: QMessageBox.information(self, "Input Hint", "Right operand is empty. It will be treated as an empty string.", QMessageBox.StandardButton.Ok)
            right_op_config = {"type": "hardcoded", "value": self._parse_value_from_string(value_str)}
        operator = self.operator_combo.currentText()
        return {"block_name": block_name if block_name else None, "condition": {"left_operand": left_op_config, "operator": operator, "right_operand": right_op_config}}

    def set_config(self, config: Dict[str, Any]) -> None:
        self.block_name_editor.setText(config.get("block_name", "") or "")
        condition = config.get("condition", {})
        if not condition: return
        left_op = condition.get("left_operand", {})
        if left_op.get("type") == "variable":
            self.left_operand_source_combo.setCurrentIndex(1)
            idx = self.left_operand_var_combo.findText(left_op.get("value", ""));
            if idx != -1: self.left_operand_var_combo.setCurrentIndex(idx)
        else:
            self.left_operand_source_combo.setCurrentIndex(0)
            val_to_display = left_op.get("value", "")
            if not isinstance(val_to_display, str): val_to_display = repr(val_to_display)
            self.left_operand_editor.setText(str(val_to_display))
        idx = self.operator_combo.findText(condition.get("operator", "=="))
        if idx != -1: self.operator_combo.setCurrentIndex(idx)
        right_op = condition.get("right_operand", {})
        if right_op.get("type") == "variable":
            self.right_operand_source_combo.setCurrentIndex(1)
            idx = self.right_operand_var_combo.findText(right_op.get("value", ""))
            if idx != -1: self.right_operand_var_combo.setCurrentIndex(idx)
        else:
            self.right_operand_source_combo.setCurrentIndex(0)
            val_to_display = right_op.get("value", "")
            if not isinstance(val_to_display, str): val_to_display = repr(val_to_display)
            self.right_operand_editor.setText(str(val_to_display))
        self._toggle_left_operand_input(); self._toggle_right_operand_input()

# In main_app.py, REPLACE the entire GlobalVariableDialog class

class GlobalVariableDialog(QDialog):
    def __init__(self, variable_name: str = "", variable_value: Any = "", parent: Optional[QWidget] = None):
        super().__init__(parent)
        self.setWindowTitle("Add/Edit Global Variable")
        self.layout = QFormLayout(self)

        self.name_input = QLineEdit(variable_name)
        self.layout.addRow("Name:", self.name_input)

        # --- NEW Type ComboBox ---
        self.type_combo = QComboBox()
        self.type_combo.addItems(["String", "Number", "List", "Dictionary", "Boolean", "None"])
        self.layout.addRow("Type:", self.type_combo)

        # --- Value Input (now configured by helpers) ---
        self.value_input = QLineEdit()
        self.browse_button = QPushButton("Browse...")
        self.browse_button.clicked.connect(self._open_file_dialog)
        
        self.value_layout = QHBoxLayout()
        self.value_layout.addWidget(self.value_input)
        self.value_layout.addWidget(self.browse_button)
        self.layout.addRow("Value:", self.value_layout)

        # --- Set initial state based on variable_value ---
        self._set_initial_state(variable_value)

        # --- Buttons ---
        self.buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        self.buttons.accepted.connect(self.accept)
        self.buttons.rejected.connect(self.reject)
        self.layout.addRow(self.buttons)

        # --- Connections ---
        self.type_combo.currentTextChanged.connect(self._update_value_input_state)
        self.name_input.textChanged.connect(self._update_value_input_state) # For browse button
        self._update_value_input_state() # Initial call

    def _set_initial_state(self, variable_value: Any):
        """Sets the type combo and value text based on an existing value."""
        if isinstance(variable_value, (int, float)):
            self.type_combo.setCurrentText("Number")
            self.value_input.setText(str(variable_value))
        elif isinstance(variable_value, list):
            self.type_combo.setCurrentText("List")
            self.value_input.setText(repr(variable_value)) # Use repr for lists/dicts
        elif isinstance(variable_value, dict):
            self.type_combo.setCurrentText("Dictionary")
            self.value_input.setText(repr(variable_value))
        elif isinstance(variable_value, bool):
            self.type_combo.setCurrentText("Boolean")
            self.value_input.setText(str(variable_value))
        elif variable_value is None:
            self.type_combo.setCurrentText("None")
            self.value_input.setText("")
        else: # Default to String (covers str and other unhandled types)
            self.type_combo.setCurrentText("String")
            self.value_input.setText(str(variable_value))

    def _update_value_input_state(self):
        """Shows/hides/disables inputs based on type and name."""
        selected_type = self.type_combo.currentText()
        var_name = self.name_input.text().lower()

        if selected_type == "None":
            self.value_input.setEnabled(False)
            self.value_input.setText("")
            self.browse_button.setVisible(False)
            self.value_input.setPlaceholderText("")
        else:
            self.value_input.setEnabled(True)
            # Show browse button ONLY if type is String and name contains "link"
            is_file_link = (selected_type == "String" and "link" in var_name)
            self.browse_button.setVisible(is_file_link)
            
            # Set placeholder text
            if selected_type == "String":
                self.value_input.setPlaceholderText("Enter text value (or use Browse if name has 'link')")
            elif selected_type == "Number":
                self.value_input.setPlaceholderText("Enter a number (e.g., 123 or 45.6)")
            elif selected_type == "List":
                self.value_input.setPlaceholderText("Enter a Python list (e.g., [1, \"a\"] or [\"item\"])")
            elif selected_type == "Dictionary":
                self.value_input.setPlaceholderText("Enter a Python dict (e.g., {\"key\": \"value\"})")
            elif selected_type == "Boolean":
                self.value_input.setPlaceholderText("Enter True or False")

    def _open_file_dialog(self):
        file_path, _ = QFileDialog.getOpenFileName(self, "Select File", "", "All Files (*)")
        if file_path:
            self.value_input.setText(file_path)

    def get_variable_data(self) -> Optional[Tuple[str, Any]]:
        """Parses the value input based on the selected type."""
        name = self.name_input.text().strip()
        if not name:
            QMessageBox.warning(self, "Input Error", "Variable name cannot be empty.")
            return None
        
        selected_type = self.type_combo.currentText()
        value_str = self.value_input.text().strip()
        parsed_value: Any = None

        try:
            if selected_type == "String":
                parsed_value = value_str
            
            elif selected_type == "None":
                parsed_value = None
            
            elif selected_type == "Boolean":
                if value_str.lower() == 'true':
                    parsed_value = True
                elif value_str.lower() == 'false':
                    parsed_value = False
                else:
                    raise ValueError("Boolean value must be 'True' or 'False'")
            
            elif selected_type == "Number":
                if not value_str: # Treat empty as 0 for numbers
                    parsed_value = 0
                else:
                    parsed_value = ast.literal_eval(value_str)
                if not isinstance(parsed_value, (int, float)):
                    raise ValueError("Value is not a valid number.")
            
            elif selected_type == "List":
                if not value_str:
                    parsed_value = [] # Default to empty list
                else:
                    parsed_value = ast.literal_eval(value_str)
                if not isinstance(parsed_value, list):
                    raise ValueError("Value is not a valid list.")
            
            elif selected_type == "Dictionary":
                if not value_str:
                    parsed_value = {} # Default to empty dict
                else:
                    parsed_value = ast.literal_eval(value_str)
                if not isinstance(parsed_value, dict):
                    raise ValueError("Value is not a valid dictionary.")

            return name, parsed_value

        except (ValueError, SyntaxError) as e:
            QMessageBox.warning(self, "Input Error", f"Invalid value for type '{selected_type}'.\n\n{e}\n\nPlease check your input.")
            return None
        except Exception as e:
            QMessageBox.critical(self, "Error", f"An unexpected error occurred: {e}")
            return None

# In main_app.py, REPLACE the entire ParameterInputDialog class with this one:

class ParameterInputDialog(QDialog):
    request_screenshot = pyqtSignal()
    update_image_filenames = pyqtSignal(list, str)

    def __init__(self, method_name: str, parameters_to_configure: Dict[str, Tuple[Any, Any]],
                 current_global_var_names: List[str], image_filenames: List[str],
                 gui_communicator: GuiCommunicator,
                 initial_parameters_config: Optional[Dict[str, Any]] = None, 
                 initial_assign_to_variable_name: Optional[str] = None, 
                 method_docstring: Optional[str] = None,
                 parent: Optional[QWidget] = None):

        super().__init__(parent)
        self.setWindowTitle(f"Configure Parameters for '{method_name}'")
        self.parameters_config: Dict[str, Any] = {}
        self.assign_to_variable_name: Optional[str] = None
        self.gui_communicator = gui_communicator
        self._parent_main_window = parent
        
        self._all_image_relative_paths = image_filenames 
        self._folder_list = sorted(list(set([path.split('/')[0] for path in self._all_image_relative_paths if '/' in path])))

        self.param_editors: Dict[str, QLineEdit] = {}
        self.param_var_selectors: Dict[str, QComboBox] = {}
        self.param_value_source_combos: Dict[str, QComboBox] = {}
        self.file_selector_combos: Dict[str, QComboBox] = {}
        self.folder_selector_combos: Dict[str, QComboBox] = {}
        self.param_kinds: Dict[str, Any] = {}

        main_layout, form_layout = QVBoxLayoutDialog(), QFormLayout()
        
        if method_docstring:
            doc_group = QGroupBox("Method Documentation")
            doc_layout = QVBoxLayout()
            self.docstring_display = QTextBrowser()
            self.docstring_display.setMarkdown(method_docstring.strip())
            self.docstring_display.setFixedHeight(100)
            self.docstring_display.setReadOnly(True)
            doc_layout.addWidget(self.docstring_display)
            doc_group.setLayout(doc_layout)
            main_layout.addWidget(doc_group)
        
        initial_parameters_config = initial_parameters_config if initial_parameters_config is not None else {}

        for param_name, (default_value, param_kind) in parameters_to_configure.items():
            param_h_layout = QHBoxLayout()
            label = QLabel(f"{param_name}:")
            self.param_kinds[param_name] = param_kind

            val_to_display = ""
            value_source_combo = QComboBox()
            value_source_combo.addItems(["Hardcoded Value", "Global Variable"])
            self.param_value_source_combos[param_name] = value_source_combo

            hardcoded_editor = QLineEdit()
            self.param_editors[param_name] = hardcoded_editor

            variable_select_combo = QComboBox()
            variable_select_combo.addItem("-- Select Variable --")
            variable_select_combo.addItems(current_global_var_names)
            self.param_var_selectors[param_name] = variable_select_combo

            # --- MODIFICATION 1 of 3: Changed from 'startswith("image_to_click")' to '"image" in' ---
            if "image" in param_name:
                # This block now handles any parameter with "image" in its name
                file_source_combo = QComboBox()
                file_source_combo.addItems(["Select from Files", "Global Variable"])
                self.param_value_source_combos[param_name] = file_source_combo

                folder_selector_combo = QComboBox()
                folder_selector_combo.addItem("All Folders")
                folder_selector_combo.addItems(self._folder_list)
                self.folder_selector_combos[param_name] = folder_selector_combo

                file_selector_combo = QComboBox()
                file_selector_combo.addItem("-- Select File --")
                file_selector_combo.addItems(self._all_image_relative_paths)
                file_selector_combo.addItem("--- Add new image ---")
                self.file_selector_combos[param_name] = file_selector_combo

                variable_select_combo_for_image = QComboBox()
                variable_select_combo_for_image.addItem("-- Select Variable --")
                variable_select_combo_for_image.addItems(current_global_var_names)
                self.param_var_selectors[param_name] = variable_select_combo_for_image

                file_source_combo.currentIndexChanged.connect(
                    lambda index, f_fold=folder_selector_combo, f_sel=file_selector_combo, v_sel=variable_select_combo_for_image: \
                    self._toggle_file_or_var_input(index, f_fold, f_sel, v_sel)
                )
                
                folder_selector_combo.currentIndexChanged.connect(
                    self._update_file_list_based_on_folder
                )
                
                file_selector_combo.currentIndexChanged.connect(lambda index, p_name=param_name: self._on_file_selection_changed(p_name, index))
                self.update_image_filenames.connect(self._refresh_file_selector_combo)

                param_h_layout.addWidget(file_source_combo, 0)
                param_h_layout.addWidget(folder_selector_combo, 1)
                param_h_layout.addWidget(file_selector_combo, 2)
                param_h_layout.addWidget(variable_select_combo_for_image, 1)

                if param_name in initial_parameters_config:
                    config = initial_parameters_config[param_name]
                    if config.get('type') == 'hardcoded_file':
                        file_source_combo.setCurrentIndex(0)
                        
                        saved_path = config['value']
                        saved_folder = "All Folders"
                        if '/' in saved_path:
                            saved_folder = saved_path.split('/')[0]
                        
                        folder_idx = folder_selector_combo.findText(saved_folder)
                        if folder_idx != -1:
                            folder_selector_combo.setCurrentIndex(folder_idx)
                            self._update_file_list_based_on_folder(folder_idx) 
                        
                        idx = file_selector_combo.findText(saved_path)
                        if idx != -1:
                            file_selector_combo.setCurrentIndex(idx)
                            self._on_file_selection_changed(param_name, idx)

                    elif config.get('type') == 'variable':
                        file_source_combo.setCurrentIndex(1)
                        idx = variable_select_combo_for_image.findText(config['value'])
                        if idx != -1:
                            variable_select_combo_for_image.setCurrentIndex(idx)
                
                self._toggle_file_or_var_input(file_source_combo.currentIndex(), folder_selector_combo, file_selector_combo, variable_select_combo_for_image)

            elif "file_link" in param_name: # Handle file_link parameters separately
                browse_button = QPushButton("Browse...")
                browse_button.clicked.connect(lambda _, p_name=param_name: self._open_file_dialog_for_param(p_name))
                param_h_layout.addWidget(browse_button)

                param_h_layout.insertWidget(0, value_source_combo)
                param_h_layout.insertWidget(1, hardcoded_editor, 2)
                param_h_layout.insertWidget(2, variable_select_combo, 1)

                value_source_combo.currentIndexChanged.connect(lambda index, editor=hardcoded_editor, selector=variable_select_combo: self._toggle_param_input_type(index, editor, selector))
                self._toggle_param_input_type(value_source_combo.currentIndex(), hardcoded_editor, variable_select_combo)
                
                # Pre-fill data if editing
                if param_name in initial_parameters_config:
                    config = initial_parameters_config[param_name]
                    if config.get('type') == 'hardcoded':
                        value_source_combo.setCurrentIndex(0)
                        hardcoded_editor.setText(str(config.get('value', '')))
                    elif config.get('type') == 'variable':
                        value_source_combo.setCurrentIndex(1)
                        idx = variable_select_combo.findText(config.get('value'))
                        if idx != -1: variable_select_combo.setCurrentIndex(idx)

            else: # Logic for all other non-image, non-file_link parameters
                if param_name in initial_parameters_config:
                    config = initial_parameters_config[param_name]
                    if config.get('type') == 'hardcoded':
                        value_source_combo.setCurrentIndex(0)
                        val_to_display = config['value']
                        if not isinstance(val_to_display, str):
                            val_to_display = repr(val_to_display)
                        hardcoded_editor.setText(str(val_to_display))
                    elif config.get('type') == 'variable':
                        value_source_combo.setCurrentIndex(1)
                        idx = variable_select_combo.findText(config['value'])
                        if idx != -1:
                            variable_select_combo.setCurrentIndex(idx)
                        else:
                            QMessageBox.warning(self, "Warning", f"Global variable '{config['value']}' not found for parameter '{param_name}'.")
                elif default_value is not inspect.Parameter.empty:
                    val_to_display = default_value
                    if not isinstance(val_to_display, str):
                        val_to_display = repr(val_to_display)
                    hardcoded_editor.setText(str(val_to_display))
                elif param_kind == inspect.Parameter.VAR_POSITIONAL:
                    hardcoded_editor.setPlaceholderText("comma, separated, values")
                elif param_kind == inspect.Parameter.VAR_KEYWORD:
                    hardcoded_editor.setPlaceholderText('{"key": "value", "another": 123}')
                else:
                    hardcoded_editor.setPlaceholderText(f"Enter value for {param_name}")

                param_h_layout.insertWidget(0, value_source_combo)
                param_h_layout.insertWidget(1, hardcoded_editor, 2)
                param_h_layout.insertWidget(2, variable_select_combo, 1)

                value_source_combo.currentIndexChanged.connect(lambda index, editor=hardcoded_editor, selector=variable_select_combo: self._toggle_param_input_type(index, editor, selector))
                self._toggle_param_input_type(value_source_combo.currentIndex(), hardcoded_editor, variable_select_combo)

            form_layout.addRow(label, param_h_layout)

        main_layout.addLayout(form_layout)
        
        # --- Assignment Group Box (Unchanged) ---
        assignment_group_box = QGroupBox("Assign Method Result to Variable")
        assignment_layout = QVBoxLayoutDialog()

        self.assign_checkbox = QCheckBox("Assign result")
        self.assign_checkbox.stateChanged.connect(self._toggle_assignment_widgets)
        assignment_layout.addWidget(self.assign_checkbox)

        self.new_var_radio = QRadioButton("New Variable Name:")
        self.new_var_input = QLineEdit()
        self.new_var_input.setPlaceholderText("Enter new variable name")

        self.existing_var_radio = QRadioButton("Existing Variable:")
        self.existing_var_combo = QComboBox()
        self.existing_var_combo.addItem("-- Select Variable --")
        self.existing_var_combo.addItems(current_global_var_names)

        if initial_assign_to_variable_name:
            if initial_assign_to_variable_name in current_global_var_names:
                self.existing_var_radio.setChecked(True)
                idx = self.existing_var_combo.findText(initial_assign_to_variable_name)
                if idx != -1:
                    self.existing_var_combo.setCurrentIndex(idx)
            else:
                self.new_var_radio.setChecked(True)
                self.new_var_input.setText(initial_assign_to_variable_name)
            self.assign_checkbox.setChecked(True)
        else:
            self.new_var_radio.setChecked(True)

        self.new_var_radio.toggled.connect(self._toggle_assignment_widgets)
        self.existing_var_radio.toggled.connect(self._toggle_assignment_widgets)

        assignment_form_layout = QFormLayout()
        assignment_form_layout.addRow(self.new_var_radio, self.new_var_input)
        assignment_form_layout.addRow(self.existing_var_radio, self.existing_var_combo)
        assignment_layout.addLayout(assignment_form_layout)
        assignment_group_box.setLayout(assignment_layout)
        main_layout.addWidget(assignment_group_box)

        self._toggle_assignment_widgets()

        button_box = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        button_box.accepted.connect(self.accept)
        button_box.rejected.connect(self.reject)
        main_layout.addWidget(button_box)
        self.setLayout(main_layout)
        # --- End Assignment Group Box ---

    def _open_file_dialog_for_param(self, param_name: str):
        editor = self.param_editors.get(param_name)
        if editor:
            file_path, _ = QFileDialog.getOpenFileName(self, "Select File", "", "All Files (*)")
            if file_path:
                editor.setText(file_path)

    def _toggle_param_input_type(self, index: int, hardcoded_editor: QLineEdit, variable_select_combo: QComboBox) -> None:
        is_hardcoded = (index == 0)
        hardcoded_editor.setVisible(is_hardcoded)
        variable_select_combo.setVisible(not is_hardcoded)
        if not is_hardcoded:
            hardcoded_editor.clear()

    def _toggle_file_or_var_input(self, index: int, folder_selector_combo: QComboBox, file_selector_combo: QComboBox, variable_select_combo: QComboBox) -> None:
        is_file_selection = (index == 0)
        folder_selector_combo.setVisible(is_file_selection)
        file_selector_combo.setVisible(is_file_selection)
        variable_select_combo.setVisible(not is_file_selection)
        if not is_file_selection:
            folder_selector_combo.setCurrentIndex(0)
            file_selector_combo.setCurrentIndex(0)

    def _update_file_list_based_on_folder(self, index: int = -1):
        folder_combo = self.sender()
        if not isinstance(folder_combo, QComboBox):
            folder_combos = self.folder_selector_combos.values()
            if not folder_combos:
                return
            folder_combo = list(folder_combos)[0]

        param_name = ""
        for name, combo in self.folder_selector_combos.items():
            if combo is folder_combo:
                param_name = name
                break
        
        if not param_name:
            return

        file_combo = self.file_selector_combos.get(param_name)
        if not file_combo:
            return

        selected_folder = folder_combo.currentText()
        current_file = file_combo.currentText()

        file_combo.blockSignals(True)
        file_combo.clear()
        file_combo.addItem("-- Select File --")

        if selected_folder == "All Folders":
            filtered_files = self._all_image_relative_paths
        else:
            prefix = selected_folder + '/'
            root_files = [path for path in self._all_image_relative_paths if '/' not in path]
            folder_files = [path for path in self._all_image_relative_paths if path.startswith(prefix)]
            filtered_files = root_files + folder_files

        file_combo.addItems(sorted(filtered_files))
        file_combo.addItem("--- Add new image ---")
        
        idx = file_combo.findText(current_file)
        if idx != -1:
            file_combo.setCurrentIndex(idx)
        
        file_combo.blockSignals(False)

    def _on_file_selection_changed(self, param_name: str, index: int) -> None:
        # --- MODIFICATION 2 of 3: Changed from 'startswith("image_to_click")' to '"image" in' ---
        if "image" in param_name and param_name in self.file_selector_combos:
            file_selector_combo = self.file_selector_combos[param_name]
            selected_text = file_selector_combo.currentText()
            if selected_text == "--- Add new image ---":
                file_selector_combo.blockSignals(True)
                file_selector_combo.setCurrentIndex(0)
                file_selector_combo.blockSignals(False)
                self.request_screenshot.emit()
            elif selected_text != "-- Select File --":
                self.gui_communicator.update_module_info_signal.emit(selected_text)
            else:
                self.gui_communicator.update_module_info_signal.emit("")

    def _refresh_file_selector_combo(self, new_filenames: List[str], saved_filename: str = "") -> None:
        self._all_image_relative_paths = new_filenames
        self._folder_list = sorted(list(set([path.split('/')[0] for path in new_filenames if '/' in path])))
        
        for param_name, combo_box in self.file_selector_combos.items():
            # This check is implicitly correct because only image parameters will be in file_selector_combos
            folder_combo = self.folder_selector_combos.get(param_name)
            
            target_folder_name = "All Folders"
            if saved_filename and '/' in saved_filename:
                target_folder_name = saved_filename.split('/')[0]
            elif folder_combo:
                target_folder_name = folder_combo.currentText()

            if folder_combo:
                folder_combo.blockSignals(True)
                folder_combo.clear()
                folder_combo.addItem("All Folders")
                folder_combo.addItems(self._folder_list)
                
                folder_idx = folder_combo.findText(target_folder_name)
                if folder_idx != -1:
                    folder_combo.setCurrentIndex(folder_idx)
                else:
                    folder_combo.setCurrentIndex(0)
                folder_combo.blockSignals(False)

            selected_folder = folder_combo.currentText() if folder_combo else "All Folders"

            if selected_folder == "All Folders":
                filtered_files = self._all_image_relative_paths
            else:
                prefix = selected_folder + '/'
                root_files = [path for path in self._all_image_relative_paths if '/' not in path]
                folder_files = [path for path in self._all_image_relative_paths if path.startswith(prefix)]
                filtered_files = root_files + folder_files

            combo_box.blockSignals(True)
            combo_box.clear()
            combo_box.addItem("-- Select File --")
            combo_box.addItems(sorted(filtered_files))
            combo_box.addItem("--- Add new image ---")

            if saved_filename:
                idx = combo_box.findText(saved_filename)
                if idx != -1:
                    combo_box.setCurrentIndex(idx)
                    self.gui_communicator.update_module_info_signal.emit(saved_filename)
            
            combo_box.blockSignals(False)
            
            if combo_box.currentIndex() <= 0 and saved_filename == "":
                self.gui_communicator.update_module_info_signal.emit("")

    def _toggle_assignment_widgets(self) -> None:
        is_assign_enabled = self.assign_checkbox.isChecked()
        self.new_var_radio.setVisible(is_assign_enabled)
        self.new_var_input.setVisible(is_assign_enabled and self.new_var_radio.isChecked())
        self.existing_var_radio.setVisible(is_assign_enabled)
        self.existing_var_combo.setVisible(is_assign_enabled and self.existing_var_radio.isChecked())
        if not is_assign_enabled:
            self.new_var_input.clear()
            self.existing_var_combo.setCurrentIndex(0)

    def get_parameters_config(self) -> Optional[Dict[str, Any]]:
        config_data: Dict[str, Any] = {}
        for param_name, source_combo in self.param_value_source_combos.items():
            # --- MODIFICATION 3 of 3: Changed from 'startswith("image_to_click")' to '"image" in' ---
            if "image" in param_name and param_name in self.file_selector_combos:
                value_source_index = source_combo.currentIndex()
                if value_source_index == 0:
                    file_name = self.file_selector_combos[param_name].currentText()
                    if file_name in ["-- Select File --", "--- Add new image ---"]:
                        # Allow empty image for parameters that might be optional
                        # A check can be added in the bot module itself if an image is mandatory
                        config_data[param_name] = {'type': 'hardcoded_file', 'value': ""}
                    else:
                        config_data[param_name] = {'type': 'hardcoded_file', 'value': file_name}
                else:
                    var_name = self.param_var_selectors[param_name].currentText()
                    if var_name == "-- Select Variable --":
                        QMessageBox.warning(self, "Input Error", f"Please select a global variable for parameter '{param_name}'.")
                        return None
                    config_data[param_name] = {'type': 'variable', 'value': var_name}
                continue
            
            # Logic for all other parameters (unchanged)
            value_source_index = source_combo.currentIndex()
            if value_source_index == 0:
                value_str = self.param_editors[param_name].text().strip()
                param_kind = self.param_kinds[param_name]
                try:
                    parsed_value = None
                    if value_str.lower() == 'none':
                        parsed_value = None
                    elif param_kind == inspect.Parameter.VAR_POSITIONAL:
                        parsed_value = [item.strip() for item in value_str.split(',') if item.strip()]
                    elif param_kind == inspect.Parameter.VAR_KEYWORD:
                        parsed_value = json.loads(value_str)
                    elif value_str.lower() == 'true':
                        parsed_value = True
                    elif value_str.lower() == 'false':
                        parsed_value = False
                    elif value_str.isdigit():
                        parsed_value = int(value_str)
                    elif value_str.replace('.', '', 1).isdigit():
                        parsed_value = float(value_str)
                    else:
                        if (value_str.startswith('{') and value_str.endswith('}')) or (value_str.startswith('[') and value_str.endswith(']')):
                            try:
                                parsed_value = json.loads(value_str)
                            except json.JSONDecodeError:
                                parsed_value = value_str
                        else:
                            parsed_value = value_str
                except (ValueError, json.JSONDecodeError) as e:
                    QMessageBox.warning(self, "Input Error", f"Could not parse value '{value_str}' for '{param_name}' ({param_kind}): {e}. Storing as string.")
                    parsed_value = value_str
                
                # Also handle file_link parameters here now
                if "file_link" in param_name:
                    config_data[param_name] = {'type': 'hardcoded', 'value': value_str} # Always treat as string path
                else:
                    config_data[param_name] = {'type': 'hardcoded', 'value': parsed_value}
            else:
                var_name = self.param_var_selectors[param_name].currentText()
                if var_name == "-- Select Variable --":
                    QMessageBox.warning(self, "Input Error", f"Please select a global variable for parameter '{param_name}'.")
                    return None
                config_data[param_name] = {'type': 'variable', 'value': var_name}

        self.parameters_config = config_data
        return config_data

    def get_assignment_variable(self) -> Optional[str]:
        if not self.assign_checkbox.isChecked():
            return None
        if self.new_var_radio.isChecked():
            var_name = self.new_var_input.text().strip()
            if not var_name:
                QMessageBox.warning(self, "Input Error", "New variable name cannot be empty for assignment.")
                return None
            return var_name
        else:
            var_name = self.existing_var_combo.currentText()
            if var_name == "-- Select Variable --":
                QMessageBox.warning(self, "Input Error", "Please select an existing variable to assign the result to.")
                return None
            return var_name


# REPLACE the entire ExecutionWorker class with this one:

# In main_app.py
# REPLACE the entire ExecutionWorker class with this one:

class ExecutionWorker(QThread):
    execution_started = pyqtSignal(str)
    execution_progress = pyqtSignal(int)
    execution_item_started = pyqtSignal(dict, int)
    execution_item_finished = pyqtSignal(dict, str, int)
    execution_error = pyqtSignal(dict, str, int)
    execution_finished_all = pyqtSignal(ExecutionContext, bool, int)
    loop_iteration_started = pyqtSignal(str, int)

    def __init__(self, steps_to_execute: List[Dict[str, Any]], module_directory: str, gui_communicator: GuiCommunicator,
                 global_variables_ref: Dict[str, Any],
                 wait_config: Dict[str, Any],
                 parent: Optional[QWidget] = None,
                 single_step_mode: bool = False,
                 selected_start_index: int = 0,
                 selected_end_index: Optional[int] = None,
                 # --- NEW ARGUMENTS FOR EMAIL NOTIFICATIONS ---
                 bot_name: str = "Untitled Bot",
                 email_config: Optional[Dict[str, Any]] = None):
        super().__init__(parent)
        self.steps_to_execute = steps_to_execute
        self.module_directory = module_directory
        self.click_image_dir = os.path.normpath(os.path.join(module_directory, "..", "Click_image"))
        self.instantiated_objects: Dict[Tuple[str, str], Any] = {}
        self.context = ExecutionContext()
        self.context.set_gui_communicator(gui_communicator)
        self.global_variables = global_variables_ref
        self._is_stopped = False
        self.loop_stack: List[Dict[str, Any]] = []
        self.conditional_stack: List[Dict[str, Any]] = []
        self.group_stack: List[Dict[str, Any]] = []
        self.single_step_mode = single_step_mode
        self.selected_start_index = selected_start_index
        self.selected_end_index = selected_end_index
        self.next_step_index_to_select: int = -1
        self._is_paused = False
        self.wait_config = wait_config
        # --- STORE NEW ATTRIBUTES ---
        self.bot_name = bot_name
        self.email_config = email_config or {}
        self.error_message: Optional[str] = None # To store the specific error

    # ... (Keep all existing methods like _resolve_loop_count, _resolve_operand_value, _evaluate_condition) ...
    def _resolve_loop_count(self, loop_config: Dict[str, Any]) -> int:
        count_config = loop_config["iteration_count_config"]
        if count_config["type"] == "variable":
            var_name = count_config["value"]
            var_value = self.global_variables.get(var_name)
            if isinstance(var_value, int) and var_value >= 1: return var_value
            else: self.context.add_log(f"Warning: Global variable '{var_name}' for loop count is not a valid positive integer (value: {var_value}). Defaulting to 1 iteration."); return 1
        else: return count_config.get("value", 1)

    def _resolve_operand_value(self, operand_config: Dict[str, Any]) -> Any:
        if operand_config["type"] == "variable":
            var_name = operand_config["value"]
            if var_name not in self.global_variables: raise ValueError(f"Global variable '{var_name}' not found for condition operand.")
            return self.global_variables[var_name]
        else: return operand_config["value"]

    def _evaluate_condition(self, condition_config: Dict[str, Any]) -> bool:
        left_val = self._resolve_operand_value(condition_config["left_operand"])
        right_val = self._resolve_operand_value(condition_config["right_operand"])
        operator = condition_config["operator"]
        try:
            if operator == '==': return left_val == right_val
            elif operator == '!=': return left_val != right_val
            elif operator == '<': return left_val < right_val
            elif operator == '>': return left_val > right_val
            elif operator == '<=': return left_val <= right_val
            elif operator == '>=': return left_val >= right_val
            elif operator == 'in': return left_val in right_val
            elif operator == 'not in': return left_val not in right_val
            elif operator == 'is': return left_val is right_val
            elif operator == 'is not': return left_val is not right_val
            else: raise ValueError(f"Unknown operator: {operator}")
        except Exception as e: raise ValueError(f"Error evaluating condition '{left_val} {operator} {right_val}': {e}")
        
    # --- NEW METHOD TO SEND EMAIL ---
    # --- NEW METHOD TO SEND EMAIL ---
    def _send_notification_email(self):
        """Sends an email based on the execution result and configuration."""
        if not self.email_config.get("email_notification_enabled"):
            return

        is_error = self.error_message is not None
        should_send = False

        if is_error and self.email_config.get("notify_on_error"):
            should_send = True
        elif not is_error and self.email_config.get("notify_on_success"):
            should_send = True

        if should_send:
            status = "Failed with Error" if is_error else "Completed Successfully"
            recipient = self.email_config.get("recipient_email")
            
            try:
                emailer = Emailer()
                # --- THIS IS THE KEY CHANGE ---
                # Check the return value of the send function.
                was_sent = emailer.send_outlook_notification(
                    recipient_email=recipient,
                    bot_name=self.bot_name,
                    status=status,
                    error_message=self.error_message or ""
                )
                
                if was_sent:
                    self.context.add_log(f"Notification email sent to {recipient}.")
                else:
                    # If it fails, log a warning instead of crashing.
                    self.context.add_log(f"WARNING: Could not send notification email to {recipient}. Outlook may not be installed or available.")
                # --- END OF KEY CHANGE ---
            except Exception as e:
                # Log to the context if email sending fails for any other reason
                self.context.add_log(f"CRITICAL: Failed to send notification email. Error: {e}")

    # --- MODIFIED RUN METHOD ---
# In main_app.py, find the ExecutionWorker class
# REPLACE the entire 'run' method with this one:

    def run(self) -> None:
        self.execution_started.emit("Starting execution...")
        if not self.steps_to_execute:
            self.execution_finished_all.emit(self.context, False, -1)
            return
            
        if self.selected_end_index is not None:
            actual_end_index = min(self.selected_end_index + 1, len(self.steps_to_execute))
        else:
            actual_end_index = len(self.steps_to_execute)
        
        total_steps_for_progress = (actual_end_index - self.selected_start_index) if not self.single_step_mode else 1
        if total_steps_for_progress == 0: total_steps_for_progress = 1
            
        current_execution_item_count = 0
        original_sys_path = sys.path[:]
        
        if self.module_directory not in sys.path:
            sys.path.insert(0, self.module_directory)
            
        self.context.set_click_image_base_dir(self.click_image_dir)
        self.context.set_global_variables_ref(self.global_variables)     
        
        self.loop_stack = []
        self.conditional_stack = []
        self.group_stack = []
        step_index = self.selected_start_index
        original_listbox_row_index = 0
        
        # Define the jump signal prefix
        JUMP_PREFIX = "_JUMP_TO_STEP_::"

        try:
            while step_index < actual_end_index:
                while self._is_paused:
                    if self._is_stopped: break
                    QThread.msleep(100)
                
                if self._is_stopped: break
                if self.single_step_mode and current_execution_item_count >= 1: break
                
                if current_execution_item_count > 0 and not self.single_step_mode:
                    wait_seconds = 0
                    if self.wait_config['type'] == 'variable':
                        var_name = self.wait_config['value']
                        var_value = self.global_variables.get(var_name, 0)
                        try: wait_seconds = float(var_value)
                        except (ValueError, TypeError):
                            self.context.add_log(f"Warning: Global variable '@{var_name}' does not contain a valid number for wait time. Using 0."); wait_seconds = 0
                    else: wait_seconds = self.wait_config['value']

                    if wait_seconds > 0:
                        self.context.add_log(f"Waiting for {wait_seconds:.2f} second(s)..."); QThread.msleep(int(wait_seconds * 1000))
                
                step_data = self.steps_to_execute[step_index]
                step_type = step_data["type"]
                original_listbox_row_index = step_data.get("original_listbox_row_index", step_index)
                current_execution_item_count += 1
                progress_percentage = int((current_execution_item_count / total_steps_for_progress) * 100)
                self.execution_progress.emit(min(progress_percentage, 100))
                
                is_skipping = False
                if self.conditional_stack:
                    current_if_context = self.conditional_stack[-1]
                    is_in_false_if_branch = not current_if_context.get('condition_result', True) and not current_if_context.get('else_taken', False)
                    is_in_true_else_branch = current_if_context.get('condition_result', False) and current_if_context.get('else_taken', False)
                    if is_in_false_if_branch and not (step_type == "ELSE" and step_data.get("if_id") == current_if_context["if_id"]): is_skipping = True
                    elif is_in_true_else_branch and not (step_type == "IF_END" and step_data.get("if_id") == current_if_context["if_id"]): is_skipping = True
                
                if is_skipping:
                    self.execution_item_started.emit(step_data, original_listbox_row_index)
                    if step_type == "IF_START": self.conditional_stack.append({'if_id': step_data['if_id'], 'skipped_marker': True})
                    elif step_type == "loop_start": self.loop_stack.append({'loop_id': step_data['loop_id'], 'skipped_marker': True})
                    elif step_type == "group_start": self.group_stack.append({'group_id': step_data['group_id'], 'skipped_marker': True})
                    elif step_type == "IF_END" and self.conditional_stack and self.conditional_stack[-1].get('skipped_marker'): self.conditional_stack.pop()
                    elif step_type == "loop_end" and self.loop_stack and self.loop_stack[-1].get('skipped_marker'): self.loop_stack.pop()
                    elif step_type == "group_end" and self.group_stack and self.group_stack[-1].get('skipped_marker'): self.group_stack.pop()
                    self.execution_item_finished.emit(step_data, "SKIPPED", original_listbox_row_index); step_index += 1; continue
                
                self.execution_item_started.emit(step_data, original_listbox_row_index); QThread.msleep(50)
                if step_type in ["group_start", "group_end"]: self.execution_item_finished.emit(step_data, "Organizational Step", original_listbox_row_index)
                elif step_type == "loop_start":
                    loop_id, loop_config = step_data["loop_id"], step_data["loop_config"]
                    is_new_loop = not (self.loop_stack and self.loop_stack[-1].get('loop_id') == loop_id)
                    if is_new_loop: total_iterations = self._resolve_loop_count(loop_config); self.loop_stack.append({'loop_id': loop_id, 'start_index': step_index, 'current_iteration': 1, 'total_iterations': total_iterations, 'loop_config': loop_config}); self.loop_iteration_started.emit(loop_id, 1)
                    else: current_loop_info = self.loop_stack[-1]; current_loop_info['current_iteration'] += 1; current_loop_info['total_iterations'] = self._resolve_loop_count(loop_config); self.loop_iteration_started.emit(loop_id, current_loop_info['current_iteration'])
                    current_loop_info = self.loop_stack[-1]
                    if current_loop_info['current_iteration'] > current_loop_info['total_iterations']:
                        self.loop_stack.pop()
                        nesting_level, loop_end_index = 0, -1
                        for i in range(step_index + 1, len(self.steps_to_execute)):
                            s, s_type = self.steps_to_execute[i], self.steps_to_execute[i].get("type")
                            if s_type in ["loop_start", "IF_START", "group_start"]: nesting_level += 1
                            elif s_type == "loop_end" and s.get("loop_id") == loop_id and nesting_level == 0: loop_end_index = i; break
                            elif s_type in ["loop_end", "IF_END", "group_end"] and nesting_level > 0: nesting_level -= 1
                        if loop_end_index != -1: step_index = loop_end_index
                        self.execution_item_finished.emit(step_data, "Loop Finished", original_listbox_row_index)
                    else:
                        assign_var = loop_config.get("assign_iteration_to_variable")
                        if assign_var: self.global_variables[assign_var] = current_loop_info['current_iteration']; self.context.add_log(f"Assigned iteration {current_loop_info['current_iteration']} to @{assign_var}")
                        self.execution_item_finished.emit(step_data, f"Iter {current_loop_info['current_iteration']}/{current_loop_info['total_iterations']}", original_listbox_row_index)
                elif step_type == "loop_end":
                    if not self.loop_stack or self.loop_stack[-1].get('loop_id') != step_data['loop_id']: raise ValueError(f"Mismatched loop_end for ID: {step_data['loop_id']}")
                    step_index = self.loop_stack[-1]['start_index'] - 1; self.execution_item_finished.emit(step_data, "Looping...", original_listbox_row_index)
                elif step_type == "step":
                    class_name, method_name, module_name, parameters_config, assign_to_variable_name = step_data["class_name"], step_data["method_name"], step_data["module_name"], step_data["parameters_config"], step_data["assign_to_variable_name"]
                    resolved_parameters, params_str_debug = {}, []
                    for param_name, config in parameters_config.items():
                        if param_name == "original_listbox_row_index": continue
                        if config['type'] == 'hardcoded': resolved_parameters[param_name] = config['value']; params_str_debug.append(f"{param_name}={repr(config['value'])}")
                        elif config['type'] == 'hardcoded_file': resolved_parameters[param_name] = config['value']; params_str_debug.append(f"{param_name}=FILE('{config['value']}')")
                        elif config['type'] == 'variable':
                            var_name = config['value']
                            if var_name in self.global_variables: resolved_parameters[param_name] = self.global_variables[var_name]; params_str_debug.append(f"{param_name}=@{var_name}({repr(self.global_variables[var_name])})")
                            else: raise ValueError(f"Global variable '{var_name}' not found for parameter '{param_name}'.")
                    self.context.add_log(f"Executing: {class_name}.{method_name}({', '.join(params_str_debug)})")
                    try:
                        module = importlib.import_module(module_name); importlib.reload(module); class_obj = getattr(module, class_name)
                        instance_key = (class_name, module_name)
                        if instance_key not in self.instantiated_objects:
                            init_kwargs = {};
                            if 'context' in inspect.signature(class_obj.__init__).parameters: init_kwargs['context'] = self.context
                            self.instantiated_objects[instance_key] = class_obj(**init_kwargs)
                        instance = self.instantiated_objects[instance_key]; method_func = getattr(instance, method_name); method_kwargs = {k:v for k,v in resolved_parameters.items()}
                        if 'context' in inspect.signature(method_func).parameters: method_kwargs['context'] = self.context
                        
                        # Execute the method and get the result
                        result = method_func(**method_kwargs)
                        
                        # ===============================================
                        # === NEW JUMP LOGIC STARTS HERE ===
                        # ===============================================
                        if isinstance(result, str) and result.startswith(JUMP_PREFIX):
                            try:
                                # 1. Parse the target step number from the result string
                                target_step_1_based = int(result.replace(JUMP_PREFIX, ""))
                                # 2. Convert to 0-based index for our list
                                target_index_0_based = target_step_1_based - 1

                                # 3. Validate the target index
                                if 0 <= target_index_0_based < len(self.steps_to_execute):
                                    # 4. Set the main step_index to the new target.
                                    #    We subtract 1 because the loop will auto-increment it.
                                    step_index = target_index_0_based - 1
                                    self.context.add_log(f"Jumping to step {target_step_1_based}.")
                                    self.execution_item_finished.emit(step_data, f"Jumping to step {target_step_1_based}", original_listbox_row_index)
                                else:
                                    # The jump target is out of bounds, treat as an error
                                    raise ValueError(f"Jump target step {target_step_1_based} is out of bounds (1-{len(self.steps_to_execute)}).")
                            except (ValueError, TypeError) as jump_error:
                                # Catch errors from parsing or invalid numbers
                                raise ValueError(f"Invalid JumpTo instruction: {jump_error}")
                            
                            # After setting the new index, continue to the next loop iteration
                            # to immediately process the target step.
                            step_index += 1
                            continue 
                        # ===============================================
                        # === NEW JUMP LOGIC ENDS HERE ===
                        # ===============================================
                        
                        # --- This is the original logic for normal steps ---
                        if assign_to_variable_name: 
                            self.global_variables[assign_to_variable_name] = result
                            result_msg = f"Result: {result} (Assigned to @{assign_to_variable_name})"
                        else: 
                            result_msg = f"Result: {result}"
                            
                        self.execution_item_finished.emit(step_data, result_msg, original_listbox_row_index)
                        
                    except Exception as e: raise e
                elif step_type == "IF_START":
                    condition_config, if_id = step_data["condition_config"], step_data["if_id"]; condition_result = self._evaluate_condition(condition_config["condition"])
                    self.context.add_log(f"IF '{if_id}' evaluated: {condition_result}"); self.conditional_stack.append({'if_id': if_id, 'condition_result': condition_result, 'else_taken': False})
                    self.execution_item_finished.emit(step_data, f"Condition: {condition_result}", original_listbox_row_index)
                    if not condition_result:
                        nesting_level, target_index = 0, -1
                        for i in range(step_index + 1, len(self.steps_to_execute)):
                            s, s_type = self.steps_to_execute[i], self.steps_to_execute[i].get("type")
                            if s_type in ["loop_start", "IF_START", "group_start"]: nesting_level += 1
                            elif s_type in ["ELSE", "IF_END"] and s.get("if_id") == if_id and nesting_level == 0: target_index = i; break
                            elif s_type in ["loop_end", "IF_END", "group_end"] and nesting_level > 0: nesting_level -= 1
                        if target_index != -1: step_index = target_index - 1
                        else: raise ValueError(f"Mismatched IF_START for ID: {if_id}, no ELSE or IF_END found.")
                elif step_type == "ELSE":
                    if not self.conditional_stack or self.conditional_stack[-1].get('if_id') != step_data['if_id']: raise ValueError(f"Mismatched ELSE for ID: {step_data['if_id']}")
                    current_if = self.conditional_stack[-1]; current_if['else_taken'] = True; self.execution_item_finished.emit(step_data, "Branching", original_listbox_row_index)
                    if current_if.get('condition_result', False):
                        nesting_level, target_index = 0, -1
                        for i in range(step_index + 1, len(self.steps_to_execute)):
                            s, s_type = self.steps_to_execute[i], self.steps_to_execute[i].get("type")
                            if s_type in ["loop_start", "IF_START", "group_start"]: nesting_level += 1
                            elif s_type == "IF_END" and s.get("if_id") == current_if["if_id"] and nesting_level == 0: target_index = i; break
                            elif s_type in ["loop_end", "IF_END", "group_end"] and nesting_level > 0: nesting_level -= 1
                        if target_index != -1: step_index = target_index - 1
                        else: raise ValueError(f"Mismatched ELSE for ID: {current_if['if_id']}, no IF_END found.")
                elif step_type == "IF_END":
                    if not self.conditional_stack or self.conditional_stack[-1].get('if_id') != step_data['if_id']: raise ValueError(f"Mismatched IF_END for ID: {step_data['if_id']}")
                    self.conditional_stack.pop(); self.execution_item_finished.emit(step_data, "End of Conditional", original_listbox_row_index)
                step_index += 1
        except Exception as e:
            self.error_message = f"Error at step {original_listbox_row_index+1}: {type(e).__name__}: {e}"
            self.context.add_log(self.error_message)
            self.execution_error.emit(self.steps_to_execute[step_index] if step_index < len(self.steps_to_execute) else {}, self.error_message, original_listbox_row_index)
            self._is_stopped = True
        finally:
            sys.path = original_sys_path
            if self.single_step_mode:
                next_index = -1
                if not self._is_stopped and step_index < len(self.steps_to_execute): next_index = self.steps_to_execute[step_index].get("original_listbox_row_index", -1)
                self.next_step_index_to_select = next_index
            
            if not self.single_step_mode:
                self._send_notification_email()
            
            self.execution_finished_all.emit(self.context, self._is_stopped, self.next_step_index_to_select)


    # ... (Keep all existing methods like pause, resume, stop) ...
    def pause(self): self._is_paused = True; self.context.add_log("Execution PAUSED."); self.execution_started.emit("Execution PAUSED.")
    def resume(self): self._is_paused = False; self.context.add_log("Execution RESUMED."); self.execution_started.emit("Execution RESUMED.")
    def stop(self): self._is_stopped = True; self.context.add_log("Execution STOP requested by user."); self.execution_started.emit("Execution STOPPED.")

        
class RearrangeStepItemWidget(QWidget):
    """A compact widget to display a step's details for the rearrange dialog."""
    def __init__(self, step_data: Dict[str, Any], step_number: int, parent: Optional[QWidget] = None):
        super().__init__(parent)
        self.step_data = step_data
        self.step_number = step_number

        layout = QHBoxLayout(self)
        layout.setContentsMargins(5, 3, 5, 3)

        # Get the detailed text for the label
        full_text = self._get_formatted_display_text()
        
        self.label = QLabel(full_text)
        self.label.setWordWrap(True)
        
        # Add an icon to indicate draggability
        self.drag_handle_label = QLabel("☰")
        self.drag_handle_label.setToolTip("Drag to reorder")
        self.drag_handle_label.setStyleSheet("font-weight: bold; color: #7f8c8d;")
        self.drag_handle_label.setFixedWidth(20)
        layout.addWidget(self.drag_handle_label)
        layout.addWidget(self.label)
        
        # Set background color based on step type for better readability
        step_type = self.step_data.get("type")
        if step_type in ["loop_start", "IF_START", "group_start"]:
            self.setStyleSheet("background-color: #e8f4fd; border-radius: 3px;")
        elif step_type in ["loop_end", "IF_END", "group_end", "ELSE"]:
            self.setStyleSheet("background-color: #f1f2f3; border-radius: 3px;")
        else:
             self.setStyleSheet("background-color: #ffffff; border-radius: 3px;")

    def _get_formatted_display_text(self) -> str:
        """
        Creates a descriptive string for the step, ensuring the step number is always first.
        Format: Step X: @var = method(params...)
        """
        step_type = self.step_data.get("type")
        step_num = self.step_number
        
        # --- NEW LOGIC: Get block name if it exists ---
        block_name_str = ""
        if step_type == "group_start" or step_type == "group_end":
            name = self.step_data.get("group_name")
            if name: block_name_str = f": '{name}'"
        elif step_type == "loop_start" or step_type == "loop_end":
            config = self.step_data.get("loop_config", {})
            name = config.get("loop_name")
            if name: block_name_str = f": '{name}'"
        elif step_type == "IF_START" or step_type == "ELSE" or step_type == "IF_END":
            config = self.step_data.get("condition_config", {})
            name = config.get("block_name")
            if name: block_name_str = f": '{name}'"
        # --- END NEW LOGIC ---

        # For non-step types (loops, ifs, etc.), use the reliable formatting from ExecutionStepCard
        if step_type != "step":
            temp_card = ExecutionStepCard(self.step_data, step_num)
            
            # --- MODIFIED: Add the block name ---
            base_title = temp_card.step_label.text().replace(":", "") # Remove default colon
            # --- END MODIFIED ---
            
            details_text = temp_card.method_label.text() if temp_card.method_label else ""
            
            if details_text:
                return f"{base_title}{block_name_str}: {details_text}"
            return f"{base_title}{block_name_str}"

        # --- THIS IS THE UPDATED LOGIC FOR 'step' TYPE ---
        
        # 1. Start with the Step number, which is always present.
        display_parts = [f"Step {step_num}:"]
        
        # 2. Add the variable assignment, if it exists.
        assign_var = self.step_data.get("assign_to_variable_name")
        if assign_var:
            display_parts.append(f"@{assign_var} =")
        
        # 3. Construct the method call string with parameters.
        method_name = self.step_data.get("method_name", "Unknown")
        params_config = self.step_data.get("parameters_config", {})
        param_details = []

        for name, config in params_config.items():
            if name == "original_listbox_row_index":
                continue
            
            value_display = ""
            param_type = config.get('type')
            
            if param_type == 'hardcoded':
                value_display = repr(config['value'])
            elif param_type == 'hardcoded_file':
                base_name = os.path.basename(config['value'])
                value_display = f"File:'{base_name}'"
            elif param_type == 'variable':
                value_display = f"@{config['value']}"
            else:
                value_display = "???"

            if len(value_display) > 25:
                value_display = value_display[:22] + "..."

            param_details.append(f"{name}={value_display}")
        
        param_str = ", ".join(param_details)
        method_call_str = f"{method_name}({param_str})"
        
        # 4. Add the method call string to our list of parts.
        display_parts.append(method_call_str)
        
        # 5. Join all the parts together with spaces.
        return " ".join(display_parts)
        
    def set_bold(self, bold: bool):
        """Sets the font of the main label to bold or normal."""
        font = self.label.font()
        font.setBold(bold)
        self.label.setFont(font)
    

# --- DIALOG: RearrangeStepsDialog (WITH MULTI-SELECT, DRAG-DROP, AND PRECISE MOVE) ---

class RearrangeStepsDialog(QDialog):
    """A dialog to reorder steps using drag-and-drop or precise movement."""
    def __init__(self, steps_data: List[Dict[str, Any]], parent: Optional[QWidget] = None):
        super().__init__(parent)
        self.setWindowTitle("Rearrange Bot Steps")
        self.setMinimumSize(1000, 700)
        
        self.main_window_ref = parent 
        self.original_steps = steps_data
        
        main_layout = QVBoxLayout(self)

        # Instructions
        info_label = QLabel("Drag and drop to reorder. Use Ctrl/Shift to select multiple items, or use the controls below.")
        info_label.setStyleSheet("font-style: italic; color: #555;")
        main_layout.addWidget(info_label)

        # The list widget that will hold the steps
        self.steps_list_widget = QListWidget()
        self.steps_list_widget.setDragDropMode(QListWidget.DragDropMode.InternalMove)
        self.steps_list_widget.setSelectionMode(QListWidget.SelectionMode.ExtendedSelection)
        self.steps_list_widget.setAlternatingRowColors(True)
        self.steps_list_widget.setStyleSheet("font-size: 12pt;")
        main_layout.addWidget(self.steps_list_widget)

        # Populate the list with our custom widgets
        self.populate_list(self.original_steps)
        
        # --- Edit buttons (Group, Delete) ---
        edit_button_layout = QHBoxLayout()
        self.group_selected_button = QPushButton("📦 Group Selected")
        self.delete_selected_button = QPushButton("🗑️ Delete Selected")
        
        edit_button_layout.addWidget(self.group_selected_button)
        edit_button_layout.addStretch()
        edit_button_layout.addWidget(self.delete_selected_button)
        main_layout.addLayout(edit_button_layout)
        
        # --- NEW: Precise Move Controls ---
        move_group = QGroupBox("Move Selected Steps")
        move_layout = QHBoxLayout(move_group)
        
        self.move_position_combo = QComboBox()
        self.move_position_combo.addItems(["Before Step #", "After Step #"])
        
        self.move_target_input = QLineEdit()
        self.move_target_input.setPlaceholderText("Num")
        self.move_target_input.setValidator(QIntValidator(1, 9999)) # Allow up to 9999 steps
        self.move_target_input.setFixedWidth(60)

        self.move_button = QPushButton("➡️ Move")
        self.move_button.setToolTip("Move selected steps to the specified position")
        
        move_layout.addWidget(QLabel("Action:"))
        move_layout.addWidget(self.move_position_combo)
        move_layout.addWidget(self.move_target_input)
        move_layout.addStretch()
        move_layout.addWidget(self.move_button)
        
        main_layout.addWidget(move_group)
        # --- END NEW ---

        # OK and Cancel buttons
        button_box = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        button_box.accepted.connect(self.accept)
        button_box.rejected.connect(self.reject)
        main_layout.addWidget(button_box)
        
        # --- Connect signals ---
        self.delete_selected_button.clicked.connect(self.delete_selected)
        self.group_selected_button.clicked.connect(self.group_selected)
        self.steps_list_widget.itemSelectionChanged.connect(self.on_selection_changed)
        
        # --- NEW: Connect precise move button signal ---
        self.move_button.clicked.connect(self._handle_precise_move)

        # --- Initial UI state ---
        self.on_selection_changed() # Call once to set initial button states

    def populate_list(self, steps_to_load: List[Dict[str, Any]]):
        """Fills the QListWidget with the steps and updates step numbers."""
        self.steps_list_widget.clear()
        
        for i, step_data in enumerate(steps_to_load):
            list_item = QListWidgetItem(self.steps_list_widget)
            item_widget = RearrangeStepItemWidget(step_data, i + 1)
            list_item.setData(Qt.ItemDataRole.UserRole, step_data)
            list_item.setSizeHint(item_widget.sizeHint())
            self.steps_list_widget.setItemWidget(list_item, item_widget)

    def get_current_steps_from_list(self) -> List[Dict[str, Any]]:
        """Helper to get the current list of data from the list widget."""
        return [self.steps_list_widget.item(i).data(Qt.ItemDataRole.UserRole) for i in range(self.steps_list_widget.count())]

    def get_rearranged_steps(self) -> List[Dict[str, Any]]:
        """Returns the new, reordered list of step data."""
        return self.get_current_steps_from_list()

    def delete_selected(self):
        """Removes all currently selected items from the list."""
        selected_items = self.steps_list_widget.selectedItems()
        if not selected_items:
            return

        reply = QMessageBox.question(self, "Confirm Delete",
                                     f"Are you sure you want to delete {len(selected_items)} selected step(s)?",
                                     QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                                     QMessageBox.StandardButton.No)
        
        if reply == QMessageBox.StandardButton.Yes:
            # We must iterate in reverse when removing items
            for item in reversed(selected_items):
                row = self.steps_list_widget.row(item)
                self.steps_list_widget.takeItem(row)
            
            self.populate_list(self.get_current_steps_from_list())

    def group_selected(self):
        """Wraps the currently selected items in a Group block."""
        selected_items = self.steps_list_widget.selectedItems()
        if not selected_items:
            QMessageBox.information(self, "No Selection", "Please select one or more steps to group.")
            return

        selected_rows = sorted([self.steps_list_widget.row(item) for item in selected_items])
        first_row = selected_rows[0]
        last_row = selected_rows[-1]

        group_name, ok = QInputDialog.getText(self, "Create Group", "Enter a name for the group:")
        if ok and group_name:
            if self.main_window_ref and hasattr(self.main_window_ref, 'group_id_counter'):
                self.main_window_ref.group_id_counter += 1
                group_id = f"group_{self.main_window_ref.group_id_counter}"
            else:
                import time
                group_id = f"group_temp_{int(time.time())}"

            group_start_data = {"type": "group_start", "group_id": group_id, "group_name": group_name}
            group_end_data = {"type": "group_end", "group_id": group_id, "group_name": group_name}
            
            start_list_item = QListWidgetItem()
            start_list_item.setData(Qt.ItemDataRole.UserRole, group_start_data)
            
            end_list_item = QListWidgetItem()
            end_list_item.setData(Qt.ItemDataRole.UserRole, group_end_data)
            
            self.steps_list_widget.insertItem(first_row, start_list_item)
            self.steps_list_widget.insertItem(last_row + 2, end_list_item)
            
            self.populate_list(self.get_current_steps_from_list())
            
    def get_step_identifier(self, step_data: Dict[str, Any]) -> Optional[Tuple[str, str]]:
        """Returns a hashable identifier (tuple) for a block step, or None."""
        step_type = step_data.get("type")

        if step_type in ["group_start", "group_end"]:
            return ("group", step_data.get("group_id"))
        elif step_type in ["loop_start", "loop_end"]:
            return ("loop", step_data.get("loop_id"))
        elif step_type in ["IF_START", "ELSE", "IF_END"]:
            return ("if", step_data.get("if_id"))
        
        return None

    def on_selection_changed(self):
        """Called when list selection changes. Bolds related block parts and enables/disables buttons."""
        
        # --- Update button enabled state ---
        has_selection = len(self.steps_list_widget.selectedItems()) > 0
        self.group_selected_button.setEnabled(has_selection)
        self.delete_selected_button.setEnabled(has_selection)
        self.move_button.setEnabled(has_selection)
        # --- End button update ---

        identifier_to_rows = {}
        for i in range(self.steps_list_widget.count()):
            item = self.steps_list_widget.item(i)
            widget = self.steps_list_widget.itemWidget(item)
            if widget and hasattr(widget, 'set_bold'):
                widget.set_bold(False)
            
            step_data = item.data(Qt.ItemDataRole.UserRole)
            identifier = self.get_step_identifier(step_data)
            
            if identifier and identifier[1]:
                if identifier not in identifier_to_rows:
                    identifier_to_rows[identifier] = []
                identifier_to_rows[identifier].append(i)

        rows_to_bold = set()
        for item in self.steps_list_widget.selectedItems():
            step_data = item.data(Qt.ItemDataRole.UserRole)
            identifier = self.get_step_identifier(step_data)
            if identifier and identifier[1] and identifier in identifier_to_rows:
                rows_to_bold.update(identifier_to_rows[identifier])

        for row in rows_to_bold:
            item = self.steps_list_widget.item(row)
            widget = self.steps_list_widget.itemWidget(item)
            if widget and hasattr(widget, 'set_bold'):
                widget.set_bold(True)
                
    # --- NEW METHOD to handle the precise move logic ---
    def _handle_precise_move(self):
        """Orchestrates the moving of selected steps to a new, specific location."""
        # 1. Input Validation
        target_num_str = self.move_target_input.text()
        if not target_num_str.isdigit():
            QMessageBox.warning(self, "Invalid Input", "Please enter a valid step number.")
            return
            
        target_step_num = int(target_num_str)
        total_steps = self.steps_list_widget.count()
        if not (1 <= target_step_num <= total_steps):
            QMessageBox.warning(self, "Invalid Step Number", f"Please enter a number between 1 and {total_steps}.")
            return

        selected_items = self.steps_list_widget.selectedItems()
        if not selected_items:
            # This should not happen since the button is disabled, but it's good practice
            return

        # 2. Get Data and Indices of Selected Items
        # Store tuples of (original_row, data)
        selected_steps_info = sorted([(self.steps_list_widget.row(item), item.data(Qt.ItemDataRole.UserRole)) for item in selected_items], key=lambda x: x[0])
        
        # Extract just the data in the correct order
        selected_data_to_move = [info[1] for info in selected_steps_info]

        # 3. Remove Selected Items from the List
        # It is crucial to remove items in reverse order to avoid index shifting issues
        for row, _ in reversed(selected_steps_info):
            self.steps_list_widget.takeItem(row)
            
        # Get the current state of the list after removal
        current_steps_data = self.get_current_steps_from_list()

        # 4. Calculate the Target Insertion Index
        # The target_step_num is 1-based, but our list is now smaller.
        # We need to calculate the 0-based index in the *new* list.
        move_mode = self.move_position_combo.currentText()
        
        # Adjust target index to be 0-based
        target_index_0based = target_step_num - 1

        if move_mode == "Before Step #":
            insertion_index = target_index_0based
        else: # "After Step #"
            insertion_index = target_index_0based + 1
            
        # Clamp the insertion index to be within the bounds of the list *after* removal
        insertion_index = max(0, min(insertion_index, len(current_steps_data)))

        # 5. Insert the items at the new location
        # The list comprehension efficiently combines the parts
        new_ordered_steps = (current_steps_data[:insertion_index] + 
                             selected_data_to_move + 
                             current_steps_data[insertion_index:])
        
        # 6. Repopulate the entire list
        # This is the most reliable way to update all visuals and step numbers
        self.populate_list(new_ordered_steps)
        
        # Clear the input for the next use
        self.move_target_input.clear()
class StepInsertionDialog(QDialog):
    def __init__(self, execution_tree: QTreeWidget, parent: Optional[QWidget] = None):
        super().__init__(parent)
        self.setWindowTitle("Insert Step At...")
        self.setFixedSize(600, 800)
        self.layout = QVBoxLayout(self)
        
        self.execution_tree_view = QTreeWidget()
        self.execution_tree_view.setHeaderHidden(True)
        self.execution_tree_view.setSelectionMode(QTreeWidget.SelectionMode.SingleSelection)
        
        self.insertion_mode_group = QGroupBox("Insertion Mode")
        self.insertion_mode_layout = QHBoxLayout()
        
        # SIMPLIFIED: Always enable both before and after
        self.insert_before_radio = QRadioButton("Insert Before Selected")
        self.insert_after_radio = QRadioButton("Insert After Selected")
        
        # Default to "Insert After"
        self.insert_after_radio.setChecked(True)
        
        self.insertion_mode_layout.addWidget(self.insert_before_radio)
        self.insertion_mode_layout.addWidget(self.insert_after_radio)
        self.insertion_mode_group.setLayout(self.insertion_mode_layout)
        
        self.layout.addWidget(QLabel("Select position for new step:"))
        self.layout.addWidget(self.execution_tree_view)
        self.layout.addWidget(self.insertion_mode_group)
        
        self._populate_tree_view(execution_tree)
        
        self.button_box = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        self.button_box.accepted.connect(self.accept)
        self.button_box.rejected.connect(self.reject)
        self.layout.addWidget(self.button_box)
        
        self.selected_parent_item: Optional[QTreeWidgetItem] = None
        self.insert_mode: str = "after"

    def _get_item_data(self, item: QTreeWidgetItem) -> Optional[Dict[str, Any]]:
        if not item: return None
        data = item.data(0, Qt.ItemDataRole.UserRole)
        return data.value() if isinstance(data, QVariant) else data

    def _populate_tree_view(self, source_tree: QTreeWidget):
        self.execution_tree_view.clear()
        self._copy_children(source_tree.invisibleRootItem(), self.execution_tree_view.invisibleRootItem())
        self.execution_tree_view.expandAll()

    def _copy_children(self, source_item: QTreeWidgetItem, dest_item: QTreeWidgetItem):
        for i in range(source_item.childCount()):
            child_source = source_item.child(i)
            card_widget = self.parent().execution_tree.itemWidget(child_source, 0)
            display_text = f"{card_widget.step_label.text()}" if card_widget else ""
            child_dest = QTreeWidgetItem(dest_item, [display_text])
            child_dest.setData(0, Qt.ItemDataRole.UserRole, self._get_item_data(child_source))
            self._copy_children(child_source, child_dest)

    def get_insertion_point(self) -> Tuple[Optional[QTreeWidgetItem], str]:
        self.selected_parent_item = self.execution_tree_view.currentItem()
        if self.insert_before_radio.isChecked(): 
            self.insert_mode = "before"
        else: 
            self.insert_mode = "after"
        return self.selected_parent_item, self.insert_mode


# --- REPLACEMENT CLASS: TemplateVariableMappingDialog (with 'is' variable filtering) ---
# In main_app.py, REPLACE the entire TemplateVariableMappingDialog class

# --- REPLACEMENT CLASS: TemplateVariableMappingDialog (with 'is' variable filtering) ---
class TemplateVariableMappingDialog(QDialog):
    """A dialog to map variables from a template to global variables."""

    def __init__(self, template_variables: set, global_variables: list, parent: Optional[QWidget] = None):
        super().__init__(parent)
        self.setWindowTitle("Map Template Variables")
        self.setMinimumWidth(600)

        # --- THIS IS THE KEY MODIFICATION ---
        # Filter out any template variable that starts with 'is' (case-insensitive).
        # These are typically status flags and not user-configurable inputs.
        filtered_vars = {var for var in template_variables if (not var.lower().startswith('is') and not var.lower().startswith('_') )}
        self.template_variables = sorted(list(filtered_vars))
        # --- END MODIFICATION ---

        self.global_variables = global_variables
        self.mapping_widgets = {}

        main_layout = QVBoxLayout(self)
        
        # If all variables were filtered out, show a message and exit.
        if not self.template_variables:
            # --- THIS IS THE FIX ---
            main_layout.addWidget(QLabel("No configurable variables found in this template. Click OK to proceed."))
            # Add an OK button that accepts the dialog
            button_box = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok) 
            button_box.accepted.connect(self.accept) # Accept the dialog
            main_layout.addWidget(button_box)
            self.setLayout(main_layout)
            return # Stop building the rest of the dialog
            # --- END OF FIX ---

        # Original layout code for when there are variables to map
        form_layout = QFormLayout()

        for var_name in self.template_variables:
            row_layout = QHBoxLayout()
            
            action_combo = QComboBox()
            action_combo.addItems(["Map to Existing", "Create New"])
            
            existing_var_combo = QComboBox()
            existing_var_combo.addItem("-- Select Existing --")
            existing_var_combo.addItems(self.global_variables)
            
            new_var_name_editor = QLineEdit(var_name)
            new_var_name_editor.setPlaceholderText("Variable Name")

            new_var_value_editor = QLineEdit()
            new_var_value_editor.setPlaceholderText("Initial Value (optional)")

            if var_name in self.global_variables:
                action_combo.setCurrentText("Map to Existing")
                existing_var_combo.setCurrentText(var_name)
            else:
                action_combo.setCurrentText("Create New")

            row_layout.addWidget(action_combo, 1)
            row_layout.addWidget(existing_var_combo, 2)
            row_layout.addWidget(new_var_name_editor, 2)
            row_layout.addWidget(new_var_value_editor, 2)
            
            form_layout.addRow(QLabel(f"Template Variable '{var_name}':"), row_layout)

            self.mapping_widgets[var_name] = {
                'action': action_combo,
                'existing': existing_var_combo,
                'new_name': new_var_name_editor,
                'new_value': new_var_value_editor
            }
            
            action_combo.currentIndexChanged.connect(
                lambda index, v=var_name: self._toggle_inputs(v, index)
            )
            self._toggle_inputs(var_name, action_combo.currentIndex())

        main_layout.addLayout(form_layout)
        
        button_box = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        button_box.accepted.connect(self.accept)
        button_box.rejected.connect(self.reject)
        main_layout.addWidget(button_box)
        self.setLayout(main_layout)


    def _toggle_inputs(self, var_name: str, index: int):
        """Shows or hides the input widgets based on the selected action."""
        widgets = self.mapping_widgets[var_name]
        is_mapping_to_existing = (index == 0)
        
        widgets['existing'].setVisible(is_mapping_to_existing)
        widgets['new_name'].setVisible(not is_mapping_to_existing)
        widgets['new_value'].setVisible(not is_mapping_to_existing)

    def get_mapping(self) -> Optional[Tuple[Dict[str, str], Dict[str, Any]]]:
        # If there were no variables to map in the first place, return empty results.
        if not self.template_variables:
            return {}, {}

        mapping = {}
        new_variables = {}
        for var_name, widgets in self.mapping_widgets.items():
            action_index = widgets['action'].currentIndex()
            
            if action_index == 0:  # Map to Existing
                target_var = widgets['existing'].currentText()
                if target_var == "-- Select Existing --":
                    QMessageBox.warning(self, "Input Error", f"Please select an existing variable to map '{var_name}' to.")
                    return None
                mapping[var_name] = target_var
            
            else:  # Create New
                target_var_name = widgets['new_name'].text().strip()
                if not target_var_name:
                    QMessageBox.warning(self, "Input Error", f"The new variable name for '{var_name}' cannot be empty.")
                    return None
                
                mapping[var_name] = target_var_name
                
                if target_var_name not in self.global_variables:
                    initial_value_str = widgets['new_value'].text()

                    if not initial_value_str:
                        new_variables[target_var_name] = None
                    else:
                        try:
                            parsed_value = ast.literal_eval(initial_value_str)
                        except (ValueError, SyntaxError):
                            parsed_value = initial_value_str
                        
                        new_variables[target_var_name] = parsed_value

        return mapping, new_variables

# In the TemplateVariableMappingDialog class, replace the _toggle_inputs method

    def _toggle_inputs(self, var_name: str, index: int):
        """Shows or hides the input widgets based on the selected action."""
        widgets = self.mapping_widgets[var_name]
        is_mapping_to_existing = (index == 0)
        
        widgets['existing'].setVisible(is_mapping_to_existing)
        widgets['new_name'].setVisible(not is_mapping_to_existing)
        widgets['new_value'].setVisible(not is_mapping_to_existing) # --- NEW: Toggle the value editor ---

# In the TemplateVariableMappingDialog class, replace the get_mapping method

    def get_mapping(self) -> Optional[Tuple[Dict[str, str], Dict[str, Any]]]:
        mapping = {}
        new_variables = {}
        for var_name, widgets in self.mapping_widgets.items():
            action_index = widgets['action'].currentIndex()
            
            if action_index == 0:  # Map to Existing
                target_var = widgets['existing'].currentText()
                if target_var == "-- Select Existing --":
                    QMessageBox.warning(self, "Input Error", f"Please select an existing variable to map '{var_name}' to.")
                    return None
                mapping[var_name] = target_var
            
            else:  # Create New
                target_var_name = widgets['new_name'].text().strip()
                if not target_var_name:
                    QMessageBox.warning(self, "Input Error", f"The new variable name for '{var_name}' cannot be empty.")
                    return None
                
                mapping[var_name] = target_var_name
                
                if target_var_name not in self.global_variables:
                    # --- NEW: Get the initial value from the textbox ---
                    initial_value_str = widgets['new_value'].text()

                    # If the textbox is empty, the value will be None
                    if not initial_value_str:
                        new_variables[target_var_name] = None
                    else:
                        # Safely evaluate the string to get Python types (int, float, bool, etc.)
                        try:
                            # ast.literal_eval is a safe way to evaluate simple literals
                            parsed_value = ast.literal_eval(initial_value_str)
                        except (ValueError, SyntaxError):
                            # If it can't be parsed (e.g., just text), treat it as a string
                            parsed_value = initial_value_str
                        
                        new_variables[target_var_name] = parsed_value
                    # --- END NEW ---

        return mapping, new_variables

# --- NEW CLASS: SaveTemplateDialog ---
# --- NEW DIALOG: WaitTimeConfigDialog ---
class WaitTimeConfigDialog(QDialog):
    """A dialog to configure the wait time using a hardcoded value or a global variable."""
    def __init__(self, global_variables: List[str], initial_config: Dict[str, Any], parent: Optional[QWidget] = None):
        super().__init__(parent)
        self.setWindowTitle("Configure Wait Time Between Steps")
        self.setMinimumWidth(400)
        self.global_variables = global_variables
        
        main_layout = QVBoxLayout(self)
        form_layout = QFormLayout()

        # --- Input Mode Selection ---
        self.hardcoded_radio = QRadioButton("Use a fixed number of seconds:")
        self.variable_radio = QRadioButton("Use a Global Variable:")
        
        # --- Input Widgets ---
        self.wait_time_editor = QLineEdit()
        # Use a QDoubleValidator to allow for fractional seconds (e.g., 0.5)
        self.wait_time_editor.setValidator(QtGui.QDoubleValidator(0, 300, 2)) 

        self.global_var_combo = QComboBox()
        self.global_var_combo.addItem("-- Select Variable --")
        self.global_var_combo.addItems(sorted(self.global_variables))

        # --- Layout ---
        form_layout.addRow(self.hardcoded_radio, self.wait_time_editor)
        form_layout.addRow(self.variable_radio, self.global_var_combo)
        main_layout.addLayout(form_layout)

        # --- Buttons ---
        button_box = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        button_box.accepted.connect(self.accept)
        button_box.rejected.connect(self.reject)
        main_layout.addWidget(button_box)
        
        # --- Connections ---
        self.hardcoded_radio.toggled.connect(self._toggle_inputs)
        
        # --- Set Initial State ---
        self.set_config(initial_config)

    def _toggle_inputs(self):
        """Enable/disable input fields based on which radio button is selected."""
        self.wait_time_editor.setEnabled(self.hardcoded_radio.isChecked())
        self.global_var_combo.setEnabled(self.variable_radio.isChecked())

    def set_config(self, config: Dict[str, Any]):
        """Sets the dialog's state from an existing configuration."""
        if config.get('type') == 'variable':
            self.variable_radio.setChecked(True)
            idx = self.global_var_combo.findText(config.get('value', ''))
            if idx != -1:
                self.global_var_combo.setCurrentIndex(idx)
        else: # Default to hardcoded
            self.hardcoded_radio.setChecked(True)
            self.wait_time_editor.setText(str(config.get('value', 0)))
        self._toggle_inputs()

    def get_config(self) -> Optional[Dict[str, Any]]:
        """Returns the new configuration dictionary."""
        if self.hardcoded_radio.isChecked():
            try:
                # Allow floating point numbers for more precision
                value = float(self.wait_time_editor.text())
                if value < 0:
                    raise ValueError
                return {'type': 'hardcoded', 'value': value}
            except (ValueError, TypeError):
                QMessageBox.warning(self, "Input Error", "Please enter a valid non-negative number for the wait time.")
                return None
        elif self.variable_radio.isChecked():
            var_name = self.global_var_combo.currentText()
            if var_name == "-- Select Variable --":
                QMessageBox.warning(self, "Input Error", "Please select a global variable for the wait time.")
                return None
            return {'type': 'variable', 'value': var_name}
        return None
class SaveTemplateDialog(QDialog):
    def __init__(self, existing_templates: List[str], parent: Optional[QWidget] = None):
        super().__init__(parent)
        self.setWindowTitle("Save Step Template")
        self.setMinimumWidth(350)
        
        main_layout = QVBoxLayout(self)
        form_layout = QFormLayout()

        self.info_label = QLabel("Select an existing template to overwrite, or type a new name.")
        
        self.templates_combo = QComboBox()
        self.templates_combo.addItem("-- Create New Template --")
        self.templates_combo.addItems(sorted(existing_templates))

        self.name_editor = QLineEdit()
        self.name_editor.setPlaceholderText("Enter new template name")

        self.templates_combo.currentTextChanged.connect(self._selection_changed)

        form_layout.addRow("Action:", self.templates_combo)
        form_layout.addRow("Template Name:", self.name_editor)

        main_layout.addWidget(self.info_label)
        main_layout.addLayout(form_layout)
        
        button_box = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        button_box.accepted.connect(self.accept)
        button_box.rejected.connect(self.reject)
        main_layout.addWidget(button_box)

        self._selection_changed(self.templates_combo.currentText())

    def _selection_changed(self, text: str) -> None:
        if text == "-- Create New Template --":
            self.name_editor.clear()
            self.name_editor.setEnabled(True)
            self.name_editor.setPlaceholderText("Enter new template name")
        else:
            self.name_editor.setText(text)
            self.name_editor.setEnabled(True)

    def get_template_name(self) -> Optional[str]:
        name = self.name_editor.text().strip()
        # Sanitize name
        sanitized_name = "".join(c for c in name if c.isalnum() or c in (' ', '_')).rstrip()
        if not sanitized_name:
            QMessageBox.warning(self, "Invalid Name", "Template name cannot be empty or contain only invalid characters.")
            return None
        return sanitized_name

# --- NEW CLASS: SaveBotDialog ---
class SaveBotDialog(QDialog):
    def __init__(self, existing_bots: List[str], parent: Optional[QWidget] = None):
        super().__init__(parent)
        self.setWindowTitle("Save Bot Steps")
        self.setMinimumWidth(350)
        
        main_layout = QVBoxLayout(self)
        form_layout = QFormLayout()

        self.info_label = QLabel("Select an existing bot to overwrite, or type a new name.")
        
        self.bots_combo = QComboBox()
        self.bots_combo.addItem("-- Create New Bot --")
        self.bots_combo.addItems(sorted(existing_bots))

        self.name_editor = QLineEdit()
        self.name_editor.setPlaceholderText("Enter new bot name")

        self.bots_combo.currentTextChanged.connect(self._selection_changed)

        form_layout.addRow("Action:", self.bots_combo)
        form_layout.addRow("Bot Name:", self.name_editor)

        main_layout.addWidget(self.info_label)
        main_layout.addLayout(form_layout)
        
        button_box = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        button_box.accepted.connect(self.accept)
        button_box.rejected.connect(self.reject)
        main_layout.addWidget(button_box)

        self._selection_changed(self.bots_combo.currentText())

    def _selection_changed(self, text: str) -> None:
        if text == "-- Create New Bot --":
            self.name_editor.clear()
            self.name_editor.setEnabled(True)
            self.name_editor.setPlaceholderText("Enter new bot name")
        else:
            self.name_editor.setText(text)
            self.name_editor.setEnabled(True)

    def get_bot_name(self) -> Optional[str]:
        name = self.name_editor.text().strip()
        sanitized_name = "".join(c for c in name if c.isalnum() or c in (' ', '_')).rstrip()
        if not sanitized_name:
            QMessageBox.warning(self, "Invalid Name", "Bot name cannot be empty or contain only invalid characters.")
            return None
        return sanitized_name


# In main_app.py, REPLACE your entire GroupedTreeWidget class with this:

class GroupedTreeWidget(QTreeWidget):
    step_reorder_requested = pyqtSignal(int, int)  # NEW SIGNAL
    
    def __init__(self, main_window: 'MainWindow', parent: Optional[QWidget] = None):
        super().__init__(parent)
        self.main_window = main_window
        
        # Enable drag and drop
        self.setAcceptDrops(True)
        self.setDragEnabled(False)  # We handle dragging in cards
        self.setDefaultDropAction(Qt.DropAction.MoveAction)

    def dragEnterEvent(self, event: QtGui.QDragEnterEvent):
        if event.mimeData().hasText():
            event.acceptProposedAction()

    def dragMoveEvent(self, event: QtGui.QDragMoveEvent):
        if event.mimeData().hasText():
            event.acceptProposedAction()
            
            # Provide visual feedback
            item = self.itemAt(event.position().toPoint() if hasattr(event, 'position') else event.pos())
            if item:
                self.setCurrentItem(item)

    def dropEvent(self, event: QtGui.QDropEvent):
        if event.mimeData().hasText():
            source_index = int(event.mimeData().text())
            
            # Calculate target position
            drop_pos = event.position().toPoint() if hasattr(event, 'position') else event.pos()
            target_item = self.itemAt(drop_pos)
            
            if target_item:
                target_card = self.itemWidget(target_item, 0)
                if isinstance(target_card, ExecutionStepCard):
                    target_index = target_card.step_data.get("original_listbox_row_index", -1)
                    
                    # Determine if dropping above or below based on position
                    item_rect = self.visualItemRect(target_item)
                    if drop_pos.y() < item_rect.center().y():
                        # Drop above (before)
                        final_target = target_index
                    else:
                        # Drop below (after)
                        final_target = target_index + 1
                    
                    if source_index != final_target:
                        self.step_reorder_requested.emit(source_index, final_target)
            else:
                # Drop at end
                if source_index < len(self.main_window.added_steps_data):
                    self.step_reorder_requested.emit(source_index, len(self.main_window.added_steps_data))
            
            event.acceptProposedAction()

    def paintEvent(self, event: QtGui.QPaintEvent) -> None:
        # First, run the default paint event to draw all the items.
        super().paintEvent(event)
        
        # Now, draw our custom lines on top.
        painter = QPainter(self.viewport())
        pen = QPen(QColor("#C0392B"))
        pen.setWidth(2)
        painter.setPen(pen)

        self._draw_group_lines_recursive(self.invisibleRootItem(), painter)

    def _draw_group_lines_recursive(self, parent_item: QTreeWidgetItem, painter: QPainter):
        for i in range(parent_item.childCount()):
            child_item = parent_item.child(i)
            
            item_data = self.main_window._get_item_data(child_item)
            
            if (item_data and item_data.get("type") in ["group_start", "loop_start", "IF_START"] and child_item.isExpanded()):
                
                start_index = item_data.get("original_listbox_row_index")
                _ , end_index = self.main_window._find_block_indices(start_index)
                
                end_item = self.main_window.data_to_item_map.get(end_index)
                
                start_rect = self.visualItemRect(child_item)
                
                if end_item and not start_rect.isEmpty():
                    end_rect = self.visualItemRect(end_item)
                    
                    x_offset = 8
                    tick_width = 5
                    start_y = start_rect.center().y()
                    
                    end_y = end_rect.center().y() if not end_rect.isEmpty() else self.viewport().height()

                    if end_y < start_y:
                        continue
                        
                    painter.drawLine(x_offset, start_y, x_offset, end_y)
                    painter.drawLine(x_offset, start_y, x_offset + tick_width, start_y)
                    if not end_rect.isEmpty():
                        painter.drawLine(x_offset, end_y, x_offset + tick_width, end_y)

            if child_item.isExpanded():
                self._draw_group_lines_recursive(child_item, painter)
# --- NEW WIDGET: FindReplaceWidget ---
class FindReplaceWidget(QWidget):
    """A widget for find and replace functionality."""
    def __init__(self, editor):
        super().__init__()
        self.editor = editor
        self.init_ui()

    def init_ui(self):
        main_layout = QVBoxLayout(self)
        main_layout.setContentsMargins(0, 5, 0, 5)

        find_layout = QHBoxLayout()
        self.find_input = QLineEdit()
        self.find_input.setPlaceholderText("Find")
        self.find_input.textChanged.connect(self.update_editor_selection)
        
        self.next_button = QPushButton("Next")
        self.prev_button = QPushButton("Previous")
        
        find_layout.addWidget(QLabel("Find:"))
        find_layout.addWidget(self.find_input)
        find_layout.addWidget(self.next_button)
        find_layout.addWidget(self.prev_button)
        
        replace_layout = QHBoxLayout()
        self.replace_input = QLineEdit()
        self.replace_input.setPlaceholderText("Replace with")
        
        self.replace_button = QPushButton("Replace")
        self.replace_all_button = QPushButton("Replace All")

        replace_layout.addWidget(QLabel("Replace:"))
        replace_layout.addWidget(self.replace_input)
        replace_layout.addWidget(self.replace_button)
        replace_layout.addWidget(self.replace_all_button)

        options_layout = QHBoxLayout()
        self.case_sensitive_check = QCheckBox("Case Sensitive")
        options_layout.addWidget(self.case_sensitive_check)
        options_layout.addStretch()

        main_layout.addLayout(find_layout)
        main_layout.addLayout(replace_layout)
        main_layout.addLayout(options_layout)

    def update_editor_selection(self):
        """Highlights all occurrences of the find text in the editor."""
        text = self.find_input.text()
        if not text:
            self.editor.setExtraSelections([])
            return

        selections = []
        cursor = self.editor.document().find(text, 0, self.get_find_flags())
        while not cursor.isNull():
            selection = QTextEdit.ExtraSelection()
            selection.format.setBackground(QColor("cyan"))
            selection.cursor = cursor
            selections.append(selection)
            cursor = self.editor.document().find(text, cursor, self.get_find_flags())
        
        self.editor.setExtraSelections(selections)

    def get_find_flags(self):
        """Returns the appropriate find flags based on UI options."""
        flags = QTextDocument.FindFlag(0)
        if self.case_sensitive_check.isChecked():
            flags |= QTextDocument.FindFlag.FindCaseSensitively
        return flags

# --- NEW CLASS: HtmlViewerDialog ---
class HtmlViewerDialog(QDialog):
    """A dialog to display HTML content."""
    def __init__(self, file_path: str, parent: Optional[QWidget] = None):
        super().__init__(parent)
        self.setWindowTitle(f"Documentation: {os.path.basename(file_path)}")
        self.setGeometry(200, 200, 800, 600)

        main_layout = QVBoxLayout(self)

        self.text_browser = QTextBrowser()
        self.text_browser.setOpenExternalLinks(True) # Allow opening links in a web browser
        main_layout.addWidget(self.text_browser)

        button_box = QDialogButtonBox(QDialogButtonBox.StandardButton.Close)
        button_box.rejected.connect(self.reject)
        main_layout.addWidget(button_box)

        self.load_html(file_path)

    def load_html(self, file_path: str):
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                html_content = f.read()
                self.text_browser.setHtml(html_content)
        except Exception as e:
            self.text_browser.setPlainText(f"Error loading documentation file:\n{e}")
            
# REPLACE the entire ScheduleTaskDialog class with this one:

# REPLACE the entire ScheduleTaskDialog class with this one:

class ScheduleTaskDialog(QDialog):
    """A dialog for scheduling bot execution."""
    def __init__(self, bot_name: str, schedule_data: Optional[Dict[str, Any]] = None, parent: Optional[QWidget] = None):
        super().__init__(parent)
        self.setWindowTitle(f"Schedule Task for '{bot_name}'")
        self.setMinimumWidth(450)

        self.layout = QFormLayout(self)

        self.enable_checkbox = QCheckBox("Enable Schedule")
        self.layout.addRow(self.enable_checkbox)

        self.date_edit = QDateTimeEdit(QDateTime.currentDateTime())
        self.date_edit.setCalendarPopup(True)
        self.layout.addRow("Start Date and Time:", self.date_edit)

        self.repeat_combo = QComboBox()
        self.repeat_combo.addItems([
            "Do not repeat", 
            "Every 5 minutes",
            "Every 15 minutes",
            "Every 30 minutes",
            "Hourly", 
            "Daily", 
            "Monthly"
                    ])
        self.layout.addRow("Repeat:", self.repeat_combo)

        # --- Days of Week Group ---
        self.days_of_week_group = QGroupBox("Run on Specific Days")
        days_layout = QHBoxLayout()
        self.day_checkboxes = {}
        for day in ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]:
            cb = QCheckBox(day)
            self.day_checkboxes[day] = cb
            days_layout.addWidget(cb)
        self.days_of_week_group.setLayout(days_layout)
        self.layout.addRow(self.days_of_week_group)

        # --- Time Boundary Group ---
        self.time_boundary_group = QGroupBox("Time Boundary")
        time_boundary_form_layout = QFormLayout()
        
        self.enable_time_boundary_check = QCheckBox("Only run between specific times")
        time_boundary_form_layout.addRow(self.enable_time_boundary_check)
        
        self.start_time_edit = QTimeEdit(QTime(8, 0))
        self.end_time_edit = QTimeEdit(QTime(17, 0))
        
        time_boundary_form_layout.addRow("Start Time:", self.start_time_edit)
        time_boundary_form_layout.addRow("End Time:", self.end_time_edit)
        
        self.time_boundary_group.setLayout(time_boundary_form_layout)
        self.layout.addRow(self.time_boundary_group)

        # --- NEW: Email Notification Group ---
        self.email_group = QGroupBox("Email Notification (via Outlook)")
        self.email_group.setCheckable(True) # Makes the whole group enable/disable
        email_form_layout = QFormLayout()

        self.email_input = QLineEdit()
        self.email_input.setPlaceholderText("e.g., user.name@example.com")
        email_form_layout.addRow("Recipient Email:", self.email_input)

        self.notify_on_error_check = QCheckBox("Notify on Error")
        self.notify_on_success_check = QCheckBox("Notify on Success")
        email_form_layout.addRow("Send When:", self.notify_on_error_check)
        email_form_layout.addRow("", self.notify_on_success_check)
        
        self.email_group.setLayout(email_form_layout)
        self.layout.addRow(self.email_group)
        # --- END NEW ---

        # --- Buttons ---
        self.buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        self.buttons.accepted.connect(self.accept)
        self.buttons.rejected.connect(self.reject)
        self.layout.addRow(self.buttons)

        # --- Connections for new widgets ---
        self.repeat_combo.currentTextChanged.connect(self._update_widget_visibility)
        self.enable_time_boundary_check.toggled.connect(self._update_widget_visibility)
        self.enable_checkbox.toggled.connect(self._update_widget_visibility)

        # --- Load existing data ---
        if schedule_data:
            self.load_schedule_data(schedule_data)
        else:
            # Set sensible defaults for a new schedule
            self.email_group.setChecked(False)
            self.notify_on_error_check.setChecked(True)

        # --- Initial visibility update ---
        self._update_widget_visibility()


    def _update_widget_visibility(self):
        """Shows/hides the groups based on user selection."""
        is_schedule_enabled = self.enable_checkbox.isChecked()
        
        # All scheduling options are only visible if the schedule is enabled
        self.date_edit.setVisible(is_schedule_enabled)
        self.repeat_combo.setVisible(is_schedule_enabled)
        
        repeat_mode = self.repeat_combo.currentText()
        
        # --- THIS IS THE KEY CHANGE ---
        # Show day/time controls for all repeating schedules except "Monthly"
        is_repeating_on_schedule = repeat_mode not in ["Do not repeat", "Monthly"] and is_schedule_enabled
        self.days_of_week_group.setVisible(is_repeating_on_schedule)
        self.time_boundary_group.setVisible(is_repeating_on_schedule)
        # --- END OF KEY CHANGE ---
        
        time_boundary_enabled = self.enable_time_boundary_check.isChecked()
        self.start_time_edit.setEnabled(time_boundary_enabled)
        self.end_time_edit.setEnabled(time_boundary_enabled)

        # Email group is only visible if the schedule is enabled
        self.email_group.setVisible(is_schedule_enabled)

    def load_schedule_data(self, schedule_data: Dict[str, Any]):
        """Loads data into the dialog's widgets."""
        self.enable_checkbox.setChecked(schedule_data.get("enabled", False))
        
        start_datetime_str = schedule_data.get("start_datetime")
        if start_datetime_str:
            self.date_edit.setDateTime(QDateTime.fromString(start_datetime_str, Qt.DateFormat.ISODate))
        
        repeat_str = schedule_data.get("repeat")
        if repeat_str:
            index = self.repeat_combo.findText(repeat_str, Qt.MatchFlag.MatchFixedString)
            if index >= 0: self.repeat_combo.setCurrentIndex(index)

        selected_days = schedule_data.get("selected_days", [])
        for day, cb in self.day_checkboxes.items():
            cb.setChecked(day in selected_days)

        self.enable_time_boundary_check.setChecked(schedule_data.get("time_boundary_enabled", False))
        
        start_time_str = schedule_data.get("start_time", "08:00:00")
        self.start_time_edit.setTime(QTime.fromString(start_time_str, Qt.DateFormat.ISODate))
        
        end_time_str = schedule_data.get("end_time", "17:00:00")
        self.end_time_edit.setTime(QTime.fromString(end_time_str, Qt.DateFormat.ISODate))

        # Load new email properties
        self.email_group.setChecked(schedule_data.get("email_notification_enabled", False))
        self.email_input.setText(schedule_data.get("recipient_email", ""))
        self.notify_on_error_check.setChecked(schedule_data.get("notify_on_error", True))
        self.notify_on_success_check.setChecked(schedule_data.get("notify_on_success", False))

    def get_schedule_data(self) -> Optional[Dict[str, Any]]:
        """Returns the schedule data from the dialog, including new email properties."""
        
        # --- NEW: Validate email if notifications are enabled ---
        if self.email_group.isChecked():
            email = self.email_input.text().strip()
            if not email:
                QMessageBox.warning(self, "Input Error", "Please enter a recipient email address for notifications.")
                return None
            if not ("@" in email and "." in email):
                QMessageBox.warning(self, "Input Error", f"'{email}' is not a valid email address.")
                return None

        selected_days = [day for day, cb in self.day_checkboxes.items() if cb.isChecked()]
        
        return {
            "enabled": self.enable_checkbox.isChecked(),
            "start_datetime": self.date_edit.dateTime().toString(Qt.DateFormat.ISODate),
            "repeat": self.repeat_combo.currentText(),
            "selected_days": selected_days,
            "time_boundary_enabled": self.enable_time_boundary_check.isChecked(),
            "start_time": self.start_time_edit.time().toString(Qt.DateFormat.ISODate),
            "end_time": self.end_time_edit.time().toString(Qt.DateFormat.ISODate),
            # Add new email properties
            "email_notification_enabled": self.email_group.isChecked(),
            "recipient_email": self.email_input.text().strip(),
            "notify_on_error": self.notify_on_error_check.isChecked(),
            "notify_on_success": self.notify_on_success_check.isChecked()
        }
class UpdateDialog(QDialog):
    def __init__(self, update_dir, target_folder, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Update Application")
        self.resize(800, 600)

        # update_dir is the root extraction folder (e.g., "update/")
        # target_folder is the app's base directory
        self.update_dir_root = update_dir 
        self.target_folder = target_folder
        
        # This is the new logic: find the *actual* source of the files
        self.update_source_folder = self._find_update_source_folder(update_dir)

        self.layout = QVBoxLayout(self)

        self.tree = QTreeWidget()
        self.tree.setHeaderLabels(["File", "Status"])
        self.tree.setColumnWidth(0, 500)
        self.layout.addWidget(self.tree)

        # Button Layout
        button_layout = QHBoxLayout()
        self.select_all_btn = QPushButton("Select All")
        self.select_all_btn.clicked.connect(self.select_all)
        button_layout.addWidget(self.select_all_btn)

        self.deselect_all_btn = QPushButton("Deselect All")
        self.deselect_all_btn.clicked.connect(self.deselect_all)
        button_layout.addWidget(self.deselect_all_btn)

        button_layout.addStretch() # Add space between button groups

        self.update_button = QPushButton("Update Selected Files")
        self.update_button.clicked.connect(self.update_files)
        button_layout.addWidget(self.update_button)

        self.cancel_button = QPushButton("Cancel")
        self.cancel_button.clicked.connect(self.reject) # Closes the dialog
        button_layout.addWidget(self.cancel_button)
        
        self.layout.addLayout(button_layout)

        if self.update_source_folder is None:
             QMessageBox.critical(self, "Update Error", "Could not find 'main_app.py' in the extracted update files. The update file may be corrupt or in an unrecognized format.")
        else:
            self.populate_tree()

    def _find_update_source_folder(self, update_dir):
        """
        Determines the correct source folder for the update files.
        This handles both "flat" zips and "Repo-main" nested zips.
        """
        # Case 1: "Flat" zip (main_app.py is directly in update_dir)
        if os.path.exists(os.path.join(update_dir, "main_app.py")):
            return update_dir

        # Case 2: "Nested" zip (e.g., AutomateTask-main/main_app.py)
        # Look for sub-directories
        try:
            sub_items = os.listdir(update_dir)
        except FileNotFoundError:
            return None # update_dir doesn't exist

        potential_dirs = [d for d in sub_items if os.path.isdir(os.path.join(update_dir, d))]
        
        for dir_name in potential_dirs:
            potential_path = os.path.join(update_dir, dir_name)
            if os.path.exists(os.path.join(potential_path, "main_app.py")):
                # This is our source folder
                return potential_path
        
        # Case 3: Could not find it
        return None

    def _set_all_items_checked_state(self, state):
        """Helper function to set the check state of all items."""
        iterator = QTreeWidgetItemIterator(self.tree)
        while iterator.value():
            item = iterator.value()
            item.setCheckState(0, state)
            iterator += 1

    def select_all(self):
        self._set_all_items_checked_state(Qt.CheckState.Checked)

    def deselect_all(self):
        self._set_all_items_checked_state(Qt.CheckState.Unchecked)

    def populate_tree(self):
        if self.update_source_folder is None:
            return

        for root, _, files in os.walk(self.update_source_folder):
            
            for file in files:
                update_path = os.path.join(root, file)
                # Get relpath from the *source* folder
                relative_path = os.path.relpath(update_path, self.update_source_folder)
                
                # Exclude .git files/folders
                if ".git" in relative_path.split(os.sep):
                    continue

                target_path = os.path.join(self.target_folder, relative_path)

                status = "New"
                if os.path.exists(target_path):
                    status = "Overwrite"

                self.add_tree_item(relative_path, status)

    def add_tree_item(self, path, status):
        parent_item = self.tree.invisibleRootItem()
        parts = path.split(os.sep)
        for i, part in enumerate(parts):
            is_file = i == len(parts) - 1
            item = self.find_item(parent_item, part)
            if item is None:
                item = QTreeWidgetItem(parent_item, [part, ""])
                item.setFlags(item.flags() | Qt.ItemFlag.ItemIsUserCheckable)
                item.setCheckState(0, Qt.CheckState.Unchecked)
                if not is_file:
                     item.setText(1, "Folder")
                else:
                    item.setText(1, status)
            parent_item = item

    def find_item(self, parent, text):
        for i in range(parent.childCount()):
            child = parent.child(i)
            if child.text(0) == text:
                return child
        return None

    def update_files(self):
        checked_items = self.get_checked_items()
        if not checked_items:
            QMessageBox.information(self, "No Files Selected", "Please select files to update.")
            return
            
        for item_path in checked_items:
            # Use self.update_source_folder as the base
            source_path = os.path.join(self.update_source_folder, item_path)
            dest_path = os.path.join(self.target_folder, item_path)
            
            if not os.path.exists(source_path):
                print(f"Warning: Source file not found, skipping: {source_path}")
                continue

            os.makedirs(os.path.dirname(dest_path), exist_ok=True)
            shutil.copy2(source_path, dest_path)
            
        QMessageBox.information(self, "Update Complete", "Selected files have been updated.")
        self.accept()

    def get_checked_items(self):
        checked = []
        root = self.tree.invisibleRootItem()
        self.get_checked_recursive(root, "", checked)
        return checked

    def get_checked_recursive(self, item, base_path, checked_list):
        for i in range(item.childCount()):
            child = item.child(i)
            current_path = os.path.join(base_path, child.text(0))
            if child.checkState(0) == Qt.CheckState.Checked:
                if child.childCount() == 0:  # It's a file
                    checked_list.append(current_path)
                else: # It's a folder
                    self.get_all_children(child, current_path, checked_list)
            else:
                self.get_checked_recursive(child, current_path, checked_list)

    def get_all_children(self, item, base_path, all_children_list):
        for i in range(item.childCount()):
            child = item.child(i)
            child_path = os.path.join(base_path, child.text(0))
            if child.childCount() == 0:
                all_children_list.append(child_path)
            else:
                self.get_all_children(child, child_path, all_children_list)

# In main_app.py
# REPLACE the entire WorkflowCanvas class with this:

# In main_app.py
# REPLACE the entire WorkflowCanvas class with this enhanced version:

class WorkflowCanvas(QWidget):
    """A custom widget that draws the bot's workflow with smart layout and navigation."""
    execute_step_requested = pyqtSignal(dict)
    def __init__(self, workflow_tree: List[Dict[str, Any]], main_window, parent: Optional[QWidget] = None):
        super().__init__(parent)
        self.workflow_tree = workflow_tree
        self.main_window = main_window

        # (rect, text, shape, step_data)
        self.nodes: List[Tuple[QRect, str, str, Dict[str, Any]]] = [] 
        # --- NEW: Hotspot for collapse/expand icons ---
        # (rect, group_id)
        self.icon_hotspots: List[Tuple[QRect, str]] = []
        
        self.edges: List[Tuple[Optional[str], Tuple[int, str], Tuple[int, str]]] = []
        self.merge_lines: List[Tuple[int, int]] = []
        
        # Smart layout parameters
        self.NODE_WIDTH = 320
        self.NODE_HEIGHT = 80
        self.V_SPACING = 40
        self.H_SPACING = 220
        self.GRID_SIZE = 20
        
        # Canvas navigation
        self.canvas_offset = QPoint(0, 0)
        self.dragging_canvas = False
        self.last_pan_point = QPoint()
        
        self.total_width = 0
        self.total_height = 0

        self.dragging_node_index: Optional[int] = None
        self.drag_offset: QPoint = QPoint()
        self.setMouseTracking(True)
        
        # Auto-layout on initialization
        self._smart_redraw_layout()
        self._adjust_canvas_size()
        self.setSizePolicy(QSizePolicy.Policy.MinimumExpanding, QSizePolicy.Policy.MinimumExpanding)

        
    def _is_group_expanded(self, group_id: str) -> bool:
        """Checks the main window's state to see if a group is expanded."""
        # Default to expanded if not found
        return self.main_window.group_expansion_states.get(group_id, False)

    def _smart_redraw_layout(self):
        """Enhanced smart redraw that ensures proper sizing after layout."""
        # Clear existing user positions to force smart layout
        self._clear_all_user_positions()
        
        # Clear existing layout
        self.nodes.clear()
        self.edges.clear()
        self.merge_lines.clear()
        self.icon_hotspots.clear() # <<< ADD THIS LINE
        
        # Calculate optimal starting position (centered at top)
        canvas_center_x = max(800, self.width()) // 2
        start_x = canvas_center_x - self.NODE_WIDTH // 2
        start_y = 30
        
        # Build the new layout
        self._build_smart_layout(start_x, start_y)
        
        # Center the workflow vertically if it fits in view
        self._center_workflow_if_possible()
        
        # IMPORTANT: Force size recalculation after layout is complete
        self._adjust_canvas_size()
        
        self.update()
# In main_app.py, inside the WorkflowCanvas class

# In main_app.py, inside the WorkflowCanvas class
# REPLACE the entire render_to_pixmap method with this one:

    def render_to_pixmap(self) -> QPixmap:
        """
        Renders the entire workflow canvas, including off-screen content, to a QPixmap.
        [CORRECTED VERSION]
        """
        if not self.nodes:
            # If there are no nodes, return an empty pixmap
            return QPixmap(1, 1)

        # 1. Calculate the bounding box of all nodes to determine the required size
        min_x = min(r.left() for r, _, _, _ in self.nodes)
        min_y = min(r.top() for r, _, _, _ in self.nodes)
        max_x = max(r.right() for r, _, _, _ in self.nodes)
        max_y = max(r.bottom() for r, _, _, _ in self.nodes)

        # 2. Add padding around the content
        padding = 50
        content_width = max_x - min_x + (2 * padding)
        content_height = max_y - min_y + (2 * padding)

        # 3. Create a QPixmap with the calculated size
        pixmap = QPixmap(int(content_width), int(content_height))
        pixmap.fill(Qt.GlobalColor.white) # Set a white background

        # 4. Create a QPainter to draw on the pixmap
        painter = QPainter(pixmap)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing) # Ensure smooth rendering

        # --- THIS IS THE CRITICAL FIX ---
        # 5. Store the current canvas offset and temporarily set it to a special value
        #    that aligns the content within the pixmap.
        original_offset = self.canvas_offset
        self.canvas_offset = QPoint(-min_x + padding, -min_y + padding)

        # 6. Use the widget's own `render` method. This is the correct way to
        #    paint a widget's contents onto a different paint device (our pixmap).
        #    It correctly uses the widget's paintEvent logic.
        self.render(painter)

        # 7. Restore the original canvas offset for the on-screen display
        self.canvas_offset = original_offset
        # --- END OF CRITICAL FIX ---

        # 8. End painting
        painter.end()

        return pixmap
    def _clear_all_user_positions(self):
        """Removes all user-defined positions to allow smart auto-layout."""
        def clear_positions_recursive(nodes: List[Dict]):
            for node in nodes:
                step_data = node['step_data']
                if "workflow_pos" in step_data:
                    del step_data["workflow_pos"]
                    
                clear_positions_recursive(node.get('children', []))
                clear_positions_recursive(node.get('false_children', []))
                
                if node.get('end_node'):
                    end_step_data = node['end_node']['step_data']
                    if "workflow_pos" in end_step_data:
                        del end_step_data["workflow_pos"]
        
        clear_positions_recursive(self.workflow_tree)
        
    def _build_smart_layout(self, start_x: int, start_y: int):
        """Builds the layout with smart spacing and positioning."""
        self._recursive_smart_layout(self.workflow_tree, start_x, start_y, -1)
        
    def _center_workflow_if_possible(self):
        """Centers the workflow vertically in the canvas if it fits."""
        if not self.nodes:
            return
            
        # Find the bounds of all nodes
        min_y = min(rect.y() for rect, _, _, _ in self.nodes)
        max_y = max(rect.bottom() for rect, _, _, _ in self.nodes)
        workflow_height = max_y - min_y
        
        available_height = self.height()
        if workflow_height < available_height:
            # Center vertically
            offset_y = (available_height - workflow_height) // 2 - min_y
            if offset_y > 0:
                # Move all nodes down by offset_y
                new_nodes = []
                for rect, text, shape, step_data in self.nodes:
                    new_rect = QRect(rect.x(), rect.y() + offset_y, rect.width(), rect.height())
                    step_data["workflow_pos"] = (new_rect.x(), new_rect.y())
                    new_nodes.append((new_rect, text, shape, step_data))
                self.nodes = new_nodes
    
    # --- THIS IS THE MAIN LOGIC CHANGE ---
    def _recursive_smart_layout(self, nodes: List[Dict], x: int, y: int, 
                               last_node_idx: int) -> Tuple[int, int, int]:
        """Enhanced smart recursive layout that handles collapsed groups."""
        current_y = y
        last_node_idx_in_level = last_node_idx
        max_x = x

        for node in nodes:
            step_data = node['step_data']
            step_type = step_data.get("type")

            current_step_num = step_data.get("original_listbox_row_index", -1) + 1
            text = self._get_node_text(step_data, current_step_num)
            
            node_shape = self._get_node_shape(step_type)
            
            # --- NEW LOGIC FOR HANDLING GROUPS ---
            if step_type == "group_start":
                group_id = step_data.get("group_id")
                # Check if the group should be drawn expanded or collapsed
                if self._is_group_expanded(group_id):
                    # --- DRAW EXPANDED (existing logic, but now we add an icon) ---
                    node_y = current_y
                    node_idx = len(self.nodes)
                    
                    rect = QRect(int(x), int(node_y), int(self.NODE_WIDTH), int(self.NODE_HEIGHT))
                    self.nodes.append((rect, text, node_shape, step_data))
                    step_data["workflow_pos"] = (int(x), int(node_y))
                    
                    # Add icon hotspot for the [-] icon
                    icon_rect = QRect(rect.x() + 5, rect.y() + 5, 15, 15)
                    self.icon_hotspots.append((icon_rect, group_id))

                    if last_node_idx_in_level != -1:
                        self.edges.append((None, (last_node_idx_in_level, "bottom"), (node_idx, "top")))
                    
                    # Recursively layout children
                    children = node.get('children', [])
                    child_y, last_child_idx, child_max_x = self._recursive_smart_layout(children, x, current_y + self.NODE_HEIGHT + self.V_SPACING, node_idx)
                    current_y = child_y
                    max_x = max(max_x, child_max_x)

                    # Layout the group_end node
                    end_node_data = node.get('end_node')
                    if end_node_data:
                        end_step_num = end_node_data['step_data'].get("original_listbox_row_index", -1) + 1
                        end_text = self._get_node_text(end_node_data['step_data'], end_step_num)
                        
                        end_y = current_y
                        end_x = x
                        
                        end_rect = QRect(int(end_x), int(end_y), int(self.NODE_WIDTH), int(self.NODE_HEIGHT))
                        end_node_data['step_data']["workflow_pos"] = (int(end_x), int(end_y))
                        
                        end_node_idx = len(self.nodes)
                        self.nodes.append((end_rect, end_text, "rect_gray", end_node_data['step_data']))
                        
                        if last_child_idx != -1:
                            self.edges.append((None, (last_child_idx, "bottom"), (end_node_idx, "top")))
                        else: # Group is empty
                            self.edges.append((None, (node_idx, "bottom"), (end_node_idx, "top")))
                        
                        last_node_idx_in_level = end_node_idx
                        current_y = end_y + self.NODE_HEIGHT + self.V_SPACING
                    else:
                        last_node_idx_in_level = last_child_idx
                else:
                    # --- DRAW COLLAPSED (new logic) ---
                    node_y = current_y
                    node_idx = len(self.nodes)
                    
                    rect = QRect(int(x), int(node_y), int(self.NODE_WIDTH), int(self.NODE_HEIGHT))
                    self.nodes.append((rect, text, node_shape, step_data))
                    step_data["workflow_pos"] = (int(x), int(node_y))

                    # Add icon hotspot for the [+] icon
                    icon_rect = QRect(rect.x() + 5, rect.y() + 5, 15, 15)
                    self.icon_hotspots.append((icon_rect, group_id))

                    if last_node_idx_in_level != -1:
                        self.edges.append((None, (last_node_idx_in_level, "bottom"), (node_idx, "top")))

                    last_node_idx_in_level = node_idx
                    current_y += self.NODE_HEIGHT + self.V_SPACING
                    max_x = max(max_x, x + self.NODE_WIDTH)

                continue # Skip to the next node in the main loop
            # --- END OF NEW GROUP LOGIC ---

            elif step_type in ["IF_START", "loop_start"]:
                node_y = current_y
                node_idx = len(self.nodes)
                
                rect = QRect(int(x), int(node_y), int(self.NODE_WIDTH), int(self.NODE_HEIGHT))
                self.nodes.append((rect, text, node_shape, step_data))
                step_data["workflow_pos"] = (int(x), int(node_y))
                
                if last_node_idx_in_level != -1:
                    self.edges.append((None, (last_node_idx_in_level, "bottom"), (node_idx, "top")))

                true_children = node.get('children', [])
                false_children = node.get('false_children', [])
                end_node_data = node.get('end_node')
                
                branch_start_y = node_y + self.NODE_HEIGHT + self.V_SPACING
                
                if true_children and false_children:
                    true_x = int(x - (self.H_SPACING * 1.5))
                    false_x = int(x + (self.H_SPACING * 1.2))
                elif true_children:
                    true_x = int(x - (self.H_SPACING * 0.3))
                    false_x = x
                else:
                    true_x, false_x = x, x
                
                first_true_node_idx = len(self.nodes)
                true_y_end, last_true_node_idx, true_max_x = self._recursive_smart_layout(true_children, true_x, branch_start_y, -1)
                
                if true_children:
                    true_label = "True" if step_type == "IF_START" else "Loop Body"
                    true_port = "left" if step_type == "IF_START" and false_children else "bottom"
                    self.edges.append((true_label, (node_idx, true_port), (first_true_node_idx, "top")))

                false_y_end, last_false_node_idx, false_max_x = branch_start_y, -1, false_x
                
                if step_type == "IF_START" and false_children:
                    first_false_node_idx = len(self.nodes)
                    false_y_end, last_false_node_idx, false_max_x = self._recursive_smart_layout(false_children, false_x, branch_start_y, -1)
                    self.edges.append(("False", (node_idx, "right"), (first_false_node_idx, "top")))

                if end_node_data:
                    end_step_num = end_node_data['step_data'].get("original_listbox_row_index", -1) + 1
                    end_text = self._get_node_text(end_node_data['step_data'], end_step_num)
                    
                    end_y = max(true_y_end, false_y_end) + self.V_SPACING
                    end_x = x
                    
                    end_node_rect = QRect(int(end_x), int(end_y), int(self.NODE_WIDTH), int(self.NODE_HEIGHT))
                    end_node_data['step_data']["workflow_pos"] = (int(end_x), int(end_y))
                    
                    end_node_idx = len(self.nodes)
                    end_node_shape = self._get_node_shape("IF_END" if step_type == "IF_START" else "loop_end")
                    self.nodes.append((end_node_rect, end_text, end_node_shape, end_node_data['step_data']))
                    
                    if last_true_node_idx != -1: self.merge_lines.append((last_true_node_idx, end_node_idx))
                    if last_false_node_idx != -1: self.merge_lines.append((last_false_node_idx, end_node_idx))
                    
                    if step_type == "loop_start": self.edges.append(("Loop Again", (end_node_idx, "right"), (node_idx, "top")))

                    last_node_idx_in_level = end_node_idx
                    current_y = end_y + self.NODE_HEIGHT + self.V_SPACING
                else:
                    current_y = max(true_y_end, false_y_end)
                    if last_true_node_idx != -1: last_node_idx_in_level = last_true_node_idx
                
                max_x = max(max_x, true_max_x, false_max_x)
                
            else: # Regular step
                current_node_idx = len(self.nodes)
                rect = QRect(int(x), int(current_y), int(self.NODE_WIDTH), int(self.NODE_HEIGHT))
                step_data["workflow_pos"] = (int(x), int(current_y))
                
                self.nodes.append((rect, text, node_shape, step_data))
                
                if last_node_idx_in_level != -1:
                    self.edges.append((None, (last_node_idx_in_level, "bottom"), (current_node_idx, "top")))
                
                last_node_idx_in_level = current_node_idx
                current_y += self.NODE_HEIGHT + self.V_SPACING
                max_x = max(max_x, x + self.NODE_WIDTH)
            
            self.total_height = max(self.total_height, current_y)

        self.total_width = max(self.total_width, max_x)
        return current_y, last_node_idx_in_level, max_x

    def _get_node_shape(self, step_type: str) -> str:
        """Returns the appropriate shape for a given step type."""
        if step_type == "IF_START":
            return "diamond"
        elif step_type in ["loop_start", "loop_end"]:
            return "loop_rect"
        elif step_type in ["ELSE", "IF_END", "group_end"]: # group_end is now gray
            return "rect_gray"
        elif step_type == "group_start":
            return "rect_group"
        else:
            return "rect"
        
    def _draw_grid(self, painter: QPainter):
        """Draws a subtle grid."""
        pen = QPen(QColor("#F0F0F0"))
        pen.setStyle(Qt.PenStyle.DotLine)
        painter.setPen(pen)
        
        offset_x = self.canvas_offset.x() % self.GRID_SIZE
        offset_y = self.canvas_offset.y() % self.GRID_SIZE
        
        width, height = self.width(), self.height()
        
        for x in range(-offset_x, width, self.GRID_SIZE): painter.drawLine(x, 0, x, height)
        for y in range(-offset_y, height, self.GRID_SIZE): painter.drawLine(0, y, width, y)

    def wheelEvent(self, event: QtGui.QWheelEvent):
        """Enhanced wheel event with better zoom and pan."""
        if event.modifiers() == Qt.KeyboardModifier.ControlModifier:
            delta = event.angleDelta().y()
            zoom_factor = 1.15 if delta > 0 else (1 / 1.15)
            self._scale_layout(zoom_factor, event.position())
            self._adjust_canvas_size()
            self.update()
            event.accept()
        else:
            delta = event.angleDelta().y()
            pan_speed = 30
            if event.modifiers() == Qt.KeyboardModifier.ShiftModifier:
                self.canvas_offset.setX(self.canvas_offset.x() + (pan_speed if delta > 0 else -pan_speed))
            else:
                self.canvas_offset.setY(self.canvas_offset.y() + (pan_speed if delta > 0 else -pan_speed))
            self.update()
            event.accept()

# In main_app.py, inside the WorkflowCanvas class
# REPLACE this method:

    def mousePressEvent(self, event: QtGui.QMouseEvent):
        if event.button() == Qt.MouseButton.LeftButton:
            clicked_pos = event.pos() - self.canvas_offset
            
            # --- NEW AND CORRECTED LOGIC ---
            # 1. Check for icon click first
            for hotspot_rect, group_id in self.icon_hotspots:
                if hotspot_rect.contains(clicked_pos):
                    # 2. Toggle the group's expansion state in the main window
                    current_state = self.main_window.group_expansion_states.get(group_id, True)
                    self.main_window.group_expansion_states[group_id] = not current_state
                    
                    # 3. Tell the main window to perform a full redraw of the workflow tab
                    self.main_window._update_workflow_tab(switch_to_tab=True)
                    self.main_window._save_workflow_to_temp_file()

                    # 4. Schedule the centering action to run *after* the redraw is complete.
                    # The timer is crucial for allowing the UI to stabilize.
                    def center_on_group_after_redraw():
                        # This calls the *new* centering method in MainWindow
                        self.main_window._center_canvas_on_group(group_id)

                    QTimer.singleShot(150, center_on_group_after_redraw)
                    
                    return # Stop further processing; this was an icon click.
            # --- END OF CORRECTED LOGIC ---

            # The rest of the method for node dragging and canvas panning remains unchanged
            node_clicked = False
            for i in range(len(self.nodes) - 1, -1, -1):
                rect, _, _, _ = self.nodes[i]
                if rect.contains(clicked_pos):
                    self.dragging_node_index = i
                    self.drag_offset = clicked_pos - rect.topLeft()
                    self.setCursor(Qt.CursorShape.ClosedHandCursor)
                    node = self.nodes.pop(i)
                    self.nodes.append(node)
                    self._remap_edges_for_drag(i, len(self.nodes) - 1)
                    self.dragging_node_index = len(self.nodes) - 1
                    self.update()
                    node_clicked = True
                    break
            
            if not node_clicked:
                self.dragging_canvas = True
                self.last_pan_point = event.pos()
                self.setCursor(Qt.CursorShape.ClosedHandCursor)
        
        elif event.button() == Qt.MouseButton.RightButton:
            clicked_pos_local = event.pos() - self.canvas_offset
            clicked_node_data = None
            for rect, _, _, step_data in self.nodes:
                if rect.contains(clicked_pos_local):
                    clicked_node_data = step_data
                    break
            self._show_context_menu(event.pos(), clicked_node_data)
            
        super().mousePressEvent(event)

    def mouseMoveEvent(self, event: QtGui.QMoveEvent):
        if self.dragging_node_index is not None:
            new_top_left = event.pos() - self.canvas_offset - self.drag_offset
            _, text, shape, step_data = self.nodes[self.dragging_node_index]
            old_rect = self.nodes[self.dragging_node_index][0]
            self.nodes[self.dragging_node_index] = (QRect(new_top_left, old_rect.size()), text, shape, step_data)
            self.update()
        elif self.dragging_canvas:
            delta = event.pos() - self.last_pan_point
            self.canvas_offset += delta
            self.last_pan_point = event.pos()
            self.update()
        else:
            # --- NEW: Change cursor for icon hotspots ---
            cursor = Qt.CursorShape.ArrowCursor
            clicked_pos = event.pos() - self.canvas_offset
            
            on_hotspot = any(hotspot_rect.contains(clicked_pos) for hotspot_rect, _ in self.icon_hotspots)
            if on_hotspot:
                cursor = Qt.CursorShape.PointingHandCursor
            else:
                on_node = any(rect.contains(clicked_pos) for rect, _, _, _ in self.nodes)
                if on_node:
                    cursor = Qt.CursorShape.OpenHandCursor
            self.setCursor(cursor)
            # --- END NEW ---
        
        super().mouseMoveEvent(event)

    def mouseReleaseEvent(self, event: QtGui.QMouseEvent):
        if event.button() == Qt.MouseButton.LeftButton:
            if self.dragging_node_index is not None:
                rect, text, shape, step_data = self.nodes[self.dragging_node_index]
                top_left = rect.topLeft()
                snapped_x = round(top_left.x() / self.GRID_SIZE) * self.GRID_SIZE
                snapped_y = round(top_left.y() / self.GRID_SIZE) * self.GRID_SIZE
                new_top_left = QPoint(snapped_x, snapped_y)
                snapped_rect = QRect(new_top_left, rect.size())
                step_data["workflow_pos"] = (snapped_rect.x(), snapped_rect.y())
                self.nodes[self.dragging_node_index] = (snapped_rect, text, shape, step_data)
                self.update()

            self.dragging_node_index = None
            self.dragging_canvas = False
            self.setCursor(Qt.CursorShape.ArrowCursor)

        super().mouseReleaseEvent(event)

# In main_app.py, inside the WorkflowCanvas class

# In main_app.py, inside the WorkflowCanvas class

    def _show_context_menu(self, pos: QPoint, clicked_node_data: Optional[Dict] = None):
        """Shows a context menu with workflow options."""
        context_menu = QMenu(self)
        configure_action, execute_action, save_template_action = None, None, None # <-- Add save_template_action
        
        if clicked_node_data:
            step_type = clicked_node_data.get("type")
            
            # --- START: New logic for Save Template action ---
            # If a group start, group end, loop start, or if start is clicked, add a "Save Template" option
            if step_type in ["group_start", "group_end", "loop_start", "IF_START"]:
                block_name = clicked_node_data.get('group_name', 
                                clicked_node_data.get('loop_config', {}).get('loop_name', 
                                clicked_node_data.get('condition_config', {}).get('block_name', 'Block')))
                if block_name:
                    save_template_action = context_menu.addAction(f"💾 Save Template: '{block_name}'")
                else:
                    save_template_action = context_menu.addAction("💾 Save As Template")
            # --- END: New logic for Save Template action ---
            
            if step_type not in ["group_end", "loop_end", "IF_END", "ELSE"]:
                if step_type == "group_start": execute_action = context_menu.addAction(f"▶️ Execute Entire Group: {clicked_node_data.get('group_name', 'Group')}")
                elif step_type == "loop_start": execute_action = context_menu.addAction(f"▶️ Execute Entire Loop: {clicked_node_data.get('loop_config', {}).get('loop_name', 'Loop')}")
                elif step_type == "IF_START": execute_action = context_menu.addAction(f"▶️ Execute Entire IF: {clicked_node_data.get('condition_config', {}).get('block_name', 'IF Block')}")
                else: execute_action = context_menu.addAction(f"▶️ Execute This Step: {clicked_node_data.get('method_name', 'Step')}")
            else:
                if step_type == "group_end": execute_action = context_menu.addAction(f"▶️ Execute Entire Group: {clicked_node_data.get('group_name', 'Group')}")
                elif step_type == "loop_end": execute_action = context_menu.addAction(f"▶️ Execute Entire Loop: {clicked_node_data.get('loop_config', {}).get('loop_name', 'Loop')}")
                elif step_type in ["IF_END", "ELSE"]: execute_action = context_menu.addAction(f"▶️ Execute Entire IF: {clicked_node_data.get('condition_config', {}).get('block_name', 'IF Block')}")

            if step_type in ["step", "loop_start", "IF_START", "group_start"]:
                configure_action = context_menu.addAction("⚙️ Configure Parameters")

            # Add separator if any primary actions exist
            if execute_action or configure_action or save_template_action: context_menu.addSeparator()
        
        redraw_action = context_menu.addAction("🔄 Smart Redraw Layout")
        reset_zoom_action = context_menu.addAction("🔍 Reset Zoom")
        center_action = context_menu.addAction("🎯 Center Workflow")
        
        action = context_menu.exec(self.mapToGlobal(pos))
        
        if action == execute_action and clicked_node_data: self.execute_step_requested.emit(clicked_node_data)
        elif action == configure_action and clicked_node_data: self.main_window.edit_step_from_data(clicked_node_data)
        # --- START: Handle the new action ---
        elif action == save_template_action and clicked_node_data:
            # We can directly call the existing handler method from MainWindow
            self.main_window._handle_save_as_template_request(clicked_node_data)
        # --- END: Handle the new action ---
        elif action == redraw_action: self._smart_redraw_layout()
        elif action == reset_zoom_action: self._reset_zoom()
        elif action == center_action: self._center_workflow()


    def _reset_zoom(self):
        """Resets zoom to default size."""
        self.NODE_WIDTH, self.NODE_HEIGHT, self.V_SPACING, self.H_SPACING, self.GRID_SIZE = 220, 50, 40, 120, 20
        self._smart_redraw_layout()

    def _center_workflow(self):
        """Centers the workflow in the current view."""
        if not self.nodes: return
        min_x, max_x = min(r.x() for r,_,_,_ in self.nodes), max(r.right() for r,_,_,_ in self.nodes)
        min_y, max_y = min(r.y() for r,_,_,_ in self.nodes), max(r.bottom() for r,_,_,_ in self.nodes)
        workflow_center_x, workflow_center_y = (min_x + max_x) // 2, (min_y + max_y) // 2
        canvas_center_x, canvas_center_y = self.width() // 2, self.height() // 2
        self.canvas_offset = QPoint(canvas_center_x - workflow_center_x, canvas_center_y - workflow_center_y)
        self.update()

    def _scale_layout(self, factor: float, anchor: QPointF):
        """Enhanced scaling with better anchor point handling."""
        adjusted_anchor = anchor - QPointF(self.canvas_offset)
        
        self.NODE_WIDTH = max(50, int(self.NODE_WIDTH * factor))
        self.NODE_HEIGHT = max(30, int(self.NODE_HEIGHT * factor))
        self.V_SPACING = max(10, int(self.V_SPACING * factor))
        self.H_SPACING = max(20, int(self.H_SPACING * factor))
        self.GRID_SIZE = max(5, int(self.GRID_SIZE * factor))

        def scale_user_pos_recursive(nodes: List[Dict]):
            for node in nodes:
                step_data = node['step_data']
                if "workflow_pos" in step_data and step_data["workflow_pos"]:
                    try:
                        current_pos_tuple = step_data["workflow_pos"]
                        if isinstance(current_pos_tuple, (list, tuple)) and len(current_pos_tuple) == 2:
                            current_pos = QPointF(float(current_pos_tuple[0]), float(current_pos_tuple[1]))
                            new_pos_f = (current_pos - adjusted_anchor) * factor + adjusted_anchor
                            step_data["workflow_pos"] = (int(new_pos_f.x()), int(new_pos_f.y()))
                        else: del step_data["workflow_pos"]
                    except (TypeError, ValueError, IndexError):
                        if "workflow_pos" in step_data: del step_data["workflow_pos"]

                scale_user_pos_recursive(node.get('children', []))
                scale_user_pos_recursive(node.get('false_children', []))
                
                if node.get('end_node'):
                    end_node_step_data = node['end_node']['step_data']
                    if "workflow_pos" in end_node_step_data and end_node_step_data["workflow_pos"]:
                        try:
                            current_pos_tuple = end_node_step_data["workflow_pos"]
                            if isinstance(current_pos_tuple, (list, tuple)) and len(current_pos_tuple) == 2:
                                current_pos = QPointF(float(current_pos_tuple[0]), float(current_pos_tuple[1]))
                                new_pos_f = (current_pos - adjusted_anchor) * factor + adjusted_anchor
                                end_node_step_data["workflow_pos"] = (int(new_pos_f.x()), int(new_pos_f.y()))
                            else: del end_node_step_data["workflow_pos"]
                        except (TypeError, ValueError, IndexError):
                            if "workflow_pos" in end_node_step_data: del end_node_step_data["workflow_pos"]

        scale_user_pos_recursive(self.workflow_tree)

        self.nodes.clear(); self.edges.clear(); self.merge_lines.clear(); self.icon_hotspots.clear()
        self.total_width, self.total_height = 0, 0

        canvas_center_x = max(800, self.width()) // 2
        start_x, start_y = canvas_center_x - self.NODE_WIDTH // 2, 30
        self._recursive_smart_layout(self.workflow_tree, start_x, start_y, -1)

# In main_app.py, inside the WorkflowCanvas class
# REPLACE the existing paintEvent method with this one:

    def paintEvent(self, event: QtGui.QPaintEvent):
        """Enhanced paint event with execution status and expand/collapse icons."""
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        painter.translate(self.canvas_offset)
        self._draw_grid(painter)
        font = QFont("Arial", max(8, int(9 * (self.NODE_WIDTH / 220))))
        painter.setFont(font)
        labels_to_draw = []

        for label, (from_idx, from_port), (to_idx, to_port) in self.edges:
            try: p1, p2 = self._get_port_pos(from_idx, from_port), self._get_port_pos(to_idx, to_port)
            except IndexError: continue

            if label == "True": painter.setPen(QPen(QColor("#28a745"), 2))
            elif label == "False": painter.setPen(QPen(QColor("#dc3545"), 2))
            elif label and "Loop" in label: painter.setPen(QPen(QColor("#007bff"), 2))
            else: painter.setPen(QPen(Qt.GlobalColor.black, 2))
            
            line_points = self._draw_right_angle_line(painter, p1, p2, from_port, to_port)
            if label:
                if from_port == "left": mid_point, label_rect = line_points[0] + QPoint(-40, -15), QRect(-30, -10, 60, 20)
                elif from_port == "right": mid_point, label_rect = line_points[0] + QPoint(40, -15), QRect(-30, -10, 60, 20)
                elif label == "Loop Again": mid_point, label_rect = (line_points[1] + line_points[2]) / 2 + QPoint(0, -15), QRect(-40, -10, 80, 20)
                else: mid_point, label_rect = line_points[0] + QPoint(40, 15), QRect(-40, -10, 80, 20)
                labels_to_draw.append((label, mid_point, label_rect))

        painter.setPen(QPen(Qt.GlobalColor.gray, 2, Qt.PenStyle.DashLine))
        for from_idx, to_idx in self.merge_lines:
            try: from_rect, to_rect = self.nodes[from_idx][0], self.nodes[to_idx][0]
            except IndexError: continue
            
            # --- MODIFICATION START ---
            # Always start the merge line from the bottom port of the source node.
            from_port = "bottom"
            # --- MODIFICATION END ---
            
            p1, p2 = self._get_port_pos(from_idx, from_port), self._get_port_pos(to_idx, "top")
            merge_y = p2.y() - self.V_SPACING // 2
            points = [p1, QPoint(p1.x(), merge_y), QPoint(p2.x(), merge_y), p2]
            for i in range(len(points) - 1): painter.drawLine(points[i], points[i+1])

        for rect, text, shape, step_data in self.nodes:
            status = step_data.get("execution_status", "normal")
            if status == "running": border_color, border_width, fill_color = QColor("#FFD700"), 4, QColor("#FFFBF0")
            elif status == "error": border_color, border_width, fill_color = QColor("#DC3545"), 4, QColor("#FFF5F5")
            elif status == "completed": border_color, border_width, fill_color = QColor("#28a745"), 2, QColor("#F8FFF8")
            else:
                border_color, border_width = QColor("#333333"), 2
                if shape == "rect": fill_color = QColor("#f8f9fa")
                elif shape == "diamond": fill_color = QColor("#e3f2fd")
                elif shape == "loop_rect": fill_color = QColor("#e8f5e8")
                elif shape == "rect_gray": fill_color = QColor("#f5f5f5")
                elif shape == "rect_group": fill_color = QColor("#fce4ec")
                else: fill_color = QColor("#f8f9fa")
            
            painter.setPen(QPen(border_color, border_width)); painter.setBrush(fill_color)
            if shape == "diamond":
                poly = QPolygonF([QPointF(rect.center() - QPoint(rect.width() // 2, 0)), QPointF(rect.center() - QPoint(0, rect.height() // 2)), QPointF(rect.center() + QPoint(rect.width() // 2, 0)), QPointF(rect.center() + QPoint(0, rect.height() // 2))])
                painter.drawPolygon(poly)
            else: painter.drawRoundedRect(rect, 8, 8)

            if step_data.get("type") == "group_start":
                icon_rect = QRect(rect.x() + 5, rect.y() + 5, 15, 15)
                painter.setPen(QPen(QColor("#555"), 1.5))
                painter.setBrush(Qt.BrushStyle.NoBrush)
                painter.drawRect(icon_rect)
                painter.drawLine(icon_rect.left() + 4, icon_rect.center().y(), icon_rect.right() - 4, icon_rect.center().y())
                if self._is_group_expanded(step_data.get("group_id")):
                    pass 
                else:
                    painter.drawLine(icon_rect.center().x(), icon_rect.top() + 4, icon_rect.center().x(), icon_rect.bottom() - 4)

            if status == "running":
                painter.save(); painter.setPen(QPen(QColor("#FF8C00"), 2)); painter.setBrush(Qt.BrushStyle.NoBrush); painter.drawEllipse(QRect(rect.right() - 15, rect.top() + 5, 10, 10)); painter.restore()
            elif status == "completed":
                painter.save(); painter.setPen(QPen(QColor("#28a745"), 3)); painter.drawLine(rect.right() - 15, rect.top() + 10, rect.right() - 12, rect.top() + 13); painter.drawLine(rect.right() - 12, rect.top() + 13, rect.right() - 7, rect.top() + 8); painter.restore()
            elif status == "error":
                painter.save(); painter.setPen(QPen(QColor("#DC3545"), 3)); painter.drawLine(rect.right() - 15, rect.top() + 5, rect.right() - 7, rect.top() + 13); painter.drawLine(rect.right() - 7, rect.top() + 5, rect.right() - 15, rect.top() + 13); painter.restore()

            painter.setPen(Qt.GlobalColor.black)
            text_rect = rect.adjusted(5, 5, -5, -5)
            result_message, execution_status = step_data.get("execution_result"), step_data.get("execution_status")
            if result_message and execution_status == "completed":
                display_result_text = ""
                assign_to_var = step_data.get("assign_to_variable_name")
                if step_data.get("type") == "step" and assign_to_var and "Result: " in result_message:
                    try:
                        result_val_str = result_message.split("Result: ")[1].split(" (Assigned to")[0] if " (Assigned to" in result_message else result_message.split("Result: ")[1]
                        if len(result_val_str) > 30: result_val_str = result_val_str[:27] + "..."
                        display_result_text = f"@{assign_to_var} = {result_val_str}"
                    except IndexError: display_result_text = "✓ Completed"
                else:
                    display_result_text = result_message
                    if len(display_result_text) > 35: display_result_text = display_result_text[:32] + "..."
                
                painter.drawText(QRect(text_rect.x(), text_rect.y(), text_rect.width(), text_rect.height() // 2), Qt.AlignmentFlag.AlignCenter | Qt.TextFlag.TextWordWrap, text)
                result_font = QFont("Arial", max(7, int(8 * (self.NODE_WIDTH / 220)))); result_font.setItalic(True); painter.setFont(result_font)
                painter.setPen(QColor("#155724"))
                painter.drawText(QRect(text_rect.x(), text_rect.y() + text_rect.height() // 2, text_rect.width(), text_rect.height() // 2), Qt.AlignmentFlag.AlignCenter | Qt.TextFlag.TextWordWrap, display_result_text)
                painter.setFont(font)
            else:
                painter.drawText(text_rect, Qt.AlignmentFlag.AlignCenter | Qt.TextFlag.TextWordWrap, text)

        for label, mid_point, label_rect in labels_to_draw:
            painter.save(); painter.translate(mid_point); painter.setPen(QPen(Qt.GlobalColor.darkGray, 1)); painter.setBrush(QColor("#ffffff")); painter.drawRoundedRect(label_rect, 3, 3)
            if label == "True": painter.setPen(QColor("#28a745"))
            elif label == "False": painter.setPen(QColor("#dc3545"))
            elif "Loop" in label: painter.setPen(QColor("#007bff"))
            else: painter.setPen(Qt.GlobalColor.black)
            painter.drawText(label_rect, Qt.AlignmentFlag.AlignCenter, label)
            painter.restore()

    def _get_port_pos(self, node_idx: int, port: str) -> QPoint:
        """Gets the QPoint for a given port on a node."""
        rect = self.nodes[node_idx][0]
        if port == "top": return rect.center() - QPoint(0, rect.height() // 2)
        if port == "bottom": return rect.center() + QPoint(0, rect.height() // 2)
        if port == "left": return rect.center() - QPoint(rect.width() // 2, 0)
        if port == "right": return rect.center() + QPoint(rect.width() // 2, 0)
        return rect.center()

    def _draw_right_angle_line(self, painter: QPainter, p1: QPoint, p2: QPoint, from_port: str, to_port: str):
        """Draws a rectilinear line between two points."""
        if from_port == "bottom" and to_port == "top": points = [p1, QPoint(p1.x(), p1.y() + self.V_SPACING // 2), QPoint(p2.x(), p1.y() + self.V_SPACING // 2), p2]
        elif from_port in ("left", "right") and to_port == "top": points = [p1, QPoint(p2.x(), p1.y()), p2]
        elif from_port == "right" and to_port == "top": points = [p1, QPoint(p1.x() + self.H_SPACING // 2, p1.y()), QPoint(p1.x() + self.H_SPACING // 2, p2.y() - self.V_SPACING // 2), QPoint(p2.x(), p2.y() - self.V_SPACING // 2), p2]
        else: points = [p1, QPoint(p1.x(), p2.y()), p2]
        for i in range(len(points) - 1): painter.drawLine(points[i], points[i+1])
        return points

    def _get_node_text(self, step_data: Dict[str, Any], step_num: int) -> str:
        """Generates a concise text for the workflow node."""
        step_type = step_data.get("type")
        title_prefix = f"{step_num}. "

        if step_type == "step":
            method_name = step_data.get("method_name", "Unknown")
            assign_var = step_data.get("assign_to_variable_name")
            params_config = step_data.get("parameters_config", {})
            param_values = []
            for name, config in params_config.items():
                if name == "original_listbox_row_index":
                    continue
                param_type = config.get('type')
                if param_type == 'hardcoded':
                    value_display = repr(config['value'])
                elif param_type == 'hardcoded_file':
                    value_display = f"File:'{os.path.basename(config['value'])}'"
                elif param_type == 'variable':
                    value_display = f"@{config['value']}"
                else:
                    value_display = "???"
                if len(value_display) > 20:
                    value_display = value_display[:17] + "..."
                param_values.append(value_display)
            param_str = ", ".join(param_values)
            if assign_var:
                return f"{title_prefix}@{assign_var} = {method_name}({param_str})"
            return f"{title_prefix}{method_name}({param_str})"

        elif step_type == "loop_start":
            config = step_data.get("loop_config", {})
            name_str = f"'{config.get('loop_name')}': " if config.get("loop_name") else "Loop "
            count_config = config.get("iteration_count_config", {})
            val = count_config.get("value", "N")
            if count_config.get("type") == "variable":
                val = f"@{val}"
            return f"{title_prefix}{name_str}{val} times"

        elif step_type == "IF_START":
            config = step_data.get("condition_config", {})
            name_str = f"'{config.get('block_name')}': " if config.get("block_name") else "IF "
            cond = config.get("condition", {})
            left_val = cond.get("left_operand", {}).get("value", "L")
            if cond.get("left_operand", {}).get("type") == "variable":
                left = f"@{left_val}"
            else:
                left = repr(left_val)
            right_val = cond.get("right_operand", {}).get("value", "R")
            if cond.get("right_operand", {}).get("type") == "variable":
                right = f"@{right_val}"
            else:
                right = repr(right_val)
            op = cond.get("operator", "??")
            if len(left) > 15: left = left[:12] + "..."
            if len(right) > 15: right = right[:12] + "..."
            return f"{title_prefix}{name_str}({left} {op} {right})"

        elif step_type == "ELSE":
            return f"{title_prefix}ELSE"

        elif step_type == "group_start":
            group_name = step_data.get('group_name', 'Unnamed')
            if len(group_name) > 25:
                group_name = group_name[:22] + "..."
            return f"{title_prefix}Group: {group_name}"

        # --- THIS IS THE CORRECTED BLOCK ---
        elif step_type == "loop_end":
            loop_name = step_data.get('loop_config', {}).get('loop_name')
            name_str = f' "{loop_name}"' if loop_name else ""
            return f"End Loop{name_str}"
        
        elif step_type == "IF_END":
            block_name = step_data.get('condition_config', {}).get('block_name')
            name_str = f' "{block_name}"' if block_name else ""
            return f"End IF{name_str}"

        elif step_type == "group_end":
            group_name = step_data.get('group_name')
            name_str = f' "{group_name}"' if group_name else ""
            return f"End Group{name_str}"
        # --- END OF CORRECTION ---

        return f"{title_prefix}{step_type.replace('_', ' ').title()}"

    def _adjust_canvas_size(self):
        """Enhanced canvas sizing with proper integer handling and extra generous left margin."""
        if not hasattr(self.main_window, 'added_steps_data') or not self.main_window.added_steps_data:
            self.setMinimumSize(400, 300); return
        try:
            self._force_complete_layout_calculation()
            if not self.nodes: self._use_fallback_sizing(); return
            min_x, max_x = min(r.x() for r,_,_,_ in self.nodes), max(r.right() for r,_,_,_ in self.nodes)
            min_y, max_y = min(r.y() for r,_,_,_ in self.nodes), max(r.bottom() for r,_,_,_ in self.nodes)
            content_width, content_height = max_x - min_x, max_y - min_y
            left_margin, right_margin, top_margin, bottom_margin = int(max(200, abs(min_x) + 100)), 150, 100, 150
            padding_factor = 1.2
            required_width, required_height = int((content_width + left_margin + right_margin) * padding_factor), int((content_height + top_margin + bottom_margin) * padding_factor)
            required_width, required_height = max(required_width, 1200), max(required_height, 600)
            self.setMinimumSize(required_width, required_height)
            self.main_window._log_to_console(f"Canvas sized with enhanced left margin: {required_width}x{required_height} (content: {content_width}x{content_height}, min_x: {min_x}, left_margin: {left_margin}, {len(self.nodes)} nodes positioned)")
        except Exception as e:
            self.main_window._log_to_console(f"Error in complete layout calculation: {e}"); self._use_fallback_sizing()
            
    def _remap_edges_for_drag(self, old_idx: int, new_idx: int):
        """Updates all edge indices when a node is moved in the list."""
        new_edges, new_merges = [], []
        for label, (from_idx, from_port), (to_idx, to_port) in self.edges:
            new_from_idx, new_to_idx = from_idx, to_idx
            if from_idx == old_idx: new_from_idx = new_idx
            elif from_idx > old_idx: new_from_idx -= 1
            if to_idx == old_idx: new_to_idx = new_idx
            elif to_idx > old_idx: new_to_idx -= 1
            new_edges.append((label, (new_from_idx, from_port), (new_to_idx, to_port)))
        self.edges = new_edges
        for from_idx, to_idx in self.merge_lines:
            new_from_idx, new_to_idx = from_idx, to_idx
            if from_idx == old_idx: new_from_idx = new_idx
            elif from_idx > old_idx: new_from_idx -= 1
            if to_idx == old_idx: new_to_idx = new_idx
            elif to_idx > old_idx: new_to_idx -= 1
            new_merges.append((new_from_idx, new_to_idx))
        self.merge_lines = new_merges    

    def _use_fallback_sizing(self):
        """Fallback sizing method when layout calculation fails."""
        step_count = len(self.main_window.added_steps_data) if hasattr(self.main_window, 'added_steps_data') else 0
        estimated_width, estimated_height = int(max(1200, step_count * 50)), int(max(800, step_count * 80))
        required_width, required_height = int(estimated_width * 1.2) + 200, int(estimated_height * 1.2) + 200
        self.setMinimumSize(required_width, required_height)
        self.main_window._log_to_console(f"Canvas sized with fallback method: {required_width}x{required_height} (estimated for {step_count} steps)")
            
    def _force_complete_layout_calculation(self):
        """Forces a complete recalculation of the entire workflow layout with proper left-side spacing."""
        self.nodes.clear(); self.edges.clear(); self.merge_lines.clear(); self.icon_hotspots.clear() # <<< ADD icon_hotspots.clear()
        if not hasattr(self, 'workflow_tree') or not self.workflow_tree: self.workflow_tree = self.main_window._build_workflow_tree_data()
        if not self.workflow_tree: return
        
        max_left_expansion = self._calculate_max_left_expansion()
        start_x, start_y = int(max(600, max_left_expansion + 200)), 50
        
        self.main_window._log_to_console(f"Starting layout at x={start_x} (left expansion: {max_left_expansion})")
        self._recursive_smart_layout(self.workflow_tree, start_x, start_y, -1)
        
        if self.nodes:
            min_x = min(rect.x() for rect, _, _, _ in self.nodes)
            if min_x < 50:
                offset_needed = int(100 - min_x)
                self._shift_all_nodes_right(offset_needed)
                self.main_window._log_to_console(f"Shifted all nodes right by {offset_needed} pixels")

    def _calculate_max_left_expansion(self) -> int:
        """Calculates the maximum potential leftward expansion based on workflow structure."""
        if not hasattr(self.main_window, 'added_steps_data'): return 400
        max_nesting_depth, current_depth, if_else_count = 0, 0, 0
        for step_data in self.main_window.added_steps_data:
            step_type = step_data.get("type")
            if step_type == "IF_START": current_depth += 1; if_else_count += 1; max_nesting_depth = max(max_nesting_depth, current_depth)
            elif step_type in ["loop_start", "group_start"]: current_depth += 1; max_nesting_depth = max(max_nesting_depth, current_depth)
            elif step_type in ["IF_END", "loop_end", "group_end"]: current_depth = max(0, current_depth - 1)
        potential_left_expansion = int((if_else_count * self.H_SPACING) + (max_nesting_depth * self.H_SPACING // 2))
        self.main_window._log_to_console(f"Calculated potential left expansion: {potential_left_expansion} (IF count: {if_else_count}, max depth: {max_nesting_depth})")
        return max(potential_left_expansion, 400)

    def _shift_all_nodes_right(self, offset: int):
        """Shifts all nodes to the right by the specified offset."""
        new_nodes = []
        for rect, text, shape, step_data in self.nodes:
            new_x, new_y = int(rect.x() + offset), int(rect.y())
            new_width, new_height = int(rect.width()), int(rect.height())
            new_rect = QRect(new_x, new_y, new_width, new_height)
            step_data["workflow_pos"] = (new_x, new_y)
            new_nodes.append((new_rect, text, shape, step_data))
        self.nodes = new_nodes
        
# In main_app.py, add this new class definition before the MainWindow class.

class TemplateTreeWidget(QTreeWidget):
    """
    A QTreeWidget with drag-and-drop support for organizing bot templates.
    """
    def __init__(self, main_window_ref: 'MainWindow', parent: Optional[QWidget] = None):
        super().__init__(parent)
        self.main_window = main_window_ref
        
        # Enable drag and drop
        self.setDragEnabled(True)
        self.setAcceptDrops(True)
        self.setDropIndicatorShown(True)
        self.setDragDropMode(QTreeWidget.DragDropMode.InternalMove)

    def startDrag(self, supportedActions: Qt.DropAction):
        """
        Overridden to control what can be dragged. We only allow templates, not folders.
        """
        item = self.currentItem()
        if item:
            item_data = self.main_window._get_item_data(item)
            if isinstance(item_data, dict) and item_data.get('type') == 'template':
                # Only start the drag if the item is a template
                super().startDrag(supportedActions)

    def dragMoveEvent(self, event: QtGui.QDragMoveEvent):
        """
        Overridden to provide visual feedback during a drag operation.
        """
        # We only accept drops onto folders or the template root
        target_item = self.itemAt(event.position().toPoint())
        if target_item:
            target_data = self.main_window._get_item_data(target_item)
            if isinstance(target_data, dict) and target_data.get('type') in ['template_folder', 'template_root']:
                event.accept()
                return
        event.ignore()

    def dropEvent(self, event: QtGui.QDropEvent):
        """
        Overridden to handle the file move operation when an item is dropped.
        """
        source_item = self.currentItem()
        target_item = self.itemAt(event.position().toPoint())

        if not source_item or not target_item:
            event.ignore()
            return

        source_data = self.main_window._get_item_data(source_item)
        target_data = self.main_window._get_item_data(target_item)

        # Validate that we are dropping a template onto a folder or root
        is_valid_drop = (
            isinstance(source_data, dict) and source_data.get('type') == 'template' and
            isinstance(target_data, dict) and target_data.get('type') in ['template_folder', 'template_root']
        )

        if not is_valid_drop:
            event.ignore()
            return

        # --- Perform the move operation ---
        try:
            # 1. Get original file path
            source_relative_path = source_data['path']
            source_full_path = os.path.join(self.main_window.steps_template_directory, source_relative_path)
            
            # 2. Determine destination directory path
            if target_data['type'] == 'template_root':
                dest_dir_path = self.main_window.steps_template_directory
            else: # It's a template_folder
                dest_dir_path = os.path.join(self.main_window.steps_template_directory, target_data['path'])

            # 3. Construct new file path
            file_name = os.path.basename(source_full_path)
            dest_full_path = os.path.join(dest_dir_path, file_name)
            
            # 4. Check if the file already exists at the destination
            if os.path.exists(dest_full_path):
                # Don't show a popup, just log and abort
                self.main_window._log_to_console(f"Drop cancelled: A template named '{file_name}' already exists in the target folder.")
                event.ignore()
                return

            # 5. Move the file on disk
            shutil.move(source_full_path, dest_full_path)
            self.main_window._log_to_console(f"Moved template from '{source_relative_path}' to '{os.path.relpath(dest_full_path, self.main_window.steps_template_directory)}'")
            
            # 6. Accept the drop and refresh the tree
            event.accept()
            self.main_window.load_all_modules_to_tree()

        except Exception as e:
            QMessageBox.critical(self.main_window, "Drag & Drop Error", f"Failed to move template: {e}")
            event.ignore()        
# --- MAIN APPLICATION WINDOW ---
class MainWindow(QMainWindow):
# In MainWindow class
    def __init__(self, parent: Optional[QWidget] = None):
        super().__init__(parent)
        self.wait_time_between_steps = {'type': 'hardcoded', 'value': 0}
        self.setWindowTitle("Automate Your Task By Simple Bot - Developed by Phung Tuan Hung")
        

        #Get the geometry of the primary screen
        screen = QApplication.primaryScreen().geometry()
        width = int(screen.width() * 0.9)
        height = int(screen.height() * 0.9)
        x = int((screen.width() - width) / 2)
        y = int((screen.height() - height) / 2)
        self.setGeometry(x, y, width, height)

        # --- Initialize attributes ---
        self.gui_communicator = GuiCommunicator()
        self.base_directory = os.path.dirname(os.path.abspath(__file__))
        self.module_subfolder = "Bot_module"
        self.module_directory = os.path.join(self.base_directory, self.module_subfolder)
        self.click_image_dir = os.path.join(self.base_directory, "Click_image")
        os.makedirs(self.click_image_dir, exist_ok=True)
        self.schedules_directory = os.path.join(self.base_directory, "Schedules")
        self.schedules = {}
        self._last_focused_step_index: Optional[int] = None
        icon_path = os.path.join(self.base_directory, "app_icon.ico")
        if os.path.exists(icon_path):
            self.setWindowIcon(QIcon(icon_path))
            
        # 1. Define bot_steps_subfolder and bot_steps_directory FIRST
        self.bot_steps_subfolder = "Bot_steps"
        self.bot_steps_directory = os.path.join(self.base_directory, self.bot_steps_subfolder)
        
        # --- NEW TEMP FILE LOGIC ---
        # 2. Define the path for the default "untitled" temp file
        self.default_temp_file_path = os.path.join(self.bot_steps_directory, "workflow_temp.json")
        
        # 3. Define the variable that holds the *currently active* temp file.
        #    It starts as the default one.
        self.current_temp_file_path = self.default_temp_file_path
        
        # --- NEW: Define the restore file for scheduled tasks ---
        self.scheduled_task_restore_file = os.path.join(self.bot_steps_directory, "_scheduled_task_restore.json")
        # --- END NEW ---

        self.steps_template_subfolder = "Steps_template"
        self.steps_template_directory = os.path.join(self.base_directory, self.steps_template_subfolder)
        self.template_document_directory = os.path.join(self.base_directory, "template_document")
        self.added_steps_data: List[Dict[str, Any]] = []
        self.last_executed_context: Optional[ExecutionContext] = None
        self.global_variables: Dict[str, Any] = {}
        self.loop_id_counter: int = 0
        self.if_id_counter: int = 0
        self.group_id_counter: int = 0
        self.group_expansion_states: Dict[str, bool] = {}  # <<< ADD THIS LINE
        
        self.active_param_input_dialog: Optional[ParameterInputDialog] = None
        self.all_parsed_method_data: Dict[str, Dict[str, List[Tuple[str, str, str, str, Dict[str, Any]]]]] = {}
        self.data_to_item_map: Dict[int, QTreeWidgetItem] = {}
        self.minimized_for_execution = False
        self.original_geometry = None
        self.widget_homes = {}

        self.is_bot_running = False
        self.is_paused = False # ADD THIS
        self.worker: Optional[ExecutionWorker] = None # ADD THIS
        self.workflow_tab_index: int = 2 # <--- ADD THIS LINE
        
        # --- Create UI ---
        self.init_ui()
        # --- ADD THESE TWO LINES ---
        self.gui_communicator.hide_gui_signal.connect(self.hide)
        self.gui_communicator.show_gui_signal.connect(self.show)
        # ---------------------------
        # --- Connect signals and start logic ---
        self.gui_communicator.log_message_signal.connect(self._log_to_console)
        self.gui_communicator.update_module_info_signal.connect(self.update_label_info_from_module)
        self.gui_communicator.update_click_signal.connect(self.update_click_signal_from_module)


        # --- Scheduler Setup ---
        self.schedule_timer = QTimer(self)
        self.schedule_timer.timeout.connect(self.check_schedules)
        self.schedule_timer.start(60000)
        self._log_to_console("Scheduler started. Will check for due tasks every minute.")
        
        # --- Load initial data ---
        self.load_all_modules_to_tree()
        self.load_saved_steps_to_tree()
        self._update_variables_list_display()
        self.minimized_for_execution = False
        self.original_geometry = None
        #--------------------------------------------------
        self.minimized_for_execution = False
        self.original_geometry = None
        self.widget_homes = {} # <<< ADD THIS LINE
        self.is_bot_running = False
        self.is_paused = False
        self.worker: Optional[ExecutionWorker] = None
        
        # --- MODIFIED: This startup check now only checks for the default "untitled" temp file ---
        self._check_for_temp_workflow_recovery()
        
    def init_ui(self) -> None:
        """Initialize the new UI with left menu, center content, and right panels."""
        os.makedirs(self.steps_template_directory, exist_ok=True)
        
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        main_layout = QHBoxLayout(central_widget)
        main_layout.setContentsMargins(0, 0, 0, 0)
        main_layout.setSpacing(0)
        
        self.create_left_menu()
        self.create_center_content()
        self.create_right_panels()
        
        self.toggle_log_checkbox.toggled.connect(self.log_widget.setVisible)
        self.log_widget.setVisible(False)
        
        main_layout.addWidget(self.left_menu)
        main_layout.addWidget(self.center_content)
        main_layout.addWidget(self.right_panels)
        
        main_layout.setStretch(0, 0)
        main_layout.setStretch(1, 1)
        main_layout.setStretch(2, 0)

    def create_left_menu(self):
        """Creates the collapsible left-side menu."""
        self.left_menu = QWidget()
        self.left_menu.setFixedWidth(250)
        self.left_menu.setStyleSheet("""
            QWidget {
                background-color: #ecf0f1;
                border-right: 1px solid #bdc3c7;
            }
            QPushButton {
                text-align: left;
                padding: 8px 12px;
                border: none;
                border-radius: 4px;
                margin: 2px 8px;
                font-size: 13px;
                color: #2c3e50;
                background-color: #ffffff;
            }
            QPushButton:hover {
                background-color: #e8f4fd;
                border-left: 3px solid #3498db;
            }
            QPushButton:disabled {
                background-color: #f8f9f9;
                color: #95a5a6;
            }
            QPushButton.section-header {
                font-weight: bold;
                color: #34495e;
                background-color: transparent;
                border-bottom: 1px solid #dadedf;
                border-radius: 0;
                margin: 8px 0 4px 0;
            }
            QCheckBox {
                padding: 8px 12px;
                font-size: 13px;
            }
        """)
        menu_layout = QVBoxLayout(self.left_menu)
        
        # --- Brand ---
        self.website_label = QLabel('<a href="" style="color: #3498db; text-decoration: none; font-size: 18pt; font-weight: bold;">AutomateTask</a>')
        self.website_label.setOpenExternalLinks(True)
        self.website_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        menu_layout.addWidget(self.website_label)
        
        # Helper function for sections
        def create_section(title, buttons):
            menu_layout.addWidget(QLabel(title, objectName="section-header"))
            for btn in buttons:
                menu_layout.addWidget(btn)

        # --- Execution ---
        self.execute_all_button = QPushButton("🚀 Execute All")
        self.execute_one_step_button = QPushButton("▶️ Execute Selected")
        create_section("Execution", [self.execute_all_button, self.execute_one_step_button])

        # --- Bot Management ---
        self.save_steps_button = QPushButton("💾 Save Bot")
        self.change_bot_folder_button = QPushButton("📂 Change Folder")
        create_section("Bot Management", [self.save_steps_button, self.change_bot_folder_button])

        # --- Step Editing ---
        self.add_loop_button = QPushButton("🔄 Add Loop")
        self.add_conditional_button = QPushButton("❓ Add Conditional")
        self.group_steps_button = QPushButton("📦 Group Selected")
        
        self.rearrange_steps_button = QPushButton("↕️ Rearrange Steps")
        
        self.clear_selected_button = QPushButton("🗑️ Clear Selected")
        self.remove_all_steps_button = QPushButton("❌ Remove All")

        create_section("Step Editing", [self.add_loop_button, self.add_conditional_button, self.group_steps_button, self.rearrange_steps_button, self.clear_selected_button, self.remove_all_steps_button])
        
        # --- Tools & Settings ---
        self.open_screenshot_tool_button = QPushButton("📷 Screenshot Tool")
        self.view_workflow_button = QPushButton("📈 View Workflow")
        self.export_workflow_button = QPushButton("🖼️ Export to Image") # <<< ADD THIS LINE
        self.set_wait_time_button = QPushButton("⏱️ Wait between Steps")
        self.update_app_btn = QPushButton("🔄 Update App")
        self.always_on_top_button = QPushButton("📌 Always On Top: Off")
        self.user_manual_button = QPushButton("📘 User Manual") # <<< NEW LINE
        self.toggle_log_checkbox = QCheckBox("📋 Show Log")
        #create_section("Tools & Settings", [self.open_screenshot_tool_button, self.view_workflow_button, self.update_app_btn, self.always_on_top_button, self.toggle_log_checkbox])
        create_section("Tools & Settings", [self.open_screenshot_tool_button, self.view_workflow_button,self.export_workflow_button, self.set_wait_time_button, self.update_app_btn, self.always_on_top_button,self.user_manual_button]) #, self.toggle_log_checkbox]
        
        # Connections
        #self.execute_all_button.clicked.connect(self.execute_all_steps)
        self.execute_all_button.clicked.connect(self._handle_execute_pause_resume)
        self.execute_one_step_button.clicked.connect(self.execute_one_step)
        self.save_steps_button.clicked.connect(self.save_bot_steps_dialog)
        self.change_bot_folder_button.clicked.connect(self.select_bot_steps_folder)
        self.add_loop_button.clicked.connect(self.add_loop_block)
        self.add_conditional_button.clicked.connect(self.add_conditional_block)
        self.group_steps_button.clicked.connect(self.group_selected_steps)
        self.rearrange_steps_button.clicked.connect(self.open_rearrange_steps_dialog)
        self.clear_selected_button.clicked.connect(self.clear_selected_steps)
        self.remove_all_steps_button.clicked.connect(self.clear_all_steps)
        self.open_screenshot_tool_button.clicked.connect(self.open_screenshot_tool)
        self.view_workflow_button.clicked.connect(self._handle_view_workflow_click)
        self.export_workflow_button.clicked.connect(self._handle_export_workflow_to_image) # <<< ADD THIS LINE
        self.update_app_btn.clicked.connect(self.update_application)
        self.always_on_top_button.setCheckable(True)
        self.set_wait_time_button.clicked.connect(self.set_wait_time)
        self.always_on_top_button.clicked.connect(self.toggle_always_on_top)
        self.user_manual_button.clicked.connect(self.open_user_manual) # <<< NEW LINE

        menu_layout.addStretch()

        # Progress Bar & Exit
        self.progress_bar = QProgressBar(); self.progress_bar.hide(); menu_layout.addWidget(self.progress_bar)
        self.exit_button = QPushButton("🚪 Exit"); self.exit_button.clicked.connect(QApplication.instance().quit); menu_layout.addWidget(self.exit_button)
        
# In MainWindow class
# REPLACE your existing create_center_content method with this one:
# In MainWindow class
# REPLACE your existing create_center_content method with this one:

    def create_center_content(self):
        """Creates the main tabbed interface, now with a dedicated focus mode layout."""
        self.center_content = QWidget()
        # Main layout that holds everything in the center panel
        main_center_layout = QVBoxLayout(self.center_content)
        main_center_layout.setContentsMargins(5, 5, 5, 5)

        # 1. Normal Mode UI (Tabs and Info)
        # Create a widget to hold the normal UI so we can hide/show it easily
        self.normal_mode_widget = QWidget()
        normal_mode_layout = QVBoxLayout(self.normal_mode_widget)
        normal_mode_layout.setContentsMargins(0, 0, 0, 0) # No extra margins needed here

        self.main_tab_widget = QTabWidget()
        self.create_saved_bots_tab()
        self.create_execution_flow_tab()
        self.create_workflow_tab()
        self.create_log_tab()
        self.create_data_tab() # <--- THIS LINE IS NEW
        normal_mode_layout.addWidget(self.main_tab_widget) # Add tabs to normal widget

        # Create the info widget (as before)
        self.info_widget = QFrame()
        self.info_widget.setFrameShape(QFrame.Shape.StyledPanel)
        info_layout = QHBoxLayout(self.info_widget)
        self.label_info1 = QLabel("Info:")
        self.label_info2 = QLabel("Image Preview")
        self.label_info2.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.label_info2.setFixedSize(200, 30)
        self.label_info2.setStyleSheet("QLabel { background-color: #f0f0f0; border: 1px solid #dcdcdc; border-radius: 4px; color: #888; }")
        self.label_info3 = QLabel("Image Name")
        self.label_info3.setAlignment(Qt.AlignmentFlag.AlignRight)
        info_layout.addWidget(self.label_info1)
        info_layout.addWidget(self.label_info2)
        info_layout.addWidget(self.label_info3)
        normal_mode_layout.addWidget(self.info_widget) # Add info widget to normal widget

        # Add the entire normal mode widget to the main layout
        main_center_layout.addWidget(self.normal_mode_widget)


        # 2. Focus Mode UI (Initially hidden)
        # This is the new container for our focus mode UI
        self.focus_mode_widget = QWidget()
        self.focus_mode_layout = QVBoxLayout(self.focus_mode_widget)
        self.focus_mode_layout.setContentsMargins(0, 0, 0, 0)
        self.focus_mode_widget.setVisible(False) # Start hidden

        # Add the focus mode widget to the main layout
        main_center_layout.addWidget(self.focus_mode_widget)
    def create_data_tab(self):
        """Creates the 'Data' tab for viewing DataFrames and Worksheets."""
        data_widget = QWidget()
        layout = QVBoxLayout(data_widget)
        layout.setContentsMargins(5, 5, 5, 5)

        # Add an instruction label
        instruction_label = QLabel("When this tab is active, double-click a DataFrame or Worksheet variable in the 'Global Variables' list to display it here.")
        instruction_label.setStyleSheet("font-style: italic; color: #555;")
        instruction_label.setWordWrap(True)
        layout.addWidget(instruction_label)

        # Create the table view to display data
        self.data_table_view = QTableView()
        self.data_table_view.setEditTriggers(QTableView.EditTrigger.NoEditTriggers) # Make it read-only
        self.data_table_view.setAlternatingRowColors(True)
        layout.addWidget(self.data_table_view)

        # Add the completed widget as a new tab
        self.main_tab_widget.addTab(data_widget, "📊 Data")
    def create_right_panels(self):
        """Creates the right-side panels for modules and variables."""
        self.right_panels = QWidget()
        self.right_panels.setFixedWidth(400)
        self.right_panels.setStyleSheet("background-color: #f4f6f7;")
        right_layout = QVBoxLayout(self.right_panels)
        
        right_splitter = QSplitter(Qt.Orientation.Vertical)
        
        # Module Browser
        module_panel = QWidget()
        module_layout = QVBoxLayout(module_panel)
        module_layout.addWidget(QLabel("🔧 Module Browser", objectName="section-header"))
        filter_layout = QHBoxLayout()
        filter_layout.addWidget(QLabel("Filter:"))
        self.module_filter_dropdown = QComboBox(); self.module_filter_dropdown.addItem("-- Show All --"); filter_layout.addWidget(self.module_filter_dropdown)
        module_layout.addLayout(filter_layout)
        self.search_box = QLineEdit(); self.search_box.setPlaceholderText("Search modules..."); module_layout.addWidget(self.search_box)
        self.module_tree = QTreeWidget()
        self.module_tree = TemplateTreeWidget(main_window_ref=self)
        self.module_tree.setHeaderHidden(True); module_layout.addWidget(self.module_tree)
        
        # Variables Panel
        vars_panel = QWidget()
        vars_layout = QVBoxLayout(vars_panel)
        vars_layout.addWidget(QLabel("📊 Global Variables", objectName="section-header"))
        self.variables_list = QListWidget(); vars_layout.addWidget(self.variables_list)
        btn_layout = QHBoxLayout()
        
        # --- Example Custom Styling ---
        # You can change these values as you like.
        button_style = """
            QPushButton {
                color: #000000;                 /* Text color (white) */
                background-color: #3498db;     /* A blue background */
                font-size: 13px;               /* Text size */
                padding: 5px 8px;              /* Vertical (5px) and horizontal (8px) padding */
                border: none;
                border-radius: 4px;
            }
            QPushButton:hover {
                background-color: #2980b9;     /* Darker blue on hover */
            }
            QPushButton:pressed {
                background-color: #2471a3;     /* Even darker blue when pressed */
            }
        """

        # Create the buttons
        self.add_var_button = QPushButton("➕ Add")
        self.edit_var_button = QPushButton("✏️ Edit")
        self.delete_var_button = QPushButton("❌ Delete")
        self.clear_vars_button = QPushButton("🔄 Reset")

        # Apply the style to all four buttons
        self.add_var_button.setStyleSheet(button_style)
        self.edit_var_button.setStyleSheet(button_style)
        
        # --- Example of a different style for Delete/Reset ---
        # Just copy the 'button_style' string, change the colors, and apply it.
        # For example, to make Delete and Reset red:
        danger_style = button_style.replace("#3498db", "#e74c3c")  # Replace blue with red
                                  #.replace("#2980b9", "#c0392b")
                                  #.replace("#2471a3", "#a93226")
                                  
        self.delete_var_button.setStyleSheet(button_style)
        self.clear_vars_button.setStyleSheet(button_style)


        # Add buttons to the layout
        btn_layout.addWidget(self.add_var_button)
        btn_layout.addWidget(self.edit_var_button)
        btn_layout.addWidget(self.delete_var_button)
        btn_layout.addWidget(self.clear_vars_button)
        
        vars_layout.addLayout(btn_layout)

        right_splitter.addWidget(module_panel)
        right_splitter.addWidget(vars_panel)
        right_splitter.setSizes([500, 250])
        right_layout.addWidget(right_splitter)

        # Connections
        self.module_filter_dropdown.currentIndexChanged.connect(self.filter_module_tree)
        self.search_box.textChanged.connect(self.search_module_tree)
        self.module_tree.itemDoubleClicked.connect(self.add_item_to_execution_tree)
        self.module_tree.itemClicked.connect(self.update_selected_method_info)
        self.module_tree.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        self.module_tree.customContextMenuRequested.connect(self.show_context_menu)
        self.add_var_button.clicked.connect(self.add_variable)
        self.edit_var_button.clicked.connect(self.edit_variable)
        self.delete_var_button.clicked.connect(self.delete_variable)
        self.clear_vars_button.clicked.connect(self.reset_all_variable_values)
        self.variables_list.itemDoubleClicked.connect(self._handle_variable_double_click) # <--- THIS LINE IS NEW
        
    def create_execution_flow_tab(self):
        """
        Creates the 'Execution Flow' tab, containing only the title label
        and the main execution tree widget. The info labels have been moved out.
        """
        # Create the main widget for this tab
        exec_widget = QWidget()
        layout = QVBoxLayout(exec_widget)
        layout.setContentsMargins(5, 5, 5, 5) # Add some padding

        # Create and add the title label for this tab
        self.execution_flow_label = QLabel("Execution Flow")
        self.execution_flow_label.setStyleSheet("font-weight: bold; font-size: 14px; color: #2c3e50;")
        layout.addWidget(self.execution_flow_label)

        # Create and add the tree widget for displaying steps
        self.execution_tree = GroupedTreeWidget(self)
        self.execution_tree.setHeaderHidden(True)
        self.execution_tree.setSelectionMode(QtWidgets.QAbstractItemView.SelectionMode.ExtendedSelection)
        self.execution_tree.itemSelectionChanged.connect(self._toggle_execute_one_step_button)
        layout.addWidget(self.execution_tree)

        # The info labels (label_info1, label_info2, label_info3) are
        # intentionally NOT created or added here anymore. They are now
        # handled in the `create_center_content` method to be globally visible.

        # Add the completed widget as a new tab
        self.main_tab_widget.addTab(exec_widget, "📋 Execution Flow")

    def create_saved_bots_tab(self):
        bots_widget = QWidget()
        layout = QVBoxLayout(bots_widget)
        layout.addWidget(QLabel("Saved Bots"))
        self.saved_steps_tree = QTreeWidget(); self.saved_steps_tree.setHeaderLabels(["Bot", "Schedule", "Status"]); self.saved_steps_tree.itemDoubleClicked.connect(self.saved_step_tree_item_selected); self.saved_steps_tree.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu); self.saved_steps_tree.customContextMenuRequested.connect(self.show_saved_bot_context_menu); layout.addWidget(self.saved_steps_tree)
        self.main_tab_widget.addTab(bots_widget, "🤖 Saved Bots")

    def create_workflow_tab(self):
        flow_widget = QWidget()
        layout = QVBoxLayout(flow_widget)
        self.bot_workflow_label = QLabel("Bot Workflow")
        layout.addWidget(self.bot_workflow_label)
        self.workflow_scroll_area = QScrollArea(); 
        self.workflow_scroll_area.setWidgetResizable(True); 
        self.workflow_scroll_area.setMinimumSize(50, 50)
        layout.addWidget(self.workflow_scroll_area)

        self.workflow_tab_index = self.main_tab_widget.indexOf(flow_widget)
        self.main_tab_widget.addTab(flow_widget, "📈 Workflow")
        self.workflow_tab_index = self.main_tab_widget.indexOf(flow_widget)

    def create_log_tab(self):
        self.log_widget = QWidget()
        layout = QVBoxLayout(self.log_widget)
        layout.addWidget(QLabel("Execution Log"))
        self.log_console = QTextEdit(); self.log_console.setReadOnly(True); layout.addWidget(self.log_console)
        self.clear_log_button = QPushButton("Clear Log"); self.clear_log_button.clicked.connect(self.log_console.clear); layout.addWidget(self.clear_log_button)
        self.main_tab_widget.addTab(self.log_widget, "📜 Log")

    # All other methods from the original MainWindow go here...
    def _get_item_data(self, item: QTreeWidgetItem) -> Optional[Dict[str, Any]]:
        if not item: return None
        data = item.data(0, Qt.ItemDataRole.UserRole)
        return data.value() if isinstance(data, QVariant) else data

    def select_bot_steps_folder(self):
        """Opens a dialog to allow the user to select a different folder for saved bots."""
        current_dir = self.bot_steps_directory
        new_dir = QFileDialog.getExistingDirectory(self, "Select Bot Steps Folder", current_dir)
        
        if new_dir and new_dir != current_dir:
            self.bot_steps_directory = new_dir
            self.load_saved_steps_to_tree() # Refresh the tree from the new location
            self._log_to_console(f"Changed bot steps folder to: {new_dir}")

    def _handle_screenshot_request_from_param_dialog(self) -> None:
        if self.active_param_input_dialog:
            self.active_param_input_dialog.hide()
        self._log_to_console("ParameterInputDialog hidden, opening screenshot tool.")
        self.open_screenshot_tool()

    def show_saved_bot_context_menu(self, position: QPoint):
        item = self.saved_steps_tree.itemAt(position)
        if not item or item.text(0) == "No saved bots found.":
            return

        bot_name = item.text(0)
        context_menu = QMenu(self)
        open_action = context_menu.addAction("Open Bot")
        schedule_action = context_menu.addAction("Schedule Task")
        delete_action = context_menu.addAction("Delete Bot")

        action = context_menu.exec(self.saved_steps_tree.mapToGlobal(position))

        if action == open_action:
            self.open_saved_bot(bot_name)
        elif action == schedule_action:
            self.schedule_bot(bot_name)
        elif action == delete_action:
            self.delete_saved_bot(bot_name)

    def open_saved_bot(self, bot_name: str):
        """Loads the selected bot into the Execution Flow."""
        file_path = os.path.join(self.bot_steps_directory, f"{bot_name}.csv")
        if os.path.exists(file_path):
            self.load_steps_from_file(file_path)
        else:
            QMessageBox.warning(self, "File Not Found", f"The bot file '{bot_name}.csv' was not found.")
            self.load_saved_steps_to_tree()

    def schedule_bot(self, bot_name: str):
        """Opens the scheduling dialog for the selected bot."""
        # This correctly reads from the central 'schedules.json' for the dialog
        schedule_data = self.schedules.get(bot_name)
        dialog = ScheduleTaskDialog(bot_name, schedule_data, self)
        
        if dialog.exec() == QDialog.DialogCode.Accepted:
            # Get the new schedule data from the dialog
            new_schedule_data = dialog.get_schedule_data()

            # --- FIX STARTS HERE ---

            # 1. Write to System 1 (schedules.json) - This part is the same as before
            self.schedules[bot_name] = new_schedule_data
            self.save_schedules()

            # 2. Write to System 2 (the bot's .csv file) - This is the new, required logic
            bot_file_path = os.path.join(self.bot_steps_directory, f"{bot_name}.csv")
            
            if not os.path.exists(bot_file_path):
                QMessageBox.warning(self, "Error", f"Could not find bot file '{bot_name}.csv' to save schedule.")
                return

            # Use the existing helper function to write the schedule into the .csv
            if not self._write_schedule_to_csv(bot_file_path, new_schedule_data):
                QMessageBox.critical(self, "Schedule Save Error", f"Failed to write schedule data to {bot_name}.csv.")
            else:
                self._log_to_console(f"Schedule for '{bot_name}' saved to .json and .csv")
                
            # --- FIX ENDS HERE ---

            # Refresh the "Saved Bots" tab display
            self.load_saved_steps_to_tree()

# In MainWindow class
    def delete_saved_bot(self, bot_name: str):
        """Deletes the selected bot (.csv), its backup (.json), and its schedule."""
        reply = QMessageBox.question(self, "Confirm Delete",
                                     f"Are you sure you want to permanently delete the bot '{bot_name}', "
                                     "its backup file, and its schedule?",
                                     QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                                     QMessageBox.StandardButton.No)

        if reply == QMessageBox.StandardButton.Yes:
            try:
                # 1. Define paths for both files
                bot_path_csv = os.path.join(self.bot_steps_directory, f"{bot_name}.csv")
                bot_path_json = os.path.join(self.bot_steps_directory, f"{bot_name}.json")
                
                # 2. Delete the .csv file
                if os.path.exists(bot_path_csv):
                    os.remove(bot_path_csv)
                    
                # 3. Delete the .json backup file
                if os.path.exists(bot_path_json):
                    os.remove(bot_path_json)

                # 4. Delete the schedule
                if bot_name in self.schedules:
                    del self.schedules[bot_name]
                    self.save_schedules() # Save the updated schedules list

                QMessageBox.information(self, "Success", f"Bot '{bot_name}' has been deleted.")
                
                # 5. Check if the deleted bot was the one currently open
                if self.current_temp_file_path == bot_path_json:
                    self._log_to_console(f"The currently open bot '{bot_name}' was deleted. Clearing UI.")
                    # Clear the UI and reset to "untitled" state
                    self._internal_clear_all_steps()
                    self.current_temp_file_path = self.default_temp_file_path
                    self._clear_default_temp_file() # Ensure the default file is empty
                
                # 6. Refresh the "Saved Bots" list
                self.load_saved_steps_to_tree()
                
            except Exception as e:
                QMessageBox.critical(self, "Error", f"An error occurred while deleting the bot:\n{e}")

    def save_schedules(self):
        """Saves the current schedules to a JSON file."""
        os.makedirs(self.schedules_directory, exist_ok=True)
        schedule_file_path = os.path.join(self.schedules_directory, "schedules.json")
        try:
            with open(schedule_file_path, 'w', encoding='utf-8') as f:
                json.dump(self.schedules, f, indent=4)
        except Exception as e:
            self._log_to_console(f"Error saving schedules: {e}")


    def load_saved_steps_to_tree(self) -> None:
        """Loads saved bot step files and their schedules into the QTreeWidget."""
        self.saved_steps_tree.clear()
        self.load_schedules()
        try:
            os.makedirs(self.bot_steps_directory, exist_ok=True)
            step_files = sorted([f for f in os.listdir(self.bot_steps_directory) if f.endswith(".csv")], reverse=True)
            for file_name in step_files:
                bot_name = os.path.splitext(file_name)[0]
                schedule_info = self.schedules.get(bot_name)
                schedule_str = "Not Set"
                status_str = "Idle"
                if schedule_info:
                    schedule_str = f"{schedule_info.get('repeat', 'Once')} at {QDateTime.fromString(schedule_info.get('start_datetime'), Qt.DateFormat.ISODate).toString('yyyy-MM-dd hh:mm')}"
                    status_str = "Scheduled" if schedule_info.get("enabled") else "Disabled"

                tree_item = QTreeWidgetItem(self.saved_steps_tree, [bot_name, schedule_str, status_str])
            if not step_files:
                self.saved_steps_tree.addTopLevelItem(QTreeWidgetItem(["No saved bots found."]))
        except Exception as e:
            QMessageBox.critical(self, "Error Loading Saved Bots", f"Could not load bot files: {e}")

    def load_schedules(self):
        """Loads schedules from the JSON file."""
        schedule_file_path = os.path.join(self.schedules_directory, "schedules.json")
        if os.path.exists(schedule_file_path):
            try:
                with open(schedule_file_path, 'r', encoding='utf-8') as f:
                    self.schedules = json.load(f)
            except (json.JSONDecodeError, Exception) as e:
                self._log_to_console(f"Could not load schedules file: {e}")
                self.schedules = {}
        else:
            self.schedules = {}
    
    def _toggle_execute_one_step_button(self) -> None:
        self.execute_one_step_button.setEnabled(len(self.execution_tree.selectedItems()) > 0)

    def _rebuild_added_steps_data_from_tree(self):
        new_flat_data: List[Dict[str, Any]] = []
        self._flatten_tree_recursive(self.execution_tree.invisibleRootItem(), new_flat_data)
        self.added_steps_data = new_flat_data
        self._update_original_listbox_row_indices()
        selected_item_data = self._get_item_data(self.execution_tree.currentItem())
        self._rebuild_execution_tree(item_to_focus_data=selected_item_data)

    def _flatten_tree_recursive(self, parent_item: QTreeWidgetItem, flat_list: List[Dict[str, Any]]):
        for i in range(parent_item.childCount()):
            child_item = parent_item.child(i)
            step_data = self._get_item_data(child_item)
            if step_data and isinstance(step_data, dict):
                flat_list.append(step_data)
            self._flatten_tree_recursive(child_item, flat_list)

    def _update_original_listbox_row_indices(self):
        for i, step_data in enumerate(self.added_steps_data):
            step_data["original_listbox_row_index"] = i
            if step_data["type"] == "step" and "parameters_config" in step_data and step_data["parameters_config"] is not None:
                step_data["parameters_config"]["original_listbox_row_index"] = i

    def _get_expansion_state(self) -> set:
        """Recursively finds all expanded block items and returns their unique IDs."""
        expanded_ids = set()
        
        def traverse(parent_item):
            for i in range(parent_item.childCount()):
                child_item = parent_item.child(i)
                if child_item.isExpanded():
                    item_data = self._get_item_data(child_item)
                    if item_data:
                        item_id = item_data.get("group_id") or item_data.get("loop_id") or item_data.get("if_id")
                        if item_id:
                            expanded_ids.add(item_id)
                if child_item.childCount() > 0:
                    traverse(child_item)
    
        traverse(self.execution_tree.invisibleRootItem())
        return expanded_ids

    def _restore_expansion_state(self, expanded_ids: set):
        """Recursively traverses the tree and expands any items whose ID is in the provided set."""
        def traverse(parent_item):
            for i in range(parent_item.childCount()):
                child_item = parent_item.child(i)
                item_data = self._get_item_data(child_item)
                if item_data:
                    item_id = item_data.get("group_id") or item_data.get("loop_id") or item_data.get("if_id")
                    if item_id and item_id in expanded_ids:
                        self.execution_tree.expandItem(child_item)
                
                if child_item.childCount() > 0:
                    traverse(child_item)
        
        traverse(self.execution_tree.invisibleRootItem())
    
    def _rebuild_execution_tree(self, item_to_focus_data: Optional[Dict[str, Any]] = None) -> None:
        """Enhanced method that ensures proper centering in both tree and workflow canvas."""
        expanded_state = self._get_expansion_state()

        # Store the current selection before clearing
        previously_selected_index = None
        current_selected = self.execution_tree.selectedItems()
        if current_selected:
            previous_item_data = self._get_item_data(current_selected[0])
            if previous_item_data:
                previously_selected_index = previous_item_data.get("original_listbox_row_index")

        self.execution_tree.clear()
        self.data_to_item_map.clear()
        
        # CONNECT THE NEW TREE SIGNAL
        if hasattr(self.execution_tree, 'step_reorder_requested'):
            try:
                self.execution_tree.step_reorder_requested.disconnect()
            except TypeError:
                pass
        self.execution_tree.step_reorder_requested.connect(self._handle_step_reorder)
        
        current_parent_stack: List[QTreeWidgetItem] = [self.execution_tree.invisibleRootItem()]
        item_to_focus: Optional[QTreeWidgetItem] = None

        for i, step_data_dict in enumerate(self.added_steps_data):
            step_data_dict["original_listbox_row_index"] = i
            step_type = step_data_dict.get("type")

            if step_type == "group_end":
                if len(current_parent_stack) > 1:
                    last_parent_data = self._get_item_data(current_parent_stack[-1])
                    if last_parent_data and last_parent_data.get("type") == "group_start" and last_parent_data.get("group_id") == step_data_dict.get("group_id"):
                        current_parent_stack.pop()
            elif step_type == "loop_end":
                if len(current_parent_stack) > 1:
                    last_parent_data = self._get_item_data(current_parent_stack[-1])
                    if last_parent_data and last_parent_data.get("type") == "loop_start" and last_parent_data.get("loop_id") == step_data_dict.get("loop_id"):
                        current_parent_stack.pop()
            elif step_type == "IF_END":
                if len(current_parent_stack) > 1:
                    last_parent_data = self._get_item_data(current_parent_stack[-1])
                    if last_parent_data and last_parent_data.get("type") == "ELSE" and last_parent_data.get("if_id") == step_data_dict.get("if_id"):
                        current_parent_stack.pop()
                        if len(current_parent_stack) > 1:
                             if_start_parent_data = self._get_item_data(current_parent_stack[-1])
                             if if_start_parent_data and if_start_parent_data.get("type") == "IF_START" and if_start_parent_data.get("if_id") == step_data_dict.get("if_id"):
                                 current_parent_stack.pop()
                    elif last_parent_data and last_parent_data.get("type") == "IF_START" and last_parent_data.get("if_id") == step_data_dict.get("if_id"):
                        current_parent_stack.pop()

            parent_for_current_item = current_parent_stack[-1]
            tree_item = QTreeWidgetItem(parent_for_current_item)
            tree_item.setData(0, Qt.ItemDataRole.UserRole, QVariant(step_data_dict))
            
            self.data_to_item_map[i] = tree_item

            card = ExecutionStepCard(step_data_dict, i + 1)
            
            # Connect all signals
            card.edit_requested.connect(self._handle_edit_request)
            card.delete_requested.connect(self._handle_delete_request)
            card.move_up_requested.connect(self._handle_move_up_request)
            card.move_down_requested.connect(self._handle_move_down_request)
            card.save_as_template_requested.connect(self._handle_save_as_template_request)
            card.execute_this_requested.connect(self._handle_execute_this_request)
            card.step_drag_started.connect(self._handle_step_drag_started)
            card.step_reorder_requested.connect(self._handle_step_reorder)
            
            tree_item.setSizeHint(0, card.sizeHint())
            self.execution_tree.setItemWidget(tree_item, 0, card)

            if item_to_focus_data and step_data_dict == item_to_focus_data:
                item_to_focus = tree_item

            if step_type in ["loop_start", "IF_START", "ELSE", "group_start"]:
                current_parent_stack.append(tree_item)

        # --- ENHANCED FOCUS AND CENTERING LOGIC ---
        target_index_for_focus = None
        
        # Determine what index should be focused
        if item_to_focus_data:
            # Use explicitly requested item
            target_index_for_focus = item_to_focus_data.get("original_listbox_row_index")
            item_to_focus = self.data_to_item_map.get(target_index_for_focus)
        elif previously_selected_index is not None and previously_selected_index in self.data_to_item_map:
            # Use previously selected item
            target_index_for_focus = previously_selected_index
            item_to_focus = self.data_to_item_map[target_index_for_focus]
        elif self.added_steps_data:
            # Fallback to first step
            target_index_for_focus = 0
            item_to_focus = self.data_to_item_map.get(0)

        # Apply focus to execution tree
        if item_to_focus:
            self.execution_tree.setCurrentItem(item_to_focus)
            self.execution_tree.scrollToItem(item_to_focus, QtWidgets.QAbstractItemView.ScrollHint.PositionAtCenter)

        self.update_status_column_for_all_items()
        self._restore_expansion_state(expanded_state)
        self._update_workflow_tab(switch_to_tab=False)
        
        # --- FORCE WORKFLOW CANVAS CENTERING ---
        if target_index_for_focus is not None:
            # Schedule centering after the workflow tab update is complete
            def center_workflow_on_target():
                self._center_workflow_canvas_on_step(target_index_for_focus)
            
            QTimer.singleShot(200, center_workflow_on_target)
        
        self._save_workflow_to_temp_file()

    def _handle_edit_request(self, step_data_to_edit: Dict[str, Any]):
        item_to_edit = self._find_qtreewidget_item(step_data_to_edit)
        if item_to_edit:
            self.edit_step_in_execution_tree(item_to_edit, 0)
        else:
            idx = step_data_to_edit.get("original_listbox_row_index")
            if idx is not None and 0 <= idx < len(self.added_steps_data):
                item_from_map = self.data_to_item_map.get(idx)
                if item_from_map:
                    self.edit_step_in_execution_tree(item_from_map, 0)
                    return
            QMessageBox.critical(self, "Error", "Could not find the step to edit.")

    def _handle_delete_request(self, step_to_delete: Dict[str, Any]):
        step_type = step_to_delete.get("type")
        start_index = -1
        
        start_index = step_to_delete.get("original_listbox_row_index")
        if start_index is None or not (0 <= start_index < len(self.added_steps_data)) or self.added_steps_data[start_index].get("original_listbox_row_index") != start_index:
            try:
                start_index = self.added_steps_data.index(step_to_delete)
            except ValueError:
                 QMessageBox.critical(self, "Error", "Could not find step to delete in data list. Data may be out of sync.")
                 return

        if step_type in ["loop_start", "IF_START", "group_start"]:
            start_idx, end_idx = self._find_block_indices(start_index)
            if start_idx != end_idx: 
                items_to_remove_data = self.added_steps_data[start_idx : end_idx + 1]
            else: 
                items_to_remove_data = [step_to_delete]
        else:
            items_to_remove_data = [step_to_delete]

        if QMessageBox.question(self, "Confirm Delete", f"Are you sure you want to delete {len(items_to_remove_data)} selected step(s)?", QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No) == QMessageBox.StandardButton.Yes:
            self.added_steps_data = [s for s in self.added_steps_data if s not in items_to_remove_data]
            self._rebuild_execution_tree()
            self._save_workflow_to_temp_file() # <--- ADD THIS LINE
            
    def _find_block_indices(self, start_index: int) -> Tuple[int, int]:
        start_step = self.added_steps_data[start_index]
        step_type = start_step.get("type")

        if step_type not in ["loop_start", "IF_START", "group_start"]:
            return start_index, start_index

        if step_type == "group_start":
            block_id = start_step.get("group_id")
            end_type = "group_end"
        elif step_type == "loop_start":
            block_id = start_step.get("loop_id")
            end_type = "loop_end"
        else:
            block_id = start_step.get("if_id")
            end_type = "IF_END"

        nesting_level = 0
        for i in range(start_index + 1, len(self.added_steps_data)):
            current_step = self.added_steps_data[i]
            current_type = current_step.get("type")

            if current_type in ["loop_start", "IF_START", "group_start"]:
                nesting_level += 1
            elif current_type == end_type and (current_step.get("group_id") or current_step.get("loop_id") or current_step.get("if_id")) == block_id:
                if nesting_level == 0:
                    return start_index, i
                else:
                    nesting_level -= 1
            elif current_type in ["loop_end", "IF_END", "group_end"]:
                nesting_level -= 1
        return start_index, start_index

    def _handle_move_up_request(self, step_data: Dict[str, Any]):
        current_pos = step_data.get("original_listbox_row_index")
        if current_pos is None or not (0 <= current_pos < len(self.added_steps_data)) or self.added_steps_data[current_pos].get("original_listbox_row_index") != current_pos:
            try:
                current_pos = self.added_steps_data.index(step_data)
            except ValueError:
                 return
        
        if current_pos == 0:
            return
        start_idx, end_idx = self._find_block_indices(current_pos)
        
        prev_start_idx, prev_end_idx = self._find_block_indices(start_idx - 1) if (start_idx -1) >= 0 else (start_idx-1, start_idx-1)
        if prev_start_idx == -1:
            return
        
        part_before = self.added_steps_data[0:prev_start_idx]
        part_middle = self.added_steps_data[prev_start_idx : start_idx]
        part_after = self.added_steps_data[end_idx+1:]
        
        block_to_move = self.added_steps_data[start_idx : end_idx + 1]
        
        self.added_steps_data = part_before + block_to_move + part_middle + part_after
        self._rebuild_execution_tree(item_to_focus_data=block_to_move[0])
        self._save_workflow_to_temp_file() # <--- ADD THIS LINE

    def _handle_move_down_request(self, step_data: Dict[str, Any]):
        current_pos = step_data.get("original_listbox_row_index")
        if current_pos is None or not (0 <= current_pos < len(self.added_steps_data)) or self.added_steps_data[current_pos].get("original_listbox_row_index") != current_pos:
            try:
                current_pos = self.added_steps_data.index(step_data)
            except ValueError:
                 return

        start_idx, end_idx = self._find_block_indices(current_pos)
        if end_idx >= len(self.added_steps_data) - 1:
            return
        
        block_to_move = self.added_steps_data[start_idx : end_idx + 1]
        
        next_start_idx, next_end_idx = self._find_block_indices(end_idx+1)

        part_before = self.added_steps_data[0:start_idx]
        part_middle = self.added_steps_data[end_idx + 1 : next_end_idx + 1]
        part_after = self.added_steps_data[next_end_idx+1:]
        
        self.added_steps_data = part_before + part_middle + block_to_move + part_after
        self._rebuild_execution_tree(item_to_focus_data=block_to_move[0])
        self._save_workflow_to_temp_file() # <--- ADD THIS LINE

    def _get_template_names(self) -> List[str]:
        """Returns a sorted list of template names without extensions."""
        os.makedirs(self.steps_template_directory, exist_ok=True)
        return sorted([os.path.splitext(f)[0] for f in os.listdir(self.steps_template_directory) if f.endswith(".json")])

    def _handle_save_as_template_request(self, step_data_to_save: Dict[str, Any]):
        start_index = step_data_to_save.get("original_listbox_row_index")
        if start_index is None or not (0 <= start_index < len(self.added_steps_data)) or self.added_steps_data[start_index].get("original_listbox_row_index") != start_index:
            try:
                start_index = self.added_steps_data.index(step_data_to_save)
            except ValueError:
                 QMessageBox.critical(self, "Error", "Could not find the step to save as a template. Data may be out of sync.")
                 return

        start_idx, end_idx = self._find_block_indices(start_index)
        if start_idx == end_idx:
            QMessageBox.warning(self, "Save Error", "Cannot save a single step as a block template. The block is incomplete.")
            return
            
        block_to_save = self.added_steps_data[start_idx : end_idx + 1]

        existing_templates = self._get_template_names()
        dialog = SaveTemplateDialog(existing_templates, self)

        if dialog.exec() == QDialog.DialogCode.Accepted:
            template_name = dialog.get_template_name()
            if not template_name:
                return

            if template_name in existing_templates:
                reply = QMessageBox.question(self, "Confirm Overwrite", 
                                             f"A template named '{template_name}' already exists. Do you want to overwrite it?",
                                             QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No)
                if reply == QMessageBox.StandardButton.No:
                    return

            file_path = os.path.join(self.steps_template_directory, f"{template_name}.json")
            
            try:
                with open(file_path, 'w', encoding='utf-8') as f:
                    json.dump(block_to_save, f, indent=4)
                QMessageBox.information(self, "Success", f"Template '{template_name}' saved successfully.")
                self.load_all_modules_to_tree()
            except Exception as e:
                QMessageBox.critical(self, "Save Error", f"Failed to save the template:\n{e}")

    def _handle_execute_this_request(self, step_data: Dict[str, Any]):
        """
        Enhanced method to handle execution requests from workflow canvas.
        Now supports executing entire groups, loops, and if-blocks.
        """
        if not (step_data and isinstance(step_data, dict)):
            return

        current_row = step_data.get("original_listbox_row_index")
        if current_row is None or not (0 <= current_row < len(self.added_steps_data)):
            QMessageBox.critical(self, "Error", "Could not find the selected step in the internal data model. Data may be out of sync.")
            return

        # Clear all execution status before starting
        self._clear_all_execution_status()
        
        # Check the step type to determine execution strategy
        step_type = step_data.get("type")
        
        if step_type in ["group_start", "loop_start", "IF_START"]:
            # Execute the entire block
            self._execute_selected_block(current_row, step_type)
            
            # Log what we're executing
            if step_type == "group_start":
                block_name = f"Group '{step_data.get('group_name', 'Unknown')}'"
            elif step_type == "loop_start":
                loop_config = step_data.get('loop_config', {})
                block_name = f"Loop '{loop_config.get('loop_name', step_data.get('loop_id', 'Unknown'))}'"
            elif step_type == "IF_START":
                condition_config = step_data.get('condition_config', {})
                block_name = f"IF '{condition_config.get('block_name', step_data.get('if_id', 'Unknown'))}'"
            
            self._log_to_console(f"Workflow canvas: Executing {block_name} from right-click menu")
            
        elif step_type in ["group_end", "loop_end", "IF_END", "ELSE"]:
            # For end markers, find and execute the corresponding start block
            self._execute_end_marker_block(current_row, step_type)
            
        else:
            # Execute single step for regular steps
            self._execute_single_step_simple(current_row)
            step_name = step_data.get("method_name", f"Step {current_row + 1}")
            self._log_to_console(f"Workflow canvas: Executing single step '{step_name}' from right-click menu")

    def _execute_end_marker_block(self, end_marker_index: int, end_marker_type: str):
        """
        When user clicks on an end marker (group_end, loop_end, IF_END), 
        find the corresponding start and execute the entire block.
        """
        end_step_data = self.added_steps_data[end_marker_index]
        
        # Get the ID of the block
        if end_marker_type == "group_end":
            block_id = end_step_data.get("group_id")
            start_type = "group_start"
            block_name = f"Group '{end_step_data.get('group_name', block_id)}'"
        elif end_marker_type == "loop_end":
            block_id = end_step_data.get("loop_id") 
            start_type = "loop_start"
            loop_config = end_step_data.get('loop_config', {})
            block_name = f"Loop '{loop_config.get('loop_name', block_id)}'"
        elif end_marker_type == "IF_END":
            block_id = end_step_data.get("if_id")
            start_type = "IF_START"
            condition_config = end_step_data.get('condition_config', {})
            block_name = f"IF '{condition_config.get('block_name', block_id)}'"
        elif end_marker_type == "ELSE":
            block_id = end_step_data.get("if_id")
            start_type = "IF_START"
            condition_config = end_step_data.get('condition_config', {})
            block_name = f"IF '{condition_config.get('block_name', block_id)}'"
        else:
            QMessageBox.warning(self, "Execution Error", f"Cannot execute {end_marker_type} marker.")
            return
        
        if not block_id:
            QMessageBox.warning(self, "Execution Error", f"The {end_marker_type} marker has no valid block ID.")
            return
        
        # Find the corresponding start marker
        start_index = None
        nesting_level = 0
        
        # Search backwards from the end marker
        for i in range(end_marker_index - 1, -1, -1):
            step = self.added_steps_data[i]
            step_type = step.get("type")
            
            # Handle nesting by tracking end markers we encounter while going backwards
            if step_type in ["group_end", "loop_end", "IF_END"]:
                nesting_level += 1
            elif step_type == start_type:
                # Check if this start marker matches our block ID
                if step_type == "group_start" and step.get("group_id") == block_id:
                    if nesting_level == 0:
                        start_index = i
                        break
                    else:
                        nesting_level -= 1
                elif step_type == "loop_start" and step.get("loop_id") == block_id:
                    if nesting_level == 0:
                        start_index = i
                        break
                    else:
                        nesting_level -= 1
                elif step_type == "IF_START" and step.get("if_id") == block_id:
                    if nesting_level == 0:
                        start_index = i
                        break
                    else:
                        nesting_level -= 1
            elif step_type in ["group_start", "loop_start", "IF_START"]:
                nesting_level -= 1
        
        if start_index is None:
            QMessageBox.warning(self, "Execution Error", f"Could not find the corresponding {start_type} for this {end_marker_type}.")
            return
        
        # Execute the entire block
        self._execute_selected_block(start_index, start_type)
        self._log_to_console(f"Workflow canvas: Executing {block_name} (clicked on end marker)")

    def update_status_column_for_all_items(self):
        """Enhanced method to clear all execution status."""
        self._clear_all_execution_status()
        self._clear_status_recursive(self.execution_tree.invisibleRootItem())

    def _clear_status_recursive(self, parent_item: QTreeWidgetItem):
        """Enhanced method to clear visual status in tree."""
        for i in range(parent_item.childCount()):
            child = parent_item.child(i)
            card = self.execution_tree.itemWidget(child, 0)
            if card:
                card.set_status("#D3D3D3")  # Normal gray border, normal thickness
                card.clear_result()
            self._clear_status_recursive(child)

    def toggle_always_on_top(self) -> None:
        if self.always_on_top_button.isChecked():
            self.setWindowFlag(Qt.WindowType.WindowStaysOnTopHint, True)
            self.always_on_top_button.setText("📌 Always On Top: On")
        else:
            self.setWindowFlag(Qt.WindowType.WindowStaysOnTopHint, False)
            self.always_on_top_button.setText("📌 Always On Top: Off")
        self.show()

    def open_screenshot_tool(self, initial_image_name: str = "") -> None:
        self.hide()
        current_image_name_for_tool = self.label_info3.text() if self.label_info3.text() != "Image Name" else ""
        self.screenshot_window = SecondWindow(current_image_name_for_tool, base_dir=self.base_directory, parent=self)
        self.screenshot_window.screenshot_saved.connect(self._handle_screenshot_tool_closed)
        self.screenshot_window.show()

    def _handle_screenshot_tool_closed(self, saved_filename: str) -> None:
        self.show()
        self._log_to_console(f"Screenshot tool closed. Saved filename: '{saved_filename}'")
        if self.active_param_input_dialog and not self.active_param_input_dialog.isHidden():
            new_filenames = self._get_image_filenames()
            self.active_param_input_dialog.update_image_filenames.emit(new_filenames, saved_filename)
        elif self.active_param_input_dialog:
             self.active_param_input_dialog.show()
             new_filenames = self._get_image_filenames()
             self.active_param_input_dialog.update_image_filenames.emit(new_filenames, saved_filename)
    
# In MainWindow class
# REPLACE your existing load_all_modules_to_tree method with this one:

    def load_all_modules_to_tree(self) -> None:
        """
        Loads all modules and templates into the tree view.
        This version recursively scans the templates folder to build a hierarchical view.
        """
        self.module_tree.clear()
        self.module_filter_dropdown.clear()
        self.module_filter_dropdown.addItem("-- Show All Modules --")
        self.label_info1.setText("Module Info: Loading modules...")
        self.all_parsed_method_data.clear()

        # --- Part 1: Load Python Bot Modules (Unchanged) ---
        dummy_context = ExecutionContext()
        dummy_communicator = GuiCommunicator()
        dummy_context.set_gui_communicator(dummy_communicator)
        try:
            # ... (The entire try-finally block for loading .py modules remains identical to your original code)
            if self.module_directory not in sys.path:
                sys.path.insert(0, self.module_directory)
            if not os.path.exists(self.module_directory):
                QMessageBox.warning(self, "Module Folder Not Found", f"The '{self.module_subfolder}' folder was not found at: {self.module_directory}\nPlease create it and place your Python modules inside.")
                self.label_info1.setText("Error: Bot_module folder not found.")
                return
            module_files: List[str] = [filename[:-3] for filename in os.listdir(self.module_directory) if filename.endswith(".py") and filename != "__init__.py"]
            module_files.sort()
            if not module_files:
                self.label_info1.setText(f"No Python modules found in '{self.module_subfolder}' folder.")

            for module_name in module_files:
                self.all_parsed_method_data[module_name] = {}
                self.module_filter_dropdown.addItem(module_name)
                try:
                    module = importlib.import_module(module_name)
                    importlib.reload(module)
                    module_item = QTreeWidgetItem(self.module_tree)
                    module_item.setText(0, module_name)
                    module_item.setFlags(module_item.flags() & ~Qt.ItemFlag.ItemIsSelectable)
                    module_item.setToolTip(0, f"Module: {module_name}")

                    for name, obj in inspect.getmembers(module):
                        if (inspect.isclass(obj) and
                            obj.__module__ == module.__name__ and
                            not name.startswith('_')):
                            class_name = name
                            self.all_parsed_method_data[module_name][class_name] = []
                            class_item = QTreeWidgetItem(module_item)
                            class_item.setText(0, class_name)
                            class_item.setFlags(class_item.flags() & ~Qt.ItemFlag.ItemIsSelectable)
                            class_item.setToolTip(0, f"Class: {class_name} in {module_name}")
                            init_kwargs_for_inspection: Dict[str, Any] = {}
                            try:
                                init_signature = inspect.signature(obj.__init__)
                                if 'context' in init_signature.parameters:
                                    init_kwargs_for_inspection['context'] = dummy_context
                                temp_instance = obj(**init_kwargs_for_inspection)
                            except Exception as e:
                                self._log_to_console(f"Warning: Could not instantiate class '{class_name}' for inspection: {e}")
                                class_item.addChild(QTreeWidgetItem(["(Init error, cannot inspect methods)"]))
                                continue

                            for method_name, method_obj in inspect.getmembers(temp_instance):
                                if (not method_name.startswith('_') and callable(method_obj) and not inspect.isclass(method_obj) and not isinstance(method_obj, staticmethod) and not isinstance(method_obj, classmethod)):
                                    func_obj = method_obj.__func__ if inspect.ismethod(method_obj) else method_obj
                                    try:
                                        sig = inspect.signature(func_obj)
                                        params_for_dialog: Dict[str, Tuple[Any, Any]] = {p.name: (p.default, p.kind) for p in sig.parameters.values() if p.name not in ['self', 'context']}
                                        display_text = method_name
                                        method_info_tuple = (display_text, class_name, method_name, module_name, params_for_dialog)
                                        self.all_parsed_method_data[module_name][class_name].append(method_info_tuple)
                                        method_item = QTreeWidgetItem(class_item)
                                        method_item.setText(0, display_text)
                                        method_item.setToolTip(0, f"Method: {class_name}.{method_name}")
                                        method_item.setData(0, Qt.ItemDataRole.UserRole, QVariant(method_info_tuple))
                                    except Exception as e:
                                        self._log_to_console(f"Warning: Error inspecting '{class_name}.{method_name}': {e}")
                except Exception as e:
                    self._log_to_console(f"Error loading module '{module_name}': {e}")
        finally:
            if self.module_directory in sys.path:
                sys.path.remove(self.module_directory)


        # --- Part 2: Recursively Load Bot Templates (NEW and IMPROVED) ---
        template_root_item = QTreeWidgetItem(self.module_tree)
        template_root_item.setText(0, "Bot Templates")
        template_root_item.setToolTip(0, "Saved step templates. Right-click to create folders.")
        # Store data identifying this as the root for templates
        template_root_item.setData(0, Qt.ItemDataRole.UserRole, QVariant({'type': 'template_root'}))

        os.makedirs(self.steps_template_directory, exist_ok=True)
        self._load_templates_recursively(self.steps_template_directory, template_root_item)

        # --- Part 3: Final UI Updates (Unchanged) ---
        self.module_tree.collapseAll()
        self.label_info1.setText("Module Info: All modules loaded.")
        # This connection should already exist, but re-asserting it is safe
        self.module_tree.itemClicked.connect(self.update_selected_method_info)
# In MainWindow class
# ADD this new helper method

# In MainWindow class
# REPLACE the _load_templates_recursively method with this corrected version:

    def _load_templates_recursively(self, directory: str, parent_item: QTreeWidgetItem):
        """
        Recursively scans a directory for subdirectories (folders) and .json files (templates)
        and adds them to the parent_item in the tree.
        [CORRECTED VERSION]
        """
        try:
            # Ensure the directory exists before trying to list its contents
            if not os.path.isdir(directory):
                self._log_to_console(f"Warning: Template directory not found: {directory}")
                return

            items = sorted(os.listdir(directory))

            # Process subdirectories (folders) first
            for item_name in items:
                full_path = os.path.join(directory, item_name)
                if os.path.isdir(full_path):
                    try:
                        folder_item = QTreeWidgetItem(parent_item)
                        folder_item.setText(0, item_name)
                        # REMOVED: folder_item.setIcon(0, QIcon.style().standardIcon(QStyle.StandardPixmap.SP_DirIcon))
                        folder_item.setToolTip(0, f"Folder: {item_name}")

                        relative_path = os.path.relpath(full_path, self.steps_template_directory)
                        folder_item.setData(0, Qt.ItemDataRole.UserRole, QVariant({
                            'type': 'template_folder',
                            'name': item_name,
                            'path': relative_path
                        }))
                        
                        self._load_templates_recursively(full_path, folder_item)
                    except Exception as e:
                        # Add specific logging for an error on a single folder
                        self._log_to_console(f"Error processing template folder '{item_name}': {e}")


            # Then process files (templates)
            for item_name in items:
                full_path = os.path.join(directory, item_name)
                if os.path.isfile(full_path) and item_name.endswith(".json"):
                    try:
                        template_name = os.path.splitext(item_name)[0]
                        template_item = QTreeWidgetItem(parent_item)
                        template_item.setText(0, template_name)
                        # REMOVED: template_item.setIcon(0, QIcon.style().standardIcon(QStyle.StandardPixmap.SP_FileIcon))
                        template_item.setToolTip(0, f"Template: {template_name}")

                        relative_path = os.path.relpath(full_path, self.steps_template_directory)
                        template_item.setData(0, Qt.ItemDataRole.UserRole, QVariant({
                            'type': 'template',
                            'name': template_name,
                            'path': relative_path.replace(os.sep, '/')
                        }))
                    except Exception as e:
                         # Add specific logging for an error on a single file
                        self._log_to_console(f"Error processing template file '{item_name}': {e}")

        except Exception as e:
            # This is the generic error you saw. Now it will log the real cause.
            self._log_to_console(f"CRITICAL: Failed to load templates from '{directory}'. The error was: {e}")
            error_item = QTreeWidgetItem(parent_item)
            error_item.setText(0, "(Error loading templates - Check Log)")


    def filter_module_tree(self, index: int) -> None:
        selected_module_name = self.module_filter_dropdown.currentText()
        root = self.module_tree.invisibleRootItem()
        for i in range(root.childCount()):
            module_item = root.child(i)
            is_template_item = module_item.text(0) == "Bot Templates"
            if is_template_item:
                module_item.setHidden(not (selected_module_name == "-- Show All Modules --"))
            else:
                module_item.setHidden(not (selected_module_name == "-- Show All Modules --" or module_item.text(0) == selected_module_name))
        
        self.module_tree.collapseAll()

# In the MainWindow class

    def search_module_tree(self, text: str) -> None:
        """
        Enhanced search that filters the module tree.
        - Shows methods if they match.
        - Shows a class AND all its methods if the class name matches.
        - Shows a module AND all its contents if the module name matches.
        """
        search_text = text.lower()
        root = self.module_tree.invisibleRootItem()

        # Iterate through top-level items (Modules and Templates)
        for i in range(root.childCount()):
            module_item = root.child(i)
            module_text = module_item.text(0).lower()

            # If the module name itself matches, show everything inside it
            if search_text in module_text:
                module_item.setHidden(False)
                # Ensure all children are visible and expand the module
                for j in range(module_item.childCount()):
                    class_item = module_item.child(j)
                    class_item.setHidden(False)
                    for k in range(class_item.childCount()):
                        class_item.child(k).setHidden(False)
                module_item.setExpanded(True)
                continue

            # If the module name doesn't match, check its children (classes)
            module_has_visible_child = False
            for j in range(module_item.childCount()):
                class_item = module_item.child(j)
                class_text = class_item.text(0).lower()

                # If the class name matches, show the class and all its methods
                if search_text in class_text:
                    class_item.setHidden(False)
                    module_has_visible_child = True
                    # Make all methods under this class visible
                    for k in range(class_item.childCount()):
                        class_item.child(k).setHidden(False)
                    class_item.setExpanded(True)
                    continue

                # If the class name doesn't match, check its methods
                class_has_visible_child = False
                for k in range(class_item.childCount()):
                    method_item = class_item.child(k)
                    method_text = method_item.text(0).lower()
                    
                    # Show the method if it matches the search text
                    if search_text in method_text:
                        method_item.setHidden(False)
                        class_has_visible_child = True
                    else:
                        method_item.setHidden(True)
                
                # If any method was visible, the class and module must also be visible
                if class_has_visible_child:
                    class_item.setHidden(False)
                    class_item.setExpanded(True) # Expand the class to show the matched method
                    module_has_visible_child = True
                else:
                    class_item.setHidden(not class_has_visible_child)
            
            # Show or hide the module based on whether it has any visible children
            module_item.setHidden(not module_has_visible_child)
            if module_has_visible_child and search_text:
                module_item.setExpanded(True)

        # If the search box is empty, collapse all items
        if not search_text:
            self.module_tree.collapseAll()


    def saved_step_tree_item_selected(self, item: QTreeWidgetItem, column: int):
        """
        Enhanced version that immediately shows workflow when loading from saved bots list.
        """
        bot_name = item.text(0)
        if bot_name == "No saved bots found.":
            return

        file_path = os.path.join(self.bot_steps_directory, f"{bot_name}.csv")
        if os.path.exists(file_path):
            self.load_steps_from_file(file_path, bot_name)
            
            # The workflow will be automatically shown by load_steps_from_file
            # via the _update_and_show_workflow_after_load method
            
        else:
            QMessageBox.warning(self, "File Not Found", f"The selected bot file was not found:\n{file_path}")
            self.load_saved_steps_to_tree()

    def _extract_variables_from_steps(self, steps: List[Dict[str, Any]]) -> set:
        """Recursively finds all variable names used in a list of steps."""
        found_variables = set()

        def search_dict(d: Dict[str, Any]):
            if "assign_to_variable_name" in d and d["assign_to_variable_name"]:
                found_variables.add(d["assign_to_variable_name"])
            if "assign_iteration_to_variable" in d and d.get("assign_iteration_to_variable"):
                 found_variables.add(d["assign_iteration_to_variable"])
            
            if d.get("type") == "variable" and "value" in d:
                found_variables.add(d["value"])

            for key, value in d.items():
                if isinstance(value, dict):
                    search_dict(value)
                elif isinstance(value, list):
                    search_list(value)

        def search_list(lst: List[Any]):
            for item in lst:
                if isinstance(item, dict):
                    search_dict(item)
                elif isinstance(item, list):
                    search_list(item)
        
        search_list(steps)
        return found_variables
    
    def _apply_variable_mapping(self, steps: List[Dict[str, Any]], mapping: Dict[str, str]) -> List[Dict[str, Any]]:
        """Recursively replaces variable names in steps based on the provided mapping."""
        steps_copy = json.loads(json.dumps(steps))

        def replace_in_dict(d: Dict[str, Any]):
            if "assign_to_variable_name" in d and d["assign_to_variable_name"] in mapping:
                d["assign_to_variable_name"] = mapping[d["assign_to_variable_name"]]
            if "assign_iteration_to_variable" in d and d.get("assign_iteration_to_variable") in mapping:
                d["assign_iteration_to_variable"] = mapping[d["assign_iteration_to_variable"]]

            if d.get("type") == "variable" and d.get("value") in mapping:
                d["value"] = mapping[d["value"]]

            for key, value in d.items():
                if isinstance(value, dict):
                    replace_in_dict(value)
                elif isinstance(value, list):
                    replace_in_list(value)
        
        def replace_in_list(lst: List[Any]):
            for item in lst:
                if isinstance(item, dict):
                    replace_in_dict(item)
                elif isinstance(item, list):
                    replace_in_list(item)
        
        replace_in_list(steps_copy)
        return steps_copy

    def _load_template_by_name(self, template_relative_path: str) -> None:
        """Loads a template file, handles variable mapping, and inserts it into the execution tree."""
        # The path is now relative to the steps_template_directory
        file_path = os.path.join(self.steps_template_directory, template_relative_path)
        template_name_for_display = os.path.splitext(os.path.basename(template_relative_path))[0]

        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                template_steps = json.load(f)

            # ... The rest of the method is identical to your existing code ...
            if not template_steps:
                QMessageBox.warning(self, "Empty Template", "The selected template is empty.")
                return

            template_variables = self._extract_variables_from_steps(template_steps)
            mapped_steps = template_steps

            if template_variables:
                self._log_to_console(f"Template '{template_name_for_display}' contains variables: {template_variables}")
                var_dialog = TemplateVariableMappingDialog(template_variables, list(self.global_variables.keys()), self)
                if var_dialog.exec() == QDialog.DialogCode.Accepted:
                    mapping_result = var_dialog.get_mapping()
                    if mapping_result is None:
                        return
                    variable_map, new_vars = mapping_result
                    mapped_steps = self._apply_variable_mapping(template_steps, variable_map)
                    if new_vars:
                        self.global_variables.update(new_vars)
                        self._update_variables_list_display()
                        self._log_to_console(f"Added new global variables: {list(new_vars.keys())}")
                else:
                    self._log_to_console("Template loading cancelled by user at variable mapping stage.")
                    return

            re_id_d_steps = self._re_id_template_blocks(mapped_steps)
            insertion_dialog = StepInsertionDialog(self.execution_tree, parent=self)
            if insertion_dialog.exec() == QDialog.DialogCode.Accepted:
                selected_tree_item, insert_mode = insertion_dialog.get_insertion_point()
                insert_data_index = self._calculate_flat_insertion_index(selected_tree_item, insert_mode)
                self.added_steps_data[insert_data_index:insert_data_index] = re_id_d_steps
                self._sync_counters_with_loaded_data()
                self._rebuild_execution_tree(item_to_focus_data=re_id_d_steps[0])
                self._save_workflow_to_temp_file()
                self._log_to_console(f"Loaded template '{template_name_for_display}' with {len(re_id_d_steps)} steps.")
                workflow_tab_index = self.main_tab_widget.indexOf(self.workflow_scroll_area.parentWidget())
                if self.main_tab_widget.currentIndex() != workflow_tab_index:
                    self.main_tab_widget.setCurrentWidget(self.execution_tree.parentWidget())

        except FileNotFoundError:
            QMessageBox.critical(self, "Load Error", f"Template file not found:\n{file_path}")
        except json.JSONDecodeError:
            QMessageBox.critical(self, "Load Error", f"The template file '{template_name_for_display}.json' is corrupted.")
        except Exception as e:
            QMessageBox.critical(self, "Load Error", f"An unexpected error occurred while loading the template:\n{e}")

            
    def _re_id_template_blocks(self, template_steps: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        id_map = {}
        
        for step in template_steps:
            step_type = step.get("type")
            if step_type == "loop_start":
                old_id = step.get("loop_id")
                if old_id and old_id not in id_map:
                    self.loop_id_counter += 1
                    id_map[old_id] = f"loop_{self.loop_id_counter}"
            elif step_type == "IF_START":
                old_id = step.get("if_id")
                if old_id and old_id not in id_map:
                    self.if_id_counter += 1
                    id_map[old_id] = f"if_{self.if_id_counter}"
            elif step_type == "group_start":
                old_id = step.get("group_id")
                if old_id and old_id not in id_map:
                    self.group_id_counter += 1
                    id_map[old_id] = f"group_{self.group_id_counter}"
        
        for step in template_steps:
            if "loop_id" in step and step["loop_id"] in id_map:
                step["loop_id"] = id_map[step["loop_id"]]
            if "if_id" in step and step["if_id"] in id_map:
                step["if_id"] = id_map[step["if_id"]]
            if "group_id" in step and step["group_id"] in id_map:
                step["group_id"] = id_map[step["group_id"]]
                
        return template_steps

    def update_selected_method_info(self, item: QTreeWidgetItem, column: int) -> None:
        method_info_tuple = self._get_item_data(item)
        self.label_info2.clear()
        if method_info_tuple and isinstance(method_info_tuple, tuple) and len(method_info_tuple) == 5:
            display_text, class_name, method_name, module_name, params_for_dialog = method_info_tuple
            self.gui_communicator.update_module_info_signal.emit("")
        else:
            pass

# In main_app.py
# Replace the entire add_item_to_execution_tree method

# In MainWindow class
# REPLACE the entire add_item_to_execution_tree method with this one:

    def add_item_to_execution_tree(self, item: QTreeWidgetItem, column: int) -> None:
        item_data = self._get_item_data(item)

        # --- Handle Template Loading ---
        if isinstance(item_data, dict) and item_data.get('type') == 'template':
            # --- THIS IS THE FIX ---
            # Get the full relative path (e.g., "Folder/MyTemplate.json") from the item data.
            # This was the bug: it was previously just getting the name.
            template_path = item_data.get('path')
            if template_path:
                self._load_template_by_name(template_path)
            # --- END OF FIX ---
            return

        # --- The rest of the method for regular module steps remains the same ---
        if not (item_data and isinstance(item_data, tuple) and len(item_data) == 5):
            return

        display_text, class_name, method_name, module_name, params_for_dialog = item_data

        if method_name == "configure_data_hub":
            try:
                if self.module_directory not in sys.path:
                    sys.path.insert(0, self.module_directory)
                module = importlib.import_module(module_name)
                importlib.reload(module)
                class_obj = getattr(module, class_name)
                dummy_context = ExecutionContext()
                dummy_context.set_gui_communicator(self.gui_communicator)
                instance = class_obj(context=dummy_context)
                dialog = instance.configure_data_hub(
                    parent_window=self,
                    global_variables=list(self.global_variables.keys())
                )
                if dialog.exec() == QDialog.DialogCode.Accepted:
                    config_data = dialog.get_config_data()
                    executor_method_name = dialog.get_executor_method_name()
                    assign_to_variable_name = dialog.get_assignment_variable()
                    if config_data is None:
                        self._log_to_console("Custom configuration was cancelled or invalid.")
                        return
                    if assign_to_variable_name and assign_to_variable_name not in self.global_variables:
                        self.global_variables[assign_to_variable_name] = None
                        self._update_variables_list_display()
                    parameters_config = {
                        "config_data": {"type": "hardcoded", "value": config_data}
                    }
                    new_step_data_dict: Dict[str, Any] = {
                        "type": "step",
                        "class_name": class_name,
                        "method_name": executor_method_name,
                        "module_name": module_name,
                        "parameters_config": parameters_config,
                        "assign_to_variable_name": assign_to_variable_name,
                        "custom_config_method": method_name
                    }
                    insertion_dialog = StepInsertionDialog(self.execution_tree, parent=self)
                    if insertion_dialog.exec() == QDialog.DialogCode.Accepted:
                        selected_tree_item, insert_mode = insertion_dialog.get_insertion_point()
                        insert_data_index = self._calculate_flat_insertion_index(selected_tree_item, insert_mode)
                        self.added_steps_data.insert(insert_data_index, new_step_data_dict)
                        self._rebuild_execution_tree(item_to_focus_data=new_step_data_dict)
                        self._save_workflow_to_temp_file()
                        self.main_tab_widget.setCurrentIndex(self.workflow_tab_index)
                    self._log_to_console(f"Added custom step '{class_name}.{executor_method_name}'")
            except Exception as e:
                QMessageBox.critical(self, "Custom Module Error", f"Could not load custom configuration GUI:\n{e}")
                self._log_to_console(f"ERROR: {e}")
            finally:
                if self.module_directory in sys.path:
                    sys.path.remove(self.module_directory)
            return

        method_docstring = ""
        try:
            if self.module_directory not in sys.path:
                sys.path.insert(0, self.module_directory)
            module = importlib.import_module(module_name)
            importlib.reload(module)
            class_obj = getattr(module, class_name)
            init_kwargs_for_inspection: Dict[str, Any] = {}
            if 'context' in inspect.signature(class_obj.__init__).parameters:
                init_kwargs_for_inspection['context'] = ExecutionContext()
            temp_instance = class_obj(**init_kwargs_for_inspection)
            method_func_obj = getattr(temp_instance, method_name)
            method_docstring = inspect.getdoc(method_func_obj) or ""
        except Exception as e:
            self._log_to_console(f"Warning: Could not retrieve docstring for {class_name}.{method_name}: {e}")
        finally:
            if self.module_directory in sys.path:
                sys.path.remove(self.module_directory)

        self.active_param_input_dialog = ParameterInputDialog(
            f"{class_name}.{method_name}",
            params_for_dialog,
            list(self.global_variables.keys()),
            self._get_image_filenames(),
            self.gui_communicator,
            parent=self,
            method_docstring=method_docstring
        )
        self.active_param_input_dialog.request_screenshot.connect(self._handle_screenshot_request_from_param_dialog)

        if self.active_param_input_dialog.exec() == QDialog.DialogCode.Accepted:
            parameters_config = self.active_param_input_dialog.get_parameters_config()
            if parameters_config is None:
                self.gui_communicator.update_module_info_signal.emit("")
                return
            assign_to_variable_name = self.active_param_input_dialog.get_assignment_variable()
        else:
            self.gui_communicator.update_module_info_signal.emit("")
            return

        if assign_to_variable_name and assign_to_variable_name not in self.global_variables:
            self.global_variables[assign_to_variable_name] = None
            self._update_variables_list_display()

        new_step_data_dict: Dict[str, Any] = {
            "type": "step",
            "class_name": class_name,
            "method_name": method_name,
            "module_name": module_name,
            "parameters_config": parameters_config,
            "assign_to_variable_name": assign_to_variable_name
        }

        insertion_dialog = StepInsertionDialog(self.execution_tree, parent=self)
        if insertion_dialog.exec() == QDialog.DialogCode.Accepted:
            selected_tree_item, insert_mode = insertion_dialog.get_insertion_point()
            insert_data_index = self._calculate_flat_insertion_index(selected_tree_item, insert_mode)
            self.added_steps_data.insert(insert_data_index, new_step_data_dict)
            self._rebuild_execution_tree(item_to_focus_data=new_step_data_dict)
            self._save_workflow_to_temp_file()
            self.main_tab_widget.setCurrentIndex(self.workflow_tab_index)

        self.gui_communicator.update_module_info_signal.emit("")
        self.active_param_input_dialog = None

# In the MainWindow class

    def _calculate_flat_insertion_index(self, selected_tree_item: Optional[QTreeWidgetItem], insert_mode: str) -> int:
        """Enhanced method that always allows before/after insertion."""
        return self._calculate_smart_insertion_index(selected_tree_item, insert_mode)


    def add_loop_block(self) -> None:
        dialog = LoopConfigDialog(self.global_variables, parent=self)
        if dialog.exec() == QDialog.DialogCode.Accepted:
            loop_config = dialog.get_config()
            if loop_config is None:
                return

            new_iter_var = loop_config.get("assign_iteration_to_variable")
            if new_iter_var and new_iter_var not in self.global_variables:
                self.global_variables[new_iter_var] = None
                self._update_variables_list_display()

            self.loop_id_counter += 1
            loop_id = f"loop_{self.loop_id_counter}"
            new_loop_start_data: Dict[str, Any] = {"type": "loop_start", "loop_id": loop_id, "loop_config": loop_config}
            insertion_dialog = StepInsertionDialog(self.execution_tree, parent=self)
            if insertion_dialog.exec() == QDialog.DialogCode.Accepted:
                selected_tree_item, insert_mode = insertion_dialog.get_insertion_point()
                insert_data_index = self._calculate_flat_insertion_index(selected_tree_item, insert_mode)
                self.added_steps_data.insert(insert_data_index, new_loop_start_data)
                loop_end_data_dict = {"type": "loop_end", "loop_id": loop_id, "loop_config": loop_config}
                self.added_steps_data.insert(insert_data_index + 1, loop_end_data_dict)
                self._update_original_listbox_row_indices()
                self._rebuild_execution_tree(item_to_focus_data=new_loop_start_data)
                self._save_workflow_to_temp_file() # <--- ADD THIS LINE

    def add_conditional_block(self) -> None:
        dialog = ConditionalConfigDialog(self.global_variables, parent=self)
        if dialog.exec() == QDialog.DialogCode.Accepted:
            conditional_config = dialog.get_config()
            if conditional_config is None:
                return
            self.if_id_counter += 1
            if_id = f"if_{self.if_id_counter}"
            new_if_start_data: Dict[str, Any] = {"type": "IF_START", "if_id": if_id, "condition_config": conditional_config}
            new_else_data: Dict[str, Any] = {"type": "ELSE", "if_id": if_id, "condition_config": conditional_config}
            new_if_end_data: Dict[str, Any] = {"type": "IF_END", "if_id": if_id, "condition_config": conditional_config}
            insertion_dialog = StepInsertionDialog(self.execution_tree, parent=self)
            if insertion_dialog.exec() == QDialog.DialogCode.Accepted:
                selected_tree_item, insert_mode = insertion_dialog.get_insertion_point()
                insert_data_index = self._calculate_flat_insertion_index(selected_tree_item, insert_mode)
                self.added_steps_data.insert(insert_data_index, new_if_start_data)
                self.added_steps_data.insert(insert_data_index + 1, new_else_data)
                self.added_steps_data.insert(insert_data_index + 2, new_if_end_data)
                self._update_original_listbox_row_indices()
                self._rebuild_execution_tree(item_to_focus_data=new_if_start_data)
                self._save_workflow_to_temp_file() # <--- ADD THIS LINE
                
# In the MainWindow class, REPLACE the existing group_selected_steps method with this one:

    def group_selected_steps(self) -> None:
        selected_items = self.execution_tree.selectedItems()
        if not selected_items:
            QMessageBox.information(self, "No Selection", "Please select one or more steps to group.")
            return

        group_name, ok = QInputDialog.getText(self, "Create Group", "Enter a name for the group:")
        if ok and group_name:
            
            # --- FIX STARTS HERE: Correct logic for multi-selection ---
            selected_data = [self._get_item_data(item) for item in selected_items]
            
            # Find the min and max original_listbox_row_index from the selection
            try:
                indices = [d.get("original_listbox_row_index") for d in selected_data if d and d.get("original_listbox_row_index") is not None]
                if not indices:
                    QMessageBox.critical(self, "Error", "Could not identify the selected items. Data may be out of sync.")
                    return
                
                start_index = min(indices)
                last_item_index_in_selection = max(indices)

            except Exception as e:
                QMessageBox.critical(self, "Error", f"Could not process selected items for grouping: {e}")
                return

            # Find the full block of the last selected item to ensure we wrap the whole thing
            _, end_index = self._find_block_indices(last_item_index_in_selection)
            # --- FIX ENDS HERE ---

            self.group_id_counter += 1
            group_id = f"group_{self.group_id_counter}"
            
            group_start_data = {"type": "group_start", "group_id": group_id, "group_name": group_name}
            # --- THIS IS THE MODIFICATION ---
            group_end_data = {"type": "group_end", "group_id": group_id, "group_name": group_name}
            # --- END MODIFICATION ---

            # Insert the 'group_start' data before the first selected item
            self.added_steps_data.insert(start_index, group_start_data)
            
            # Insert the 'group_end' data after the last selected item.
            # We must add 1 because we already inserted the start item, shifting all subsequent indices.
            self.added_steps_data.insert(end_index + 2, group_end_data)

            self._rebuild_execution_tree(item_to_focus_data=group_start_data)
            self._save_workflow_to_temp_file() # <--- ADD THIS LINE

    def edit_step_in_execution_tree(self, item: QTreeWidgetItem, column: int) -> None:
        step_data_dict = self._get_item_data(item)
        if not step_data_dict or not isinstance(step_data_dict, dict):
            QMessageBox.warning(self, "Invalid Item", "Cannot edit this item type or no data found.")
            return
        step_type = step_data_dict["type"]
        current_row = -1

        current_row = step_data_dict.get("original_listbox_row_index")
        if current_row is None or not (0 <= current_row < len(self.added_steps_data)) or self.added_steps_data[current_row].get("original_listbox_row_index") != current_row:
            try:
                current_row = self.added_steps_data.index(step_data_dict)
            except ValueError:
                 QMessageBox.critical(self, "Error", "Could not find selected item in internal data model for editing. Data may be out of sync.")
                 return
        
        # =================================================================
        # --- ROBUST BLOCK FOR EDITING CUSTOM GUI MODULES ---
        # =================================================================
        
        custom_config_method_name = step_data_dict.get("custom_config_method")
        executor_method_name = step_data_dict.get("method_name")

        if not custom_config_method_name:
            if executor_method_name == "_execute_data_hub_task":
                custom_config_method_name = "configure_data_hub"

        if custom_config_method_name:
            try:
                # 1. Get all the data we need from the saved step
                class_name = step_data_dict["class_name"]
                module_name = step_data_dict["module_name"]
                
                # --- THIS IS THE FIX ---
                # Safely get the initial config, handling None at each step
                params_config = step_data_dict.get("parameters_config")
                config_data_val = params_config.get("config_data") if params_config else None
                initial_config = config_data_val.get("value") if config_data_val else None
                
                # If it's still None, default to an empty dict so the dialog can open
                if initial_config is None:
                    initial_config = {}
                    self._log_to_console("Warning: Step has no config. Opening with defaults.")
                # --- END FIX ---
                
                initial_variable = step_data_dict.get("assign_to_variable_name")

                # 2. Import the module and get the class instance
                if self.module_directory not in sys.path:
                    sys.path.insert(0, self.module_directory)
                module = importlib.import_module(module_name)
                importlib.reload(module)
                class_obj = getattr(module, class_name)
                
                dummy_context = ExecutionContext()
                dummy_context.set_gui_communicator(self.gui_communicator)
                instance = class_obj(context=dummy_context)
                
                # 3. Get the magic config method (e.g., "configure_data_hub")
                config_method = getattr(instance, custom_config_method_name)

                # 4. Call it, passing in the initial config data
                dialog = config_method(
                    parent_window=self,
                    global_variables=list(self.global_variables.keys()),
                    initial_config=initial_config,
                    initial_variable=initial_variable
                )

                # 5. Run the dialog and get the *new* data
                if dialog.exec() == QDialog.DialogCode.Accepted:
                    # Get the configuration from the dialog
                    new_config_data = dialog.get_config_data()
                    
                    # Check if the configuration itself is invalid (e.g., user left a required field blank)
                    if new_config_data is None:
                        self._log_to_console("Custom configuration was cancelled or contained invalid data.")
                        return # Exit if config is bad
                        
                    # These can now be safely called, as we know the config is valid
                    new_executor_method_name = dialog.get_executor_method_name()
                    new_assign_to_variable_name = dialog.get_assignment_variable() # This is ALLOWED to be None

                    # Handle variable changes (this part is fine)
                    if new_assign_to_variable_name and new_assign_to_variable_name not in self.global_variables:
                        self.global_variables[new_assign_to_variable_name] = None
                        self._update_variables_list_display()

                    # Update the step data in our main list (this part will now be reached)
                    new_parameters_config = {"config_data": {"type": "hardcoded", "value": new_config_data}}
                    self.added_steps_data[current_row].update({
                        "parameters_config": new_parameters_config,
                        "assign_to_variable_name": new_assign_to_variable_name,
                        "method_name": new_executor_method_name,
                        "custom_config_method": custom_config_method_name
                    })
                    
                    # Rebuild the UI to show the changes
                    self._rebuild_execution_tree(item_to_focus_data=self.added_steps_data[current_row])
                    self._save_workflow_to_temp_file()
                
            except Exception as e:
                QMessageBox.critical(self, "Custom Module Error", f"Could not load custom configuration GUI for editing:\n{e}")
                self._log_to_console(f"ERROR: {e}")
            finally:
                if self.module_directory in sys.path:
                    sys.path.remove(self.module_directory)
            return

        # =================================================================
        # --- END OF CUSTOM GUI BLOCK ---
        # =================================================================

        elif step_type == "step":
            class_name, method_name, module_name = step_data_dict["class_name"], step_data_dict["method_name"], step_data_dict["module_name"]
            
            # --- THIS IS THE FIX ---
            # Safely get parameters, defaulting to an empty dict if None
            parameters_config_with_index = step_data_dict.get("parameters_config")
            if parameters_config_with_index is None:
                self._log_to_console(f"Warning: Step '{method_name}' has no parameters. Opening with defaults.")
                parameters_config_with_index = {}
            # --- END FIX ---
                
            assign_to_variable_name = step_data_dict.get("assign_to_variable_name")
            dialog_parameters_config = {k: v for k, v in parameters_config_with_index.items() if k != "original_listbox_row_index"}
            method_docstring = ""
       
            try:
                if self.module_directory not in sys.path:
                    sys.path.insert(0, self.module_directory)
                module = importlib.import_module(module_name)
                importlib.reload(module)
                class_obj = getattr(module, class_name)
                init_kwargs_for_inspection: Dict[str, Any] = {}
                if 'context' in inspect.signature(class_obj.__init__).parameters:
                    init_kwargs_for_inspection['context'] = ExecutionContext()
                temp_instance = class_obj(**init_kwargs_for_inspection)
                method_func_obj = getattr(temp_instance, method_name)
                func_to_inspect = method_func_obj.__func__ if inspect.ismethod(method_func_obj) else method_func_obj
                sig = inspect.signature(func_to_inspect)
                params_for_dialog: Dict[str, Tuple[Any, Any]] = {p.name: (p.default, p.kind) for p in sig.parameters.values() if p.name not in ['self', 'context']}
                
                method_docstring = inspect.getdoc(method_func_obj) or ""
                
            except Exception as e:
                QMessageBox.critical(self, "Error Editing Step", f"Could not re-inspect method for editing:\n{e}")
                return
            finally:
                if self.module_directory in sys.path:
                    sys.path.remove(self.module_directory)
                    
            self.active_param_input_dialog = ParameterInputDialog(f"{class_name}.{method_name}", 
            params_for_dialog, 
            list(self.global_variables.keys()), 
            self._get_image_filenames(), 
            self.gui_communicator, 
            initial_parameters_config=dialog_parameters_config, 
            initial_assign_to_variable_name=assign_to_variable_name, 
            method_docstring=method_docstring,
            parent=self)
            self.active_param_input_dialog.request_screenshot.connect(self._handle_screenshot_request_from_param_dialog)
            if self.active_param_input_dialog.exec() == QDialog.DialogCode.Accepted:
                new_parameters_config = self.active_param_input_dialog.get_parameters_config()
                if new_parameters_config is None:
                    self.gui_communicator.update_module_info_signal.emit("")
                    return
                new_assign_to_variable_name = self.active_param_input_dialog.get_assignment_variable()
                
                if new_assign_to_variable_name and new_assign_to_variable_name not in self.global_variables:
                    self.global_variables[new_assign_to_variable_name] = None
                    self._update_variables_list_display()
                
                self.added_steps_data[current_row].update({"parameters_config": new_parameters_config, "assign_to_variable_name": new_assign_to_variable_name})
                self._rebuild_execution_tree(item_to_focus_data=self.added_steps_data[current_row])
                self._save_workflow_to_temp_file()
            self.gui_communicator.update_module_info_signal.emit("")
            self.active_param_input_dialog = None
        elif step_type == "loop_start":
            loop_config = step_data_dict["loop_config"]
            dialog = LoopConfigDialog(self.global_variables, parent=self, initial_config=loop_config)
            if dialog.exec() == QDialog.DialogCode.Accepted:
                new_loop_config = dialog.get_config()
                if new_loop_config is None:
                    return

                new_iter_var = new_loop_config.get("assign_iteration_to_variable")
                if new_iter_var and new_iter_var not in self.global_variables:
                    self.global_variables[new_iter_var] = None
                    self._update_variables_list_display()

                self.added_steps_data[current_row]["loop_config"] = new_loop_config
                loop_id, nesting_level = step_data_dict["loop_id"], 0
                for idx in range(current_row + 1, len(self.added_steps_data)):
                    step = self.added_steps_data[idx]
                    if step.get("type") in ["loop_start", "IF_START"]:
                        nesting_level += 1
                    elif step.get("type") == "loop_end" and nesting_level == 0 and step.get("loop_id") == loop_id:
                        self.added_steps_data[idx]["loop_config"] = new_loop_config
                        break
                    elif step.get("type") in ["loop_end", "IF_END"]:
                        nesting_level -= 1
                self._rebuild_execution_tree(item_to_focus_data=self.added_steps_data[current_row])
                self._save_workflow_to_temp_file()
        elif step_type == "IF_START":
            condition_config = step_data_dict["condition_config"]
            dialog = ConditionalConfigDialog(self.global_variables, parent=self, initial_config=condition_config)
            if dialog.exec() == QDialog.DialogCode.Accepted:
                new_conditional_config = dialog.get_config()
                if new_conditional_config is None:
                    return
                self.added_steps_data[current_row]["condition_config"] = new_conditional_config
                if_id, nesting_level = step_data_dict["if_id"], 0
                for idx in range(current_row + 1, len(self.added_steps_data)):
                    step = self.added_steps_data[idx]
                    if step.get("type") in ["loop_start", "IF_START"]:
                        nesting_level += 1
                    elif nesting_level == 0 and step.get("if_id") == if_id:
                        if step.get("type") == "ELSE":
                            self.added_steps_data[idx]["condition_config"] = new_conditional_config
                        elif step.get("type") == "IF_END":
                            self.added_steps_data[idx]["condition_config"] = new_conditional_config
                            break
                    elif step.get("type") in ["loop_end", "IF_END"]:
                        nesting_level -= 1
                self._rebuild_execution_tree(item_to_focus_data=self.added_steps_data[current_row])
                self._save_workflow_to_temp_file()
        elif step_type == "group_start":
            group_name = step_data_dict.get("group_name", "")
            new_name, ok = QInputDialog.getText(self, "Rename Group", "Enter new group name:", text=group_name)
            if ok and new_name:
                self.added_steps_data[current_row]["group_name"] = new_name
                self._rebuild_execution_tree(item_to_focus_data=self.added_steps_data[current_row])
                self._save_workflow_to_temp_file()
        elif step_type in ["loop_end", "ELSE", "IF_END", "group_end"]:
            QMessageBox.information(self, "Edit Block Marker", "To change parameters, edit the corresponding 'Start' block.")

    def clear_selected_steps(self) -> None:
        selected_items = self.execution_tree.selectedItems()
        if not selected_items:
            QMessageBox.information(self, "No Selection", "Please select steps to clear.")
            return
        if QMessageBox.question(self, "Confirm Clear", f"Are you sure you want to remove {len(selected_items)} selected step(s)? This may break block structures.", QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No) == QMessageBox.StandardButton.Yes:
            selected_step_data = [self._get_item_data(item) for item in selected_items]
            self.added_steps_data = [s for s in self.added_steps_data if s not in selected_step_data]
            self._rebuild_execution_tree()
            self._save_workflow_to_temp_file() # <--- ADD THIS LINE

    def _internal_clear_all_steps(self):
            self.execution_tree.clear()
            self.added_steps_data.clear()
            self.global_variables.clear()
            self.group_expansion_states.clear() # <<< ADD THIS LINE
            self._update_variables_list_display()
            self.progress_bar.setValue(0)
            self.progress_bar.hide()
            self.set_ui_enabled_state(True)
            self.loop_id_counter = 0
            self.if_id_counter = 0
            self.group_id_counter = 0
            
            self.execution_flow_label.setText("Execution Flow")
            
            self._log_to_console("Internal clear all steps executed.")
            self._update_workflow_tab(switch_to_tab=False)
# In MainWindow class
# In MainWindow class
    def clear_all_steps(self) -> None:
        if not self.added_steps_data and not self.global_variables:
            QMessageBox.information(self, "Info", "The execution queue and variables are already empty.")
            return

        # --- NEW SAVE PROMPT LOGIC ---
        # Only ask to save if there is data *and* we are NOT in the default "untitled" state
        is_working_on_saved_bot = (self.current_temp_file_path != self.default_temp_file_path)
        
        if is_working_on_saved_bot:
            # We are working on a named bot, so ask to save first.
            current_bot_name = os.path.splitext(os.path.basename(self.current_temp_file_path))[0]
            
            reply = QMessageBox.question(self, "Save Changes",
                                         f"Do you want to save your changes to '{current_bot_name}' before creating a new bot?",
                                         QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No | QMessageBox.StandardButton.Cancel,
                                         QMessageBox.StandardButton.Cancel)

            if reply == QMessageBox.StandardButton.Yes:
                # User wants to save. Call the save dialog.
                self.save_bot_steps_dialog()
                
                # Check if the save was cancelled (by checking if the temp path was reset)
                # If save_bot_steps_dialog was successful, self.current_temp_file_path is still set to "MyBot.json"
                # If the user cancelled the save dialog, we should also cancel the "clear all"
                if self.current_temp_file_path == self.default_temp_file_path:
                    # This implies the save dialog was opened but cancelled.
                    self._log_to_console("Save was cancelled. 'Clear All' operation aborted.")
                    return # Abort the clear operation
            
            elif reply == QMessageBox.StandardButton.Cancel:
                self._log_to_console("'Clear All' operation cancelled by user.")
                return # User cancelled, do nothing
            
            # If user clicked "No", we just proceed to clear.

        else:
            # We are in the "untitled" state. Just ask for a simple confirmation.
            if QMessageBox.question(self, "Confirm Remove All", "Are you sure you want to remove ALL steps and variables?", 
                                    QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No) != QMessageBox.StandardButton.Yes:
                return # User said no, abort.
        # --- END NEW SAVE PROMPT LOGIC ---

        # If we got this far, the user either saved, clicked "No" to saving,
        # or confirmed clearing an "untitled" workflow.
        
        # Now, we safely reset the app to a blank, untitled state.
        self._reset_to_untitled_state()

# In the MainWindow class
# In MainWindow class
# REPLACE your existing _handle_execute_pause_resume method with this one:
# In MainWindow class
    def _load_data_from_csv(self, file_path: str) -> Optional[Tuple[Dict[str, Any], List[Dict[str, Any]]]]:
        """
        Reads a .csv bot file and returns its variables and steps.
        Returns None if the file cannot be read.
        """
        if not os.path.exists(file_path):
            self._log_to_console(f"Error: Could not find file to read: {file_path}")
            return None
            
        try:
            section = None
            loaded_variables, loaded_steps = {}, []
            with open(file_path, 'r', newline='', encoding='utf-8') as csvfile:
                reader = csv.reader(csvfile)
                for row_num, row in enumerate(reader):
                    if not row: continue
                    
                    header = row[0]
                    if header == "__SCHEDULE_INFO__":
                        section = "SCHEDULE"
                        continue
                    elif header == "__GLOBAL_VARIABLES__":
                        section = "VARIABLES"
                        continue
                    elif header == "__BOT_STEPS__":
                        section = "STEPS"
                        next(reader, None)  # Skip the header row
                        continue
                    
                    if section == "SCHEDULE":
                        pass  # We don't need schedule info for this
                    elif section == "VARIABLES":
                        if len(row) == 2:
                            loaded_variables[row[0]] = json.loads(row[1])
                    elif section == "STEPS":
                        if len(row) == 2:
                            loaded_steps.append(json.loads(row[1]))

            return loaded_variables, loaded_steps

        except Exception as e:
            self._log_to_console(f"Error reading .csv file {file_path}: {e}")
            return None
            
# In MainWindow class
    def _compare_csv_and_json(self, csv_path: str, json_path: str) -> bool:
        """
        Compares a .csv bot file and a .json backup file.
        Returns True if the .json file has changes not present in the .csv file.
        Returns False if they are identical or if the .json doesn't exist.
        """
        if not os.path.exists(json_path):
            return False # No .json backup, so no changes to recover

        try:
            # 1. Load data from the .json backup
            with open(json_path, 'r', encoding='utf-8') as f:
                json_data = json.load(f)
            json_steps = json_data.get("added_steps_data", [])
            json_vars = json_data.get("global_variables", {})

            # 2. Load data from the .csv file
            csv_data = self._load_data_from_csv(csv_path)
            if csv_data is None:
                # If .csv is unreadable but .json exists, treat .json as having changes
                self._log_to_console(f"Warning: Could not read {os.path.basename(csv_path)} for comparison.")
                return True 
                
            csv_vars, csv_steps = csv_data

            # 3. Compare the data
            
            # Simple check: Compare step counts
            if len(json_steps) != len(csv_steps):
                self._log_to_console("Recovery check: Step counts differ.")
                return True # Different number of steps

            # Simple check: Compare variable counts
            if len(json_vars) != len(csv_vars):
                self._log_to_console("Recovery check: Variable counts differ.")
                return True # Different number of variables

            # In-depth check: Compare the JSON representation of the steps
            # We re-serialize them to ignore formatting differences
            json_steps_str = json.dumps(json_steps, sort_keys=True)
            csv_steps_str = json.dumps(csv_steps, sort_keys=True)
            
            if json_steps_str != csv_steps_str:
                self._log_to_console("Recovery check: Step data differs.")
                return True # Step content is different

            # In-depth check: Compare variables
            # We must account for complex objects saved as `null` in the .csv
            for var_name, json_value in json_vars.items():
                if var_name not in csv_vars:
                    self._log_to_console("Recovery check: Variable names differ.")
                    return True # Variable added in .json
                
                csv_value = csv_vars[var_name]
                
                # If the .csv value is None, it *could* be a complex object that
                # was intentionally nullified. We only care if the .json value
                # is *also* not None (meaning it's a simple, different value).
                if csv_value is None and json_value is not None:
                    # Check if json_value is a simple type (str, int, float, bool, list, dict)
                    # If it's a complex object, it would have been saved as None anyway.
                    try:
                        json.dumps(json_value) 
                        # If json_value is simple AND not None, but csv_value is None,
                        # they are different.
                        self._log_to_console(f"Recovery check: Variable '{var_name}' data differs (json has value).")
                        return True
                    except TypeError:
                        pass # It's a complex object, so `None` in csv is correct.
                
                # If csv_value is not None, we can do a direct comparison
                elif csv_value is not None and csv_value != json_value:
                    self._log_to_console(f"Recovery check: Variable '{var_name}' data differs.")
                    return True

            # If all checks pass, the files are effectively identical
            return False

        except Exception as e:
            self._log_to_console(f"Error comparing .csv and .json: {e}")
            # Err on the side of caution: if comparison fails, assume changes exist.
            return True
    def _apply_loaded_data_to_ui(self, variables: Dict[str, Any], steps: List[Dict[str, Any]], bot_name: str = "", expansion_states: Dict[str, bool] = None):
        """
        Enhanced version that also loads group expansion states.
        """
        # 1. Clear the current UI and data
        self._internal_clear_all_steps()

        # 2. Apply the loaded data
        self.global_variables = variables
        self.added_steps_data = steps
        # --- MODIFICATION STARTS HERE ---
        # Load expansion states, defaulting to an empty dict if not provided
        self.group_expansion_states = expansion_states if expansion_states is not None else {}
        # --- MODIFICATION ENDS HERE ---
        
        # 3. Update UI components
        self._sync_counters_with_loaded_data()
        self._rebuild_execution_tree()
        self._update_variables_list_display()
        
        if bot_name:
            self.execution_flow_label.setText(f"Execution Flow: {bot_name}")
            self.bot_workflow_label.setText(f"Bot Workflow: {bot_name}")

        # 4. Immediately prepare the workflow with centering
        def prepare_workflow_immediately():
            """Prepares and centers the workflow canvas immediately after data loading."""
            try:
                # Build the workflow tree data structure
                workflow_tree = self._build_workflow_tree_data() if self.added_steps_data else []
                
                # Force creation and sizing of the workflow canvas
                if workflow_tree:
                    # Clear any existing canvas
                    old_canvas = self.workflow_scroll_area.takeWidget()
                    if old_canvas:
                        try:
                            old_canvas.execute_step_requested.disconnect()
                        except (TypeError, AttributeError):
                            pass
                        old_canvas.deleteLater()
                    
                    # Create the new canvas with proper sizing
                    self.workflow_canvas = WorkflowCanvas(workflow_tree, self)
                    self.workflow_canvas.execute_step_requested.connect(self._handle_execute_this_request)
                    
                    # Set up the canvas in the scroll area
                    self.workflow_scroll_area.setWidget(self.workflow_canvas)
                    self.workflow_scroll_area.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
                    self.workflow_scroll_area.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
                    
                    # Force proper sizing calculation
                    self.workflow_canvas._adjust_canvas_size()
                    
                    self._log_to_console(f"Workflow canvas prepared for '{bot_name}' with {len(workflow_tree)} root nodes")
                    
                    # CENTER ON FIRST STEP after everything is set up
                    def center_on_first_after_setup():
                        self._center_workflow_on_first_step()
                    
                    QTimer.singleShot(150, center_on_first_after_setup)
                
            except Exception as e:
                self._log_to_console(f"Error preparing workflow canvas: {e}")
        
        # Schedule immediate workflow preparation
        QTimer.singleShot(50, prepare_workflow_immediately)

        # 5. Save this newly loaded data to the current temp file
        self._save_workflow_to_temp_file()
        
        self._log_to_console(f"Applied loaded data for '{bot_name or 'untitled'}' to UI with immediate workflow preparation and centering.")

    def _handle_execute_pause_resume(self):
        """
        Handles Start/Stop/Pause/Resume logic.
        - "Execute All" starts the bot.
        - The "Stop" button immediately halts the bot and restores the UI.
        - The "Pause" / "Resume" button controls a running bot.
        """
        # Determine which button was clicked by checking the sender
        sender_button = self.sender()

        # --- Case 1: STOP was requested via the Exit/Stop button ---
        if sender_button is self.exit_button and "Stop" in self.exit_button.text():
            if self.worker and self.is_bot_running:
                # Signal the worker thread to stop.
                self.worker.stop()
                
                # Immediately call the cleanup/restore method to reset the UI.
                self.on_execution_finished(self.worker.context, True, -1)
            else:
                # Failsafe in case the state is inconsistent.
                self.on_execution_finished(ExecutionContext(), True, -1)
            return

        # --- Case 2: PAUSE / RESUME was requested via the Execute/Pause/Resume button ---
        if sender_button is self.execute_all_button and self.is_bot_running:
            if not self.is_paused:
                # PAUSE the execution
                if self.worker:
                    self.worker.pause()
                    self.is_paused = True
                    self.execute_all_button.setText("▶️ Resume")
                    self.execute_all_button.setToolTip("Resume the paused execution")
            else:
                # RESUME the execution
                if self.worker:
                    self.worker.resume()
                    self.is_paused = False
                    self.execute_all_button.setText("⏸️ Pause")
                    self.execute_all_button.setToolTip("Pause the running execution")
            return

        # --- Case 3: START a new execution (only triggered by the "Execute All" button) ---
        if sender_button is self.execute_all_button and not self.is_bot_running:
            if not self.added_steps_data:
                QMessageBox.information(self, "No Steps", "No steps have been added.")
                return
            if not self._validate_block_structure_on_execution():
                return

            self.is_bot_running = True
            self.is_paused = False

            # --- Change Exit button to Stop button ---
            self.exit_button.setText("🛑 Stop")
            self.exit_button.setToolTip("Stop the current execution and return to the canvas")
            self.exit_button.clicked.disconnect()
            self.exit_button.clicked.connect(self._handle_execute_pause_resume)

            # Change Execute button to Pause
            self.execute_all_button.setText("⏸️ Pause")
            self.execute_all_button.setToolTip("Pause the running execution")

            # Focus mode logic (unchanged)
            self.view_workflow_button.click()
            if self.always_on_top_button.isChecked():
                self.minimized_for_execution = True
                self.original_geometry = self.geometry()
                self.workflow_scroll_area.setWidgetResizable(False)
                def store_home(widget):
                    parent_layout = widget.parent().layout()
                    index = parent_layout.indexOf(widget)
                    self.widget_homes[widget] = (parent_layout, index)
                store_home(self.execute_all_button)
                store_home(self.exit_button)
                store_home(self.workflow_scroll_area)
                store_home(self.label_info2)
                self.left_menu.setVisible(False)
                self.right_panels.setVisible(False)
                self.normal_mode_widget.setVisible(False)
                self.focus_mode_layout.addWidget(self.workflow_scroll_area)
                self.workflow_scroll_area.setVisible(True)
                self.focus_mode_layout.addWidget(self.label_info2)
                self.label_info2.setVisible(True)
                if not hasattr(self, 'execution_control_widget'):
                    self.execution_control_widget = QWidget()
                    self.execution_control_widget.setLayout(QHBoxLayout())
                    self.execution_control_widget.layout().setContentsMargins(5, 5, 5, 5)
                self.focus_mode_layout.addWidget(self.execution_control_widget)
                self.execution_control_widget.layout().addWidget(self.execute_all_button)
                self.execution_control_widget.layout().addWidget(self.exit_button)
                self.focus_mode_widget.setVisible(True)
                screen = QApplication.primaryScreen().geometry()
                new_width = int(self.original_geometry.width() * 0.25)
                new_height = int(self.original_geometry.height() * 0.30)
                self.resize(new_width, new_height)
                self.move(screen.width() - new_width - 10, 10)
            else:
                self.main_tab_widget.setCurrentIndex(self.workflow_tab_index)

            # Universal Start Logic (unchanged)
            self.set_ui_enabled_state(False)
            self.right_panels.setEnabled(False)
            self.main_tab_widget.setEnabled(False)
            self.progress_bar.setValue(0)
            self.progress_bar.show()
            self.update_status_column_for_all_items()

            self.worker = ExecutionWorker(
                self.added_steps_data, 
                self.module_directory, 
                self.gui_communicator, 
                self.global_variables,
                self.wait_time_between_steps
            )
            self._connect_worker_signals()
            self.worker.start()


    def _validate_block_structure_on_execution(self) -> bool:
        open_blocks = []
        for step_data in self.added_steps_data:
            step_type = step_data["type"]
            if step_type == "group_start":
                open_blocks.append(("group", step_data["group_id"]))
            elif step_type == "loop_start":
                open_blocks.append(("loop", step_data["loop_id"]))
            elif step_type == "IF_START":
                open_blocks.append(("if", step_data["if_id"]))
            elif step_type == "ELSE":
                if not open_blocks or open_blocks[-1][0] != "if":
                    QMessageBox.warning(self, "Invalid Block Structure", "Mismatched ELSE block.")
                    return False
                if_id = open_blocks.pop()[1]
                open_blocks.append(("else", if_id))
            elif step_type == "group_end":
                if not open_blocks or open_blocks.pop() != ("group", step_data["group_id"]):
                    QMessageBox.warning(self, "Invalid Block Structure", "Mismatched GROUP block.")
                    return False
            elif step_type == "loop_end":
                if not open_blocks or open_blocks.pop() != ("loop", step_data["loop_id"]):
                    QMessageBox.warning(self, "Invalid Block Structure", "Mismatched LOOP block.")
                    return False
            elif step_type == "IF_END":
                if not open_blocks or open_blocks[-1][0] not in ["if", "else"] or open_blocks.pop()[1] != step_data["if_id"]:
                    QMessageBox.warning(self, "Invalid Block Structure", "Mismatched IF_END block.")
                    return False
        
        if open_blocks:
            QMessageBox.warning(self, "Invalid Block Structure", f"Unclosed blocks remain: {open_blocks}.")
            return False
        return True

    def execute_one_step(self) -> None:
        """Executes a single step or all steps within a selected group from the main execution tree."""
        selected_items = self.execution_tree.selectedItems()
        if len(selected_items) != 1:
            QMessageBox.information(self, "Selection Error", "Please select exactly ONE step or group to execute.")
            return

        # Get the data from the selected tree item
        selected_step_data = self._get_item_data(selected_items[0])
        if not (selected_step_data and isinstance(selected_step_data, dict)):
            QMessageBox.critical(self, "Error", "Selected item has no valid data associated with it.")
            return

        # Get the reliable index
        current_row = selected_step_data.get("original_listbox_row_index")

        # Validate the index
        if current_row is None or not (0 <= current_row < len(self.added_steps_data)):
            QMessageBox.critical(self, "Error", "Could not find selected step in internal data model.")
            return

        # Clear all execution status before starting
        self._clear_all_execution_status()
        
        # Check if the selected item is a block start (group, loop, or if)
        selected_step_type = selected_step_data.get("type")
        
        if selected_step_type in ["group_start", "loop_start", "IF_START"]:
            # Execute the entire block
            self._execute_selected_block(current_row, selected_step_type)
        else:
            # Execute single step
            self._execute_single_step_simple(current_row)

    def _execute_selected_block(self, start_index: int, block_type: str) -> None:
        """Executes an entire block (group, loop, or if-else) using the range execution approach."""
        
        # Find the end index of the block
        start_idx, end_idx = self._find_block_indices(start_index)
        
        if start_idx == end_idx and block_type in ["group_start", "loop_start", "IF_START"]:
            QMessageBox.warning(self, "Incomplete Block", "The selected block appears to be incomplete. Cannot execute.")
            return
        
        block_data = self.added_steps_data[start_index]
        if block_type == "group_start":
            block_name = f"Group '{block_data.get('group_name', 'Unknown')}'"
        elif block_type == "loop_start":
            loop_config = block_data.get('loop_config', {})
            block_name = f"Loop '{loop_config.get('loop_name', block_data.get('loop_id', 'Unknown'))}'"
        elif block_type == "IF_START":
            condition_config = block_data.get('condition_config', {})
            block_name = f"IF '{condition_config.get('block_name', block_data.get('if_id', 'Unknown'))}'"
        else:
            block_name = f"{block_type} block"
        
        step_count = end_idx - start_idx + 1
        self._log_to_console(f"Executing {block_name} ({step_count} steps)")
        
        # Start execution with range
        self._start_range_execution(start_idx, end_idx, execute_all=True)

    def _execute_single_step_simple(self, step_index: int) -> None:
        """Executes a single step using the existing single step mode."""
        step_data = self.added_steps_data[step_index]
        step_name = step_data.get("method_name", f"Step {step_index + 1}")
        self._log_to_console(f"Executing single step: {step_name}")
        
        # Use single step mode (existing working logic)
        self._start_range_execution(step_index, step_index, execute_all=False)

    def _start_range_execution(self, start_index: int, end_index: int, execute_all: bool) -> None:
        """Starts execution for a specific range of steps in the main data list."""
        
        # Prevent multiple executions
        if self.is_bot_running:
            QMessageBox.warning(self, "Already Running", "Another execution is already in progress.")
            return
        
        # Set up UI for execution
        self.set_ui_enabled_state(False)
        self.progress_bar.setValue(0)
        self.progress_bar.show()
        self.update_status_column_for_all_items()
        
        # Create the worker with the full data list but specify the range to execute
        self.worker = ExecutionWorker(
            self.added_steps_data,  # Pass the full list (important!)
            self.module_directory, 
            self.gui_communicator, 
            self.global_variables, 
            self.wait_time_between_steps if execute_all else {'type': 'hardcoded', 'value': 0},
            single_step_mode=not execute_all, 
            selected_start_index=start_index,
            selected_end_index=end_index  # NEW: Specify where to stop
        )
        
        self._connect_worker_signals()
        self.worker.start()

    def _clear_all_execution_status(self) -> None:
        """Enhanced status clearing that's more thorough."""
        # Clear from data model
        for step_data in self.added_steps_data:
            # Remove execution status keys
            step_data.pop("execution_status", None)
            step_data.pop("execution_result", None)
            
            # Also clear from parameters_config if it exists
            if step_data.get("type") == "step" and "parameters_config" in step_data:
                params = step_data.get("parameters_config", {})
                if isinstance(params, dict):
                    params.pop("execution_status", None)
                    params.pop("execution_result", None)
        
        # Clear visual status from all tree items
        self._clear_status_recursive(self.execution_tree.invisibleRootItem())
        
        # Update workflow canvas
        if hasattr(self, 'workflow_canvas') and self.workflow_canvas:
            self.workflow_canvas.update()
        
        # Reset any running flags
        self.is_bot_running = False
        self.is_paused = False

    def _connect_worker_signals(self) -> None:
        try:
            self.worker.execution_started.disconnect()
            self.worker.execution_progress.disconnect()
            self.worker.execution_item_started.disconnect()
            self.worker.execution_item_finished.disconnect()
            self.worker.execution_error.disconnect()
            self.worker.execution_finished_all.disconnect()
            # Disconnect the new signal if it exists
            if hasattr(self.worker, 'loop_iteration_started'):
                self.worker.loop_iteration_started.disconnect()
        except TypeError:
            pass
            
        self.worker.execution_started.connect(lambda msg: self._log_to_console(f"GUI: {msg}"))
        self.worker.execution_progress.connect(self.progress_bar.setValue)
        self.worker.execution_item_started.connect(self.update_execution_tree_item_status_started)
        self.worker.execution_item_finished.connect(self.update_execution_tree_item_status_finished)
        self.worker.execution_error.connect(self.update_execution_tree_item_status_error)
        self.worker.execution_finished_all.connect(self.on_execution_finished)
        self.worker.execution_finished_all.connect(lambda: self._update_variables_list_display())
        
        # Connect the new loop iteration signal
        if hasattr(self.worker, 'loop_iteration_started'):
            self.worker.loop_iteration_started.connect(self._on_loop_iteration_started)
            
    def _on_loop_iteration_started(self, loop_id: str, iteration_number: int):
        """Handle loop iteration start - reset status of steps within the loop."""
        if iteration_number > 1:  # Only reset for iterations after the first one
            self._reset_nested_loop_steps_status(loop_id)
    def _find_qtreewidget_item(self, target_step_data_dict: Dict[str, Any], parent_item: Optional[QTreeWidgetItem] = None) -> Optional[QTreeWidgetItem]:
        if parent_item is None:
            parent_item = self.execution_tree.invisibleRootItem()
        
        for i in range(parent_item.childCount()):
            child_item = parent_item.child(i)
            item_data = self._get_item_data(child_item)
            
            if item_data:
                # Match by original_listbox_row_index instead of object equality
                target_index = target_step_data_dict.get("original_listbox_row_index")
                item_index = item_data.get("original_listbox_row_index")
                
                if target_index is not None and target_index == item_index:
                    return child_item
            
            # Recursively search children
            found_in_children = self._find_qtreewidget_item(target_step_data_dict, child_item)
            if found_in_children:
                return found_in_children
        
        return None
    def _find_parent_group_data(self, step_index: int) -> Optional[Dict[str, Any]]:
        """
        Finds the 'group_start' data for the group that the step at step_index is inside.
        Returns None if the step is not inside a group.
        """
        if step_index < 0 or step_index >= len(self.added_steps_data):
            return None
            
        group_stack: List[Dict[str, Any]] = []
        
        # Iterate from the beginning up to (but not including) the step itself
        for i in range(step_index):
            step_data = self.added_steps_data[i]
            step_type = step_data.get("type")
            
            if step_type == "group_start":
                group_stack.append(step_data)
            elif step_type == "group_end":
                if group_stack:
                    # Pop if the ID matches. In a valid structure, it always should.
                    if group_stack[-1].get("group_id") == step_data.get("group_id"):
                        group_stack.pop()
                        
        # If the stack is not empty, the step is inside the group at the top
        if group_stack:
            return group_stack[-1]
            
        return None
        
# In main_app.py, inside the MainWindow class
# REPLACE this entire method:

    def update_execution_tree_item_status_started(self, step_data_dict: Dict[str, Any], original_listbox_row_index: int) -> None:
        """
        Enhanced method with robust auto-centering for workflow visualization.
        Now properly handles both horizontal and vertical scrolling with smooth centering.
        """
        # --- Part 1: Immediate UI Updates (Borders, Logs, etc.) ---
        
        # Set execution status in the data model
        self._set_step_execution_status(step_data_dict, "running")
        
        # Update parent group status
        parent_group_data = self._find_parent_group_data(original_listbox_row_index)
        if parent_group_data and parent_group_data.get("execution_status") != "error":
            self._set_step_execution_status(parent_group_data, "running")
        
        # Update the execution tree card using the reliable index map
        item_to_update = self.data_to_item_map.get(original_listbox_row_index)
        if item_to_update:
            card = self.execution_tree.itemWidget(item_to_update, 0)
            if card:
                card.set_status("", is_running=True)
                self._log_to_console(f"Executing: {card._get_formatted_title()}")
            self.execution_tree.setCurrentItem(item_to_update)
            self.execution_tree.scrollToItem(item_to_update, QtWidgets.QAbstractItemView.ScrollHint.PositionAtCenter)

        # Tell the canvas it needs a repaint
        if hasattr(self, 'workflow_canvas') and self.workflow_canvas:
            self.workflow_canvas.update()

        # --- Part 2: Enhanced Auto-Centering Logic ---
        
        def center_workflow_on_executing_step():
            """
            Automatically centers the workflow view on the currently executing step.
            This runs after Qt layout stabilization for accurate geometry calculations.
            """
            # Verify workflow components are available and visible
            if not (hasattr(self, 'workflow_canvas') and 
                    self.workflow_canvas and 
                    self.workflow_scroll_area.isVisible()):
                return

            # Find the target node in the workflow canvas
            target_node_rect: Optional[QRect] = None
            target_node_data = None
            
            for rect, _, _, node_step_data in self.workflow_canvas.nodes:
                node_index = node_step_data.get("original_listbox_row_index")
                if node_index == original_listbox_row_index:
                    target_node_rect = rect
                    target_node_data = node_step_data
                    break
            
            if not target_node_rect:
                self._log_to_console(f"Could not find workflow node for step {original_listbox_row_index}")
                return

            try:
                # Get current scroll area viewport dimensions
                viewport = self.workflow_scroll_area.viewport()
                viewport_width = viewport.width()
                viewport_height = viewport.height()
                
                # Account for canvas offset in calculations
                canvas_offset = self.workflow_canvas.canvas_offset
                
                # Calculate the absolute position of the node center
                node_center_x = target_node_rect.center().x() + canvas_offset.x()
                node_center_y = target_node_rect.center().y() + canvas_offset.y()
                
                # Calculate target scroll positions to center the node
                target_scroll_x = node_center_x - (viewport_width // 2)
                target_scroll_y = node_center_y - (viewport_height // 2)
                
                # Get scroll bar ranges to clamp values
                h_scrollbar = self.workflow_scroll_area.horizontalScrollBar()
                v_scrollbar = self.workflow_scroll_area.verticalScrollBar()
                
                # Clamp scroll positions to valid ranges
                target_scroll_x = max(h_scrollbar.minimum(), 
                                    min(target_scroll_x, h_scrollbar.maximum()))
                target_scroll_y = max(v_scrollbar.minimum(), 
                                    min(target_scroll_y, v_scrollbar.maximum()))
                
                # Apply the scroll positions
                h_scrollbar.setValue(int(target_scroll_x))
                v_scrollbar.setValue(int(target_scroll_y))
                
                # Log successful centering
                step_name = target_node_data.get("method_name", "Unknown")
                self._log_to_console(f"Workflow centered on: {step_name}")
                
            except Exception as e:
                self._log_to_console(f"Error during workflow auto-centering: {e}")

        # Schedule the centering to run after Qt layout stabilization
        # Using a slightly longer delay for more reliable geometry calculations
        QTimer.singleShot(50, center_workflow_on_executing_step)



    def update_execution_tree_item_status_finished(self, step_data_dict: Dict[str, Any], message: str, original_listbox_row_index: int) -> None:
        """Enhanced method with workflow visualization support."""
        
        #print(f"DEBUG: update_execution_tree_item_status_finished called for step {original_listbox_row_index}")
        
        # --- NEW: Find parent group *before* processing ---
        parent_group_data = self._find_parent_group_data(original_listbox_row_index)
        
        # --- NEW: Check if the *current step* is a group_end ---
        is_group_end = step_data_dict.get("type") == "group_end"
        
        if is_group_end:
            # This is a group_end step. Find its matching group_start.
            group_id = step_data_dict.get("group_id")
            group_start_data = None
            for step in self.added_steps_data: # Search the whole list
                if step.get("type") == "group_start" and step.get("group_id") == group_id:
                    group_start_data = step
                    break
            
            # Set the status of the group_start node
            if group_start_data and group_start_data.get("execution_status") != "error":
                self._set_step_execution_status(group_start_data, "completed")
                # Also set the group_end step itself to completed
                self._set_step_execution_status(step_data_dict, "completed")
        
        elif message == "SKIPPED":
            #print("DEBUG: Step was SKIPPED")
            # --- Step was SKIPPED ---
            self._set_step_execution_status(step_data_dict, "normal")
            if "execution_result" in step_data_dict:
                 del step_data_dict["execution_result"]
            
            # If inside a group, keep the group "running"
            if parent_group_data and parent_group_data.get("execution_status") != "error":
                self._set_step_execution_status(parent_group_data, "running")
            
        else:
            #print("DEBUG: Step COMPLETED normally")
            # --- Step COMPLETED normally (and is not a group_end) ---
            self._set_step_execution_status(step_data_dict, "completed")
            step_data_dict["execution_result"] = message
            #self.label_info1.setText(f"Last Result: {message[0:25]}")
            # If inside a group, keep the group "running"
            if parent_group_data and parent_group_data.get("execution_status") != "error":
                self._set_step_execution_status(parent_group_data, "running")

        # --- Update the Card for the current step (regardless of type) ---
        if message == "SKIPPED":
            #print("DEBUG: Processing SKIPPED message")
            item_widget = self._find_qtreewidget_item(step_data_dict)
            #print(f"DEBUG: item_widget = {item_widget}")
            if item_widget:
                card = self.execution_tree.itemWidget(item_widget, 0)
                #print(f"DEBUG: card = {card}")
                if card:
                    card.set_status("#D3D3D3", is_running=False)
                    card.clear_result()
                self._log_to_console(f"Skipped: {card._get_formatted_title()}")
        else:
            #print("DEBUG: Processing normal completion message")
            item_widget = self._find_qtreewidget_item(step_data_dict)
            #print(f"DEBUG: item_widget = {item_widget}")
            if item_widget:
                card = self.execution_tree.itemWidget(item_widget, 0)
                #print(f"DEBUG: card = {card}")
                if card:
                    #print(f"DEBUG: About to call set_result_text with: {message}")
                    card.set_status("darkGreen", is_running=False)
                    card.set_result_text(message)  # <-- This should call it now
                    #print("DEBUG: set_result_text called successfully")
                self._log_to_console(f"Finished: {card._get_formatted_title()} | {message}")
                self._update_variables_list_display()

    def update_execution_tree_item_status_error(self, step_data_dict: Dict[str, Any], error_message: str, original_listbox_row_index: int) -> None:
        """Enhanced method with workflow visualization support."""
        # Set execution status
        self._set_step_execution_status(step_data_dict, "error")
        
        # --- NEW: Propagate error to parent group ---
        parent_group_data = self._find_parent_group_data(original_listbox_row_index)
        if parent_group_data:
            self._set_step_execution_status(parent_group_data, "error")
        # --- END NEW ---

        # Update the execution tree card
        item_widget = self._find_qtreewidget_item(step_data_dict)
        if item_widget:
            card = self.execution_tree.itemWidget(item_widget, 0)
            if card:
                card.set_status("", is_running=False, is_error=True)  # Red border, thick
            self._log_to_console(f"ERROR on {card._get_formatted_title()}: {error_message}")
            self._update_variables_list_display()



    def on_execution_finished(self, context: ExecutionContext, stopped_by_error: bool, next_step_index_to_select: int) -> None:
        self.is_bot_running = False
        self.is_paused = False
        self.worker = None

        # --- Restore UI buttons ---
        self.execute_all_button.setText("🚀 Execute All")
        self.execute_all_button.setToolTip("Execute all steps from the beginning")
        try: self.exit_button.clicked.disconnect()
        except TypeError: pass
        self.exit_button.setText("🚪 Exit")
        self.exit_button.setToolTip("Exit the application")
        self.exit_button.clicked.connect(QApplication.instance().quit)

        self.progress_bar.setValue(100)
        self.last_executed_context = context

        is_restoring = False
        if self.minimized_for_execution:
            # --- EXITING FOCUS MODE ---
            self.focus_mode_widget.setVisible(False)
            self.workflow_scroll_area.setWidgetResizable(True)
            def restore_home(widget):
                if widget in self.widget_homes:
                    layout, index = self.widget_homes[widget]
                    widget.setParent(None); layout.insertWidget(index, widget); widget.setVisible(True)
            restore_home(self.execute_all_button); restore_home(self.exit_button)
            restore_home(self.workflow_scroll_area); restore_home(self.label_info2)
            self.widget_homes.clear(); self.left_menu.setVisible(True)
            self.right_panels.setVisible(True); self.normal_mode_widget.setVisible(True)
            if self.original_geometry: self.setGeometry(self.original_geometry)
            self.minimized_for_execution = False
            
            # --- NEW RESTORATION LOGIC ---
            if os.path.exists(self.scheduled_task_restore_file):
                is_restoring = True
                self._log_to_console("Scheduler: Execution finished. Restoring previous workflow.")
                try:
                    with open(self.scheduled_task_restore_file, 'r', encoding='utf-8') as f:
                        restored_data = json.load(f)
                    
                    self._apply_loaded_data_to_ui(
                        restored_data.get("global_variables", {}),
                        restored_data.get("added_steps_data", [])
                    )
                    os.remove(self.scheduled_task_restore_file)
                except Exception as e:
                    self._log_to_console(f"CRITICAL: Error restoring workflow: {e}")
                    QMessageBox.critical(self, "Restore Error", f"Could not restore your previous workflow from the temp file.\n\nError: {e}")
            # --- END NEW RESTORATION LOGIC ---
        
        # Reset flow label text
        current_bot_name = ""
        if not is_restoring and self.current_temp_file_path != self.default_temp_file_path:
            current_bot_name = os.path.splitext(os.path.basename(self.current_temp_file_path))[0]
        self.execution_flow_label.setText(f"Execution Flow: {current_bot_name}" if current_bot_name else "Execution Flow")
        
        # Universal UI Re-enablement
        self.set_ui_enabled_state(True)
        self.right_panels.setEnabled(True)
        self.main_tab_widget.setEnabled(True)

        if next_step_index_to_select != -1:
            item_to_select = self.data_to_item_map.get(next_step_index_to_select)
            if item_to_select:
                self.execution_tree.setCurrentItem(item_to_select)
                self.execution_tree.scrollToItem(item_to_select, QtWidgets.QAbstractItemView.ScrollHint.PositionAtCenter)
    def update_click_signal_from_module(self, message: str) -> None:
        
        self.label_info1.setText(message)
        
    def update_label_info_from_module(self, message: str) -> None:
        """
        Updates the info labels, including the image preview.
        This is the corrected and robust version.
        """
        # 1. Handle cases where the preview should be cleared.
        if not message or message.startswith("Module Info:") or message.startswith("Last Module Log:"):
            #self.label_info2.clear()
            #self.label_info2.setText("Image Preview")
            #self.label_info3.setText("Image Name")
            if message:
                self.label_info1.setText(message)
            return

        # 2. If we have a message, it's an image name. Construct the full path.
        #    THIS IS THE CRITICAL FIX: We need to build the full path to the .txt file.
        image_name = message.replace("Image not found: ","")
        image_data_filepath = os.path.join(self.click_image_dir, f"{image_name}.txt")

        # 3. Check if the data file actually exists.
        if os.path.exists(image_data_filepath):
            self.label_info3.setText(image_name)
            try:
                # 4. Open the .txt file and load the JSON data.
                with open(image_data_filepath, 'r', encoding='utf-8') as json_file:
                    img_data = json.load(json_file)
                    # The image data is the first value in the dictionary
                    base64_string = next(iter(img_data.values()), None)
                
                if base64_string:
                    # 5. Decode, convert, resize, and display the image.
                    pic_png = self.base64_pgn(base64_string)
                    qimage = ImageQt(pic_png)
                    pixmap = self.resize_qimage_and_create_qpixmap(qimage)
                    self.label_info2.setPixmap(pixmap)
                    #self.label_info1.setText(f"Previewing: {image_name}")
                else:
                    # Handle case where the JSON is valid but has no image data
                    #self.label_info1.setText(f"No image data found in '{image_name}.txt'.")
                    self.label_info2.setText("No Data")
                    self.label_info2.clear()

            except (json.JSONDecodeError, Exception) as e:
                self.label_info1.setText(f"Error loading image '{image_name}': {e}")
                self.label_info2.setText("Load Error")
                self.label_info2.clear()
        else:
            # Handle case where the file is missing entirely.
            #self.label_info1.setText(f"Image file for '{image_name}' not found.")
            timestamp = datetime.now().strftime("%H:%M:%S")
            self.log_console.append(f"[{timestamp}] {message}")
            self.label_info2.setText("Not Found")
            self.label_info2.clear()
            self.label_info3.setText("Image Name")

    def base64_pgn(self,text):
        return PIL.Image.open(io.BytesIO(base64.b64decode(text)))

    def resize_qimage_and_create_qpixmap(self,qimage_input, percentage=98):
        if qimage_input.isNull():
            return QPixmap()
        new_width = int(qimage_input.width() * (percentage / 100))
        new_height = int(qimage_input.height() * (percentage / 100))
        return QPixmap.fromImage(qimage_input.scaled(QSize(new_width, new_height), Qt.AspectRatioMode.KeepAspectRatio, Qt.TransformationMode.SmoothTransformation))

    def set_ui_enabled_state(self, enabled: bool) -> None:
        widgets_to_toggle = [
            # self.execute_all_button, # <-- REMOVED
            self.add_loop_button, self.add_conditional_button, 
            self.save_steps_button, self.clear_selected_button, self.remove_all_steps_button,
            self.module_filter_dropdown, self.module_tree, self.saved_steps_tree,
            self.add_var_button, self.edit_var_button, self.delete_var_button, 
            self.clear_vars_button, self.open_screenshot_tool_button, 
            self.group_steps_button
        ]  # <--- It's right here
        for widget in widgets_to_toggle:
            widget.setEnabled(enabled)
        self.execute_one_step_button.setEnabled(enabled and len(self.execution_tree.selectedItems()) > 0)
        
    def _update_variables_list_display(self) -> None:
        self.variables_list.clear()
        if not self.global_variables:
            self.variables_list.addItem("No global variables defined.")
            return
        for name, value in self.global_variables.items():
            value_str = repr(value)
            if len(value_str) > 60:
                value_str = value_str[:57] + "..."
            self.variables_list.addItem(f"{name} = {value_str}")

# In MainWindow class, REPLACE the add_variable method

    def add_variable(self) -> None:
        dialog = GlobalVariableDialog(self)
        if dialog.exec() == QDialog.DialogCode.Accepted:
            data = dialog.get_variable_data() # This now returns Optional[Tuple[str, Any]]
            if data:
                name, value = data # Unpack the tuple
                if name:
                    if name in self.global_variables:
                        QMessageBox.warning(self, "Duplicate Variable", f"Variable '{name}' already exists.")
                        return
                    self.global_variables[name] = value # Correctly assigns Any type
                    self._update_variables_list_display()
                    self._save_workflow_to_temp_file()

# In MainWindow class, REPLACE the edit_variable method

    def edit_variable(self) -> None:
        selected_item = self.variables_list.currentItem()
        if not selected_item or selected_item.text() == "No global variables defined.":
            QMessageBox.information(self, "No Selection", "Please select a variable to edit.")
            return
        
        var_name = selected_item.text().split(' = ')[0]
        if var_name not in self.global_variables:
            self._update_variables_list_display()
            return

        # Pass the *actual* value, not the string representation
        dialog = GlobalVariableDialog(variable_name=var_name, variable_value=self.global_variables[var_name], parent=self)
        
        if dialog.exec() == QDialog.DialogCode.Accepted:
            data = dialog.get_variable_data() # Returns Optional[Tuple[str, Any]]
            if data:
                new_name, new_value = data
                
                # Check for name collision if the name was changed
                if new_name != var_name and new_name in self.global_variables:
                    QMessageBox.warning(self, "Duplicate Variable", f"A variable with the name '{new_name}' already exists.")
                    return
                
                # If name changed, remove the old one
                if new_name != var_name:
                    del self.global_variables[var_name]
                
                # Add/update the new one
                self.global_variables[new_name] = new_value # Assigns Any type
                self._update_variables_list_display()
                self._save_workflow_to_temp_file()

    def delete_variable(self) -> None:
        selected_item = self.variables_list.currentItem()
        if not selected_item or selected_item.text() == "No global variables defined.":
            QMessageBox.information(self, "No Selection", "Please select a variable to delete.")
            return
        var_name = selected_item.text().split(' = ')[0]
        if QMessageBox.question(self, "Confirm Delete", f"Are you sure you want to delete variable '{var_name}'?", QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No) == QMessageBox.StandardButton.Yes:
            if var_name in self.global_variables:
                del self.global_variables[var_name]
            self._update_variables_list_display()
            self._save_workflow_to_temp_file() # <--- ADD THIS LINE

    def reset_all_variable_values(self) -> None:
        if not self.global_variables:
            QMessageBox.information(self, "Info", "No global variables to reset.")
            return
        if QMessageBox.question(self, "Confirm Reset", "Reset all global variable values to 'None'?", QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No) == QMessageBox.StandardButton.Yes:
            for var_name in self.global_variables:
                self.global_variables[var_name] = None
            self._update_variables_list_display()

# In MainWindow class
# In MainWindow class
    def save_bot_steps_dialog(self) -> None:
        if not self.added_steps_data and not self.global_variables:
            QMessageBox.information(self, "Nothing to Save", "The execution queue and global variables are empty.")
            return

        bot_name = None
        
        # --- MODIFIED LOGIC: Always show the SaveBotDialog ---
        # This will always act as "Save As..."
        
        # Check if we were working on an "untitled" bot
        was_new_bot = (self.current_temp_file_path == self.default_temp_file_path)

        os.makedirs(self.bot_steps_directory, exist_ok=True)
        existing_bots = [os.path.splitext(f)[0] for f in os.listdir(self.bot_steps_directory) if f.endswith(".csv")]
        
        dialog = SaveBotDialog(existing_bots, self)
        
        # --- NEW: Pre-populate the dialog with the current name if it's not a new bot ---
        if not was_new_bot:
            current_bot_name = os.path.splitext(os.path.basename(self.current_temp_file_path))[0]
            if current_bot_name in existing_bots:
                # Select the existing bot in the dropdown
                dialog.bots_combo.setCurrentText(current_bot_name)
            else:
                # Put the name in the editor (e.g., if the .csv was deleted)
                dialog.name_editor.setText(current_bot_name)
        # --- END NEW ---

        if dialog.exec() == QDialog.DialogCode.Accepted:
            bot_name = dialog.get_bot_name()
            if not bot_name:
                return
    
            # Check if the chosen name is an existing bot
            is_overwriting = bot_name in existing_bots
            
            if is_overwriting:
                reply = QMessageBox.question(self, "Confirm Overwrite",
                                             f"A bot named '{bot_name}' already exists. Overwrite it?",
                                             QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No)
                if reply == QMessageBox.StandardButton.No:
                    return
        else:
            return # User cancelled the "Save As" dialog
        
        # --- END MODIFIED LOGIC ---

        if not bot_name:
            QMessageBox.critical(self, "Save Error", "Could not determine a file name to save.")
            return

        # Define paths for BOTH .csv and .json files
        csv_file_path = os.path.join(self.bot_steps_directory, f"{bot_name}.csv")
        json_file_path = os.path.join(self.bot_steps_directory, f"{bot_name}.json")

        try:
            # 1. Prepare data to save (Global Variables)
            variables_to_save = {}
            for var_name, var_value in self.global_variables.items():
                try:
                    json.dumps(var_value) # Check if serializable
                    variables_to_save[var_name] = var_value
                except (TypeError, OverflowError):
                    # Save non-serializable objects as None
                    variables_to_save[var_name] = None
            
            # 2. Prepare data to save (Bot Steps)
            steps_to_save = []
            for step_data_dict in self.added_steps_data:
                # Create a deep copy to avoid modifying the in-memory data
                step_data_to_save = json.loads(json.dumps(step_data_dict))
                
                # Clean runtime keys
                step_data_to_save.pop("original_listbox_row_index", None)
                step_data_to_save.pop("execution_status", None)
                step_data_to_save.pop("execution_result", None)
                if step_data_to_save.get("type") == "step" and step_data_to_save.get("parameters_config"):
                    step_data_to_save["parameters_config"].pop("original_listbox_row_index", None)
                steps_to_save.append(step_data_to_save)

            # 3. Save the "official" .csv file
            with open(csv_file_path, 'w', newline='', encoding='utf-8') as csvfile:
                writer = csv.writer(csvfile)
                
                # --- NEW: Preserve schedule info if overwriting ---
                schedule_data = {}
                if is_overwriting:
                     schedule_data = self._read_schedule_from_csv(csv_file_path) or {}
                # --- END NEW ---
                
                writer.writerow(["__SCHEDULE_INFO__"])
                writer.writerow([json.dumps(schedule_data)])
                # Write variables
                writer.writerow(["__GLOBAL_VARIABLES__"])
                for var_name, var_value in variables_to_save.items():
                    writer.writerow([var_name, json.dumps(var_value)])
                # Write steps
                writer.writerow(["__BOT_STEPS__"])
                writer.writerow(["StepType", "DataJSON"])
                for step_data in steps_to_save:
                    writer.writerow([step_data["type"], json.dumps(step_data)])
            
            # 4. Save the identical .json backup file
            data_for_json = {
                "added_steps_data": steps_to_save,
                "global_variables": variables_to_save
            }
            with open(json_file_path, 'w', encoding='utf-8') as f:
                json.dump(data_for_json, f, indent=4)

            # 5. Handle post-save logic
            if was_new_bot:
                # We just saved an "untitled" bot for the first time
                self._clear_default_temp_file()

            # After saving, the *new* file is our active temp file
            self.current_temp_file_path = json_file_path
            self.execution_flow_label.setText(f"Execution Flow: {bot_name}")
            self.bot_workflow_label.setText(f"Bot Workflow: {bot_name}")

            QMessageBox.information(self, "Save Successful", f"Bot saved to:\n{csv_file_path}")
            self.load_saved_steps_to_tree() # Refresh the "Saved Bots" list

        except Exception as e:
            QMessageBox.critical(self, "Save Error", f"Failed to save bot steps:\n{e}")
    

    # In MainWindow class
# In MainWindow class
    def load_steps_from_file(self, file_path: str, bot_name: str = "") -> None:
        """
        Enhanced version that immediately shows the workflow when loading a bot.
        All groups will be loaded in a collapsed state by default.
        """
        if not bot_name:
            bot_name = os.path.splitext(os.path.basename(file_path))[0]

        # Define the paths for both the .csv and the .json backup
        csv_path = file_path
        json_path = os.path.join(self.bot_steps_directory, f"{bot_name}.json")

        loaded_data = None
        data_source_msg = ""

        # 1. Check if a .json backup file exists and has unsaved changes
        has_unsaved_changes = self._compare_csv_and_json(csv_path, json_path)

        if has_unsaved_changes:
            # 2. Ask the user if they want to recover the .json version
            reply = QMessageBox.question(self, "Recover Unsaved Changes",
                                         f"Unsaved changes were found for '{bot_name}' in its backup file.\n\n"
                                         "Do you want to load the unsaved version? (Choosing 'No' will load the last official save from the .csv file).",
                                         QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No)
            
            if reply == QMessageBox.StandardButton.Yes:
                # 3a. Load from .json
                try:
                    with open(json_path, 'r', encoding='utf-8') as f:
                        json_data = json.load(f)
                    loaded_data = (json_data.get("global_variables", {}), json_data.get("added_steps_data", []))
                    data_source_msg = f"Recovered unsaved version of '{bot_name}' from .json backup."
                except Exception as e:
                    self._log_to_console(f"Error loading .json backup: {e}. Defaulting to .csv.")
                    loaded_data = None # Force fallback to .csv
            
        
        # 3b. Load from .csv (if no unsaved changes, user chose "No", or .json failed)
        if loaded_data is None:
            loaded_data = self._load_data_from_csv(csv_path)
            if loaded_data:
                data_source_msg = f"Loaded '{bot_name}' from .csv file."
        
        # 4. Check if loading was successful
        if loaded_data:
            loaded_vars, loaded_steps = loaded_data

            # --- START OF SUPPORTING CHANGE ---
            # 5. When loading a bot, ALWAYS reset the expansion states. Combined with the
            #    new default in _is_group_expanded, this forces the collapsed state.
            self.group_expansion_states.clear()
            # --- END OF SUPPORTING CHANGE ---

            # 6. Clear the *default* temp file (we are no longer "untitled")
            self._clear_default_temp_file()

            # 7. Set the *current* temp file path to this bot's .json
            self.current_temp_file_path = json_path
            
            # 8. Apply the loaded data. The expansion_states argument is now None.
            self._apply_loaded_data_to_ui(loaded_vars, loaded_steps, bot_name, None)
            
            # 9. IMMEDIATELY update and show the workflow
            self._update_and_show_workflow_after_load()
            
            self._log_to_console(data_source_msg + " All groups have been collapsed.")

        else:
            # Handle load failure
            QMessageBox.critical(self, "Load Error", f"An unexpected error occurred while loading '{bot_name}'.")
            self._log_to_console(f"Failed to load bot from {os.path.basename(csv_path)}.")
    def _update_and_show_workflow_after_load(self):
        """
        Immediately updates, displays, and centers the workflow after loading a bot.
        """
        def show_workflow_after_ui_stabilization():
            try:
                # Force update the workflow tab with the loaded data
                self._update_workflow_tab(switch_to_tab=False)
                
                # Switch to the workflow tab to show the visual representation
                workflow_tab_index = -1
                for i in range(self.main_tab_widget.count()):
                    if "Workflow" in self.main_tab_widget.tabText(i):
                        workflow_tab_index = i
                        break
                
                if workflow_tab_index != -1:
                    self.main_tab_widget.setCurrentIndex(workflow_tab_index)
                    self._log_to_console("Switched to Workflow tab to display the loaded bot structure.")
                
                # Ensure the canvas is properly sized after loading
                if hasattr(self, 'workflow_canvas') and self.workflow_canvas:
                    self.workflow_canvas._adjust_canvas_size()
                    self._log_to_console("Workflow canvas resized for optimal viewing.")
                    
                    # CENTER ON THE FIRST STEP - This is the new addition
                    def center_after_sizing():
                        self._center_workflow_on_first_step()
                    
                    # Give a small delay to ensure canvas sizing is complete
                    QTimer.singleShot(100, center_after_sizing)
                    
            except Exception as e:
                self._log_to_console(f"Error displaying workflow after load: {e}")
        
        # Schedule the workflow update after the UI has had time to stabilize
        QTimer.singleShot(200, show_workflow_after_ui_stabilization)
    def _center_workflow_on_first_step(self):
        """
        Centers the workflow canvas view on the first step after loading.
        """
        if not (hasattr(self, 'workflow_canvas') and self.workflow_canvas and self.workflow_canvas.nodes):
            return
        
        try:
            # Find the first step (step with the lowest original_listbox_row_index)
            first_step_node = None
            min_index = float('inf')
            
            for rect, text, shape, step_data in self.workflow_canvas.nodes:
                step_index = step_data.get("original_listbox_row_index", float('inf'))
                if step_index < min_index:
                    min_index = step_index
                    first_step_node = (rect, text, shape, step_data)
            
            if not first_step_node:
                return
            
            # Get the rectangle of the first step
            first_rect = first_step_node[0]
            
            # Get scroll area viewport dimensions
            viewport = self.workflow_scroll_area.viewport()
            viewport_width = viewport.width()
            viewport_height = viewport.height()
            
            # Account for canvas offset
            canvas_offset = self.workflow_canvas.canvas_offset
            
            # Calculate the center position of the first step
            step_center_x = first_rect.center().x() + canvas_offset.x()
            step_center_y = first_rect.center().y() + canvas_offset.y()
            
            # Calculate scroll positions to center the first step
            target_scroll_x = step_center_x - (viewport_width // 2)
            target_scroll_y = step_center_y - (viewport_height // 2)
            
            # Get scroll bars and clamp values to valid ranges
            h_scrollbar = self.workflow_scroll_area.horizontalScrollBar()
            v_scrollbar = self.workflow_scroll_area.verticalScrollBar()
            
            # Clamp to valid ranges
            target_scroll_x = max(h_scrollbar.minimum(), min(target_scroll_x, h_scrollbar.maximum()))
            target_scroll_y = max(v_scrollbar.minimum(), min(target_scroll_y, v_scrollbar.maximum()))
            
            # Apply the centering
            h_scrollbar.setValue(int(target_scroll_x))
            v_scrollbar.setValue(int(target_scroll_y))
            
            # Log the centering action
            step_name = first_step_node[3].get("method_name", "First Step")
            self._log_to_console(f"Workflow centered on first step: {step_name}")
            
        except Exception as e:
            self._log_to_console(f"Error centering workflow on first step: {e}")
# In the MainWindow class, REPLACE the show_context_menu

# In MainWindow class
# REPLACE your existing show_context_menu method with this one:

    def show_context_menu(self, position: QPoint):
        item = self.module_tree.itemAt(position)
        if not item:
            return

        item_data = self._get_item_data(item)
        context_menu = QMenu(self)

        # --- NEW: Logic for "Bot Templates" section ---
        item_type = item_data.get('type') if isinstance(item_data, dict) else None

        if item_type in ['template_root', 'template_folder']:
            create_folder_action = context_menu.addAction("Create New Folder")
            action = context_menu.exec(self.module_tree.mapToGlobal(position))
            if action == create_folder_action:
                self._create_template_folder(item)
            return

        # --- Logic for individual template files ---
        elif item_type == 'template':
            template_name = item_data.get('name')
            if not template_name:
                return

            add_action = context_menu.addAction("Add to Execution Flow")
            context_menu.addSeparator()
            doc_action = context_menu.addAction("View Documentation")
            delete_action = context_menu.addAction("Delete Template")

            doc_path = os.path.join(self.template_document_directory, f"{template_name}.html")
            doc_action.setEnabled(os.path.exists(doc_path))
            action = context_menu.exec(self.module_tree.mapToGlobal(position))

            if action == add_action:
                # Use the relative path to load the template now
                self._load_template_by_name(item_data['path'])
            elif action == doc_action:
                self.view_template_documentation(template_name)
            elif action == delete_action:
                # Pass the relative path for accurate deletion
                self.delete_template(item_data['path'])
            return

        # --- Existing logic for Python Bot Modules (Unchanged) ---
        module_to_edit = None
        class_to_edit = ""
        method_to_edit = ""
        if isinstance(item_data, tuple) and len(item_data) == 5:
            _, class_name, method_name, module_name, _ = item_data
            module_to_edit = module_name
            class_to_edit = class_name
            method_to_edit = method_name
        elif item.childCount() > 0 and item.parent() is not None and item.parent() is not self.module_tree.invisibleRootItem():
            if item.childCount() > 0:
                first_method_item = item.child(0)
                method_data = self._get_item_data(first_method_item)
                if isinstance(method_data, tuple):
                    _, _, _, module_name, _ = method_data
                    module_to_edit = module_name
                    class_to_edit = item.text(0)
        elif item.parent() is self.module_tree.invisibleRootItem() and item.text(0) != "Bot Templates":
            module_to_edit = item.text(0)

        if module_to_edit:
            edit_action = context_menu.addAction(f"✏️ Edit in Jupyter Notebook")
            action = context_menu.exec(self.module_tree.mapToGlobal(position))
            if action == edit_action:
                self.modify_method(module_to_edit, class_to_edit, method_to_edit)
            return
# In MainWindow class
# ADD this new method

    def _create_template_folder(self, parent_item: QTreeWidgetItem):
        """
        Opens a dialog to get a folder name and creates a new directory on the file system
        within the Bot Templates structure.
        """
        parent_data = self._get_item_data(parent_item)
        if not parent_data:
            return

        # Determine the base directory for the new folder
        if parent_data['type'] == 'template_root':
            base_dir = self.steps_template_directory
        elif parent_data['type'] == 'template_folder':
            base_dir = os.path.join(self.steps_template_directory, parent_data['path'])
        else:
            return # Cannot create folder here

        folder_name, ok = QInputDialog.getText(self, "Create New Folder", "Enter folder name:")

        if ok and folder_name:
            # Sanitize folder name
            sanitized_name = "".join(c for c in folder_name if c.isalnum() or c in (' ', '_', '-')).rstrip()
            if not sanitized_name:
                QMessageBox.warning(self, "Invalid Name", "Folder name cannot be empty or contain only invalid characters.")
                return

            new_folder_path = os.path.join(base_dir, sanitized_name)

            if os.path.exists(new_folder_path):
                QMessageBox.warning(self, "Folder Exists", f"A folder named '{sanitized_name}' already exists in this location.")
                return

            try:
                os.makedirs(new_folder_path)
                self._log_to_console(f"Created template folder: {new_folder_path}")
                # Refresh the entire tree to show the new folder
                self.load_all_modules_to_tree()
            except Exception as e:
                QMessageBox.critical(self, "Error", f"Could not create folder:\n{e}")
    def view_template_documentation(self, template_name: str):
        """Finds and displays the HTML documentation for a given template."""
        os.makedirs(self.template_document_directory, exist_ok=True)
    
        doc_path = os.path.join(self.template_document_directory, f"{template_name}.html")
    
        if os.path.exists(doc_path):
            dialog = HtmlViewerDialog(doc_path, self)
            dialog.exec()
        else:
            QMessageBox.information(self, "Documentation Not Found",
                                      f"No documentation file found at:\n{doc_path}")
    
    def delete_template(self, template_relative_path: str):
        """Deletes a template file after user confirmation using its relative path."""
        template_name_for_display = os.path.splitext(os.path.basename(template_relative_path))[0]
        reply = QMessageBox.question(self, "Confirm Delete",
                                     f"Are you sure you want to permanently delete the template '{template_name_for_display}'?",
                                     QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                                     QMessageBox.StandardButton.No)

        if reply == QMessageBox.StandardButton.Yes:
            try:
                # Use the relative path for accurate deletion
                template_path = os.path.join(self.steps_template_directory, template_relative_path)
                if os.path.exists(template_path):
                    os.remove(template_path)
                    QMessageBox.information(self, "Success", f"Template '{template_name_for_display}' has been deleted.")
                    self.load_all_modules_to_tree() # Refresh tree
                else:
                    QMessageBox.warning(self, "File Not Found", f"The template file for '{template_name_for_display}' could not be found.")
            except Exception as e:
                QMessageBox.critical(self, "Error", f"An error occurred while deleting the template:\n{e}")

    def read_method_documentation(self, module_name: str, class_name: str, method_name: str):
        try:
            if self.module_directory not in sys.path:
                sys.path.insert(0, self.module_directory)
            module = importlib.import_module(module_name)
            importlib.reload(module)
            class_obj = getattr(module, class_name)
            method_obj = getattr(class_obj, method_name)
            docstring = inspect.getdoc(method_obj)
            if not docstring:
                docstring = "No documentation found for this method."
            QMessageBox.information(self, f"Documentation for {class_name}.{method_name}", docstring)
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Could not read documentation: {e}")
        finally:
            if self.module_directory in sys.path:
                sys.path.remove(self.module_directory)

# In the MainWindow class, REPLACE the modify_method

# In the MainWindow class, REPLACE the modify_method

# In the MainWindow class, REPLACE the modify_method

    def modify_method(self, module_name: str, class_name: str, method_name: str):
        """
        Finds the associated module folder and launches Jupyter Notebook to open that folder,
        allowing the user to see and edit all related bot modules.
        """
        try:
            # 1. Get the path to the Bot_module directory (this is unchanged).
            # self.module_directory already points to ".../App content/Bot_module/"
            module_folder_path = self.module_directory
            if not os.path.exists(module_folder_path):
                QMessageBox.critical(self, "Folder Not Found", f"The Bot module folder '{module_folder_path}' could not be found.")
                return

            self._log_to_console(f"Attempting to launch Jupyter Notebook in folder: '{module_folder_path}'.")
            
            # 2. Construct the path to the Jupyter executable (this is unchanged).
            python_env_dir = os.path.join(self.base_directory, 'python-embed')
            jupyter_executable = os.path.join(python_env_dir, 'Scripts', 'jupyter-notebook.exe')

            # 3. Check if the Jupyter executable exists (this is unchanged).
            if not os.path.exists(jupyter_executable):
                QMessageBox.critical(self, "Jupyter Not Found", 
                                     f"Could not find 'jupyter-notebook.exe' at the expected path:\n"
                                     f"{jupyter_executable}\n\n"
                                     "Please ensure your 'python-embed' folder is located inside the 'App content' directory.")
                return

            # =======================================================================
            # --- THIS IS THE KEY MODIFICATION ---
            # Instead of passing the specific .py file, we now launch Jupyter
            # without a file argument, and set its working directory to the
            # Bot_module folder. This will cause Jupyter to open its file
            # browser at that location.
            # =======================================================================
            
            # 4. Launch Jupyter in a new process, setting its starting directory.
            command = [jupyter_executable]
            subprocess.Popen(command, cwd=module_folder_path) # <-- THE CHANGE IS HERE
            
            QMessageBox.information(self, "Jupyter Launched", 
                                    "Jupyter Notebook is launching in your web browser, showing the Bot_module folder.\n\n"
                                    "After saving your changes in Jupyter, you may need to reload the modules "
                                    "in this app to see the changes.")

        except Exception as e:
            QMessageBox.critical(self, "Jupyter Launch Error", f"An unexpected error occurred while trying to start Jupyter Notebook:\n{e}")



# In main_app.py
# In the MainWindow class

    def check_schedules(self):
        """
        Timer-triggered function to check for and run scheduled bots.
        This version correctly handles multiple bots and ensures the UI is updated.
        It now saves the current user workflow before running a scheduled task.
        The rescheduling logic now intelligently handles time boundaries.
        """
        if self.is_bot_running:
            return  # Main guard: If a bot is already running, do nothing.

        now = QDateTime.currentDateTime()
        
        bot_names = list(self.schedules.keys())
        
        due_bots = []
        for bot_name in bot_names:
            schedule_data = self.schedules.get(bot_name)

            if not (schedule_data and schedule_data.get("enabled")):
                continue

            start_datetime = QDateTime.fromString(schedule_data.get("start_datetime"), Qt.DateFormat.ISODate)

            if now >= start_datetime:
                repeat_mode = schedule_data.get("repeat")
                current_day_str = now.toString("ddd")
                current_time = now.time()

                # MODIFIED: Condition now includes new minute-based intervals
                if repeat_mode not in ["Do not repeat", "Monthly"]:
                    selected_days = schedule_data.get("selected_days", [])
                    if selected_days and current_day_str not in selected_days:
                        continue

                if schedule_data.get("time_boundary_enabled", False):
                    start_time = QTime.fromString(schedule_data.get("start_time", "00:00:00"), Qt.DateFormat.ISODate)
                    end_time = QTime.fromString(schedule_data.get("end_time", "23:59:59"), Qt.DateFormat.ISODate)
                    if not (start_time <= current_time <= end_time):
                        self._log_to_console(f"Skipping '{bot_name}': Current time {current_time.toString('HH:mm:ss')} is outside boundary.")
                        continue
                
                due_bots.append({
                    "name": bot_name,
                    "schedule": schedule_data,
                    "start_datetime": start_datetime
                })

        if not due_bots:
            return

        bot_to_run = due_bots[0]
        bot_name = bot_to_run["name"]
        schedule_data = bot_to_run["schedule"]
        start_datetime = bot_to_run["start_datetime"]
        
        file_path = os.path.join(self.bot_steps_directory, f"{bot_name}.csv")

        self._log_to_console(f"Executing scheduled bot: '{bot_name}'")

        if self.added_steps_data:
            self._log_to_console("Scheduler: Current workflow is not empty. Saving to restore file.")
            self._save_workflow_to_file(self.scheduled_task_restore_file)

        loaded_data = self._load_data_from_csv(file_path)
        if not loaded_data:
            self._log_to_console(f"CRITICAL: Could not load data for scheduled bot '{bot_name}'. Skipping.")
            return
        
        loaded_vars, loaded_steps = loaded_data
        
        self._apply_loaded_data_to_ui(loaded_vars, loaded_steps, bot_name)

        self.is_bot_running = True
        self.is_paused = False
        self.setWindowFlag(Qt.WindowType.WindowStaysOnTopHint, True)
        self.show()
        self.exit_button.setText("🛑 Stop")
        self.exit_button.setToolTip("Stop the current execution and return to the canvas")
        try: self.exit_button.clicked.disconnect()
        except TypeError: pass
        self.exit_button.clicked.connect(self._handle_execute_pause_resume)
        self.execute_all_button.setText("⏸️ Pause")
        self.execute_all_button.setToolTip("Pause the running execution")
        self.minimized_for_execution = True
        self.original_geometry = self.geometry()
        
        self.workflow_scroll_area.setWidgetResizable(False)
        def store_home(widget):
            if widget.parent() is not None and widget.parent().layout() is not None:
                parent_layout = widget.parent().layout()
                index = parent_layout.indexOf(widget)
                self.widget_homes[widget] = (parent_layout, index)
        store_home(self.execute_all_button); store_home(self.exit_button)
        store_home(self.workflow_scroll_area); store_home(self.label_info2)
        
        self.left_menu.setVisible(False); self.right_panels.setVisible(False)
        self.normal_mode_widget.setVisible(False)
        self.focus_mode_layout.addWidget(self.workflow_scroll_area); self.workflow_scroll_area.setVisible(True)
        self.focus_mode_layout.addWidget(self.label_info2); self.label_info2.setVisible(True)
        if not hasattr(self, 'execution_control_widget'):
            self.execution_control_widget = QWidget()
            self.execution_control_widget.setLayout(QHBoxLayout())
            self.execution_control_widget.layout().setContentsMargins(5, 5, 5, 5)
        self.focus_mode_layout.addWidget(self.execution_control_widget)
        self.execution_control_widget.layout().addWidget(self.execute_all_button)
        self.execution_control_widget.layout().addWidget(self.exit_button)
        self.focus_mode_widget.setVisible(True)
        
        screen = QApplication.primaryScreen().geometry()
        new_width = int(self.original_geometry.width() * 0.25)
        new_height = int(self.original_geometry.height() * 0.30)
        self.resize(new_width, new_height); self.move(screen.width() - new_width - 10, 10)

        self.set_ui_enabled_state(False)
        self.progress_bar.show()
        
        self.worker = ExecutionWorker(
            steps_to_execute=loaded_steps,
            module_directory=self.module_directory,
            gui_communicator=self.gui_communicator,
            global_variables_ref=loaded_vars,
            wait_config=self.wait_time_between_steps,
            bot_name=bot_name,
            email_config=schedule_data
        )
        
        self._connect_worker_signals()
        self.worker.start()
        
        # --- START: MODIFIED INTELLIGENT RESCHEDULING LOGIC ---
        repeat_mode = schedule_data.get("repeat")
        if repeat_mode != "Do not repeat":
            
            base_time = QDateTime.currentDateTime()
            next_run_time = base_time # Initialize
            
            # 1. Calculate the simple next run time
            if repeat_mode == "Every 5 minutes":
                next_run_time = base_time.addSecs(300) # 5 * 60
            elif repeat_mode == "Every 15 minutes":
                next_run_time = base_time.addSecs(900) # 15 * 60
            elif repeat_mode == "Every 30 minutes":
                next_run_time = base_time.addSecs(1800) # 30 * 60
            elif repeat_mode == "Hourly":
                next_run_time = base_time.addSecs(3600)
            elif repeat_mode == "Daily":
                next_run_time = base_time.addDays(1)
            elif repeat_mode == "Monthly":
                next_run_time = base_time.addMonths(1)
            
            # 2. Check if boundaries apply and adjust if necessary
            if schedule_data.get("time_boundary_enabled", False):
                start_time = QTime.fromString(schedule_data.get("start_time", "00:00:00"), Qt.DateFormat.ISODate)
                end_time = QTime.fromString(schedule_data.get("end_time", "23:59:59"), Qt.DateFormat.ISODate)
                
                # If the next run time is after today's end time...
                if next_run_time.time() > end_time:
                    self._log_to_console(f"Next run at {next_run_time.time().toString('HH:mm')} is after end time {end_time.toString('HH:mm')}. Finding next valid day.")
                    # ...move to the next day and set the time to the start of the boundary
                    next_run_time = next_run_time.addDays(1)
                    next_run_time.setTime(start_time)

            # 3. Find the next valid day of the week if specified
            selected_days = schedule_data.get("selected_days", [])
            if selected_days and repeat_mode != "Monthly": # Day of week is less relevant for monthly
                # Keep adding one day until we land on a selected day
                while next_run_time.toString("ddd") not in selected_days:
                    next_run_time = next_run_time.addDays(1)
                    # When jumping to a new day, always reset to the start time if boundary is enabled
                    if schedule_data.get("time_boundary_enabled", False):
                        next_run_time.setTime(QTime.fromString(schedule_data.get("start_time"), Qt.DateFormat.ISODate))
            
            schedule_data["start_datetime"] = next_run_time.toString(Qt.DateFormat.ISODate)

        else: # "Do not repeat"
            schedule_data["enabled"] = False
        # --- END: MODIFIED INTELLIGENT RESCHEDULING LOGIC ---
        
        self.schedules[bot_name] = schedule_data
        self.save_schedules()
        self._write_schedule_to_csv(file_path, schedule_data)
        self.load_saved_steps_to_tree()

        if repeat_mode != "Do not repeat":
            self._log_to_console(f"Rescheduled '{bot_name}' to run next at {schedule_data['start_datetime']}")
        else:
            self._log_to_console(f"Disabled non-repeating schedule for '{bot_name}'.")


    def _read_schedule_from_csv(self, file_path: str) -> Optional[Dict[str, Any]]:
        """Reads only the schedule info from a bot's CSV file."""
        if not os.path.exists(file_path):
            return None
        try:
            with open(file_path, 'r', newline='', encoding='utf-8') as csvfile:
                reader = csv.reader(csvfile)
                for row in reader:
                    if row and row[0] == "__SCHEDULE_INFO__":
                        schedule_row = next(reader, None)
                        if schedule_row:
                            return json.loads(schedule_row[0])
            return None
        except (Exception, json.JSONDecodeError):
            return None

    def _write_schedule_to_csv(self, file_path: str, schedule_data: Dict[str, Any]) -> bool:
        """Writes or updates the schedule info in a bot's CSV file."""
        lines = []
        schedule_written = False
        try:
            if os.path.exists(file_path):
                with open(file_path, 'r', newline='', encoding='utf-8') as f:
                    lines = list(csv.reader(f))

            with open(file_path, 'w', newline='', encoding='utf-8') as f:
                writer = csv.writer(f)
                
                try:
                    schedule_header_index = [i for i, row in enumerate(lines) if row and row[0] == "__SCHEDULE_INFO__"][0]
                    lines[schedule_header_index + 1] = [json.dumps(schedule_data)]
                    schedule_written = True
                except IndexError:
                    pass
                
                if schedule_written:
                    writer.writerows(lines)
                else:
                    writer.writerow(["__SCHEDULE_INFO__"])
                    writer.writerow([json.dumps(schedule_data)])
                    writer.writerows(lines)
            return True
        except Exception as e:
            self._log_to_console(f"Error writing schedule to {file_path}: {e}")
            return False
            
    def _log_to_console(self, message: str) -> None:
        timestamp = datetime.now().strftime("%H:%M:%S")
        self.log_console.append(f"[{timestamp}] {message}")

    def update_application(self):
        """
        Initiates the application update process.
        It first tries to download the update from GitHub automatically.
        If the automatic download or file processing fails, it will prompt
        the user to download the file manually and then select it.
        """
        github_zip_url = "https://github.com/tuanhungstar/automateclick/archive/refs/heads/main.zip"
        self.update_dir = os.path.join(self.base_directory, "update")
        zip_path = os.path.join(self.update_dir, "update.zip")

        os.makedirs(self.update_dir, exist_ok=True)

        try:
            # 1. Attempt to download the file automatically
            self._log_to_console("Attempting to download update automatically...")
            with urllib.request.urlopen(github_zip_url) as response, open(zip_path, 'wb') as out_file:
                shutil.copyfileobj(response, out_file)
            self._log_to_console("Download complete.")

            # 2. Process the downloaded zip file
            if not self._process_zip_file(zip_path):
                # _process_zip_file returns False if the zip is bad.
                # This will trigger the manual download flow.
                raise zipfile.BadZipFile("The automatically downloaded file was invalid.")

        except (urllib.error.URLError, zipfile.BadZipFile) as e:
            # 3. This block executes if automatic download or zip processing fails
            self._log_to_console(f"Automatic update failed: {e}. Switching to manual download.")

            msg_box = QMessageBox(self)
            msg_box.setIcon(QMessageBox.Icon.Warning) # Changed to Warning icon
            msg_box.setWindowTitle("Update Action Required")
            msg_box.setTextFormat(Qt.TextFormat.RichText)
            msg_box.setText(
                "Could not get the update automatically. The file may be blocked by your network or corrupted.<br><br>"
                "<b>Step 1:</b> Please download the file manually from this link:<br>"
                f"<a href='{github_zip_url}'>{github_zip_url}</a><br><br>"
                "<b>Step 2:</b> After the download is complete, click the <b>'Select File...'</b> button below and choose the file you just saved."
            )
            select_file_button = msg_box.addButton("Select File...", QMessageBox.ButtonRole.ActionRole)
            msg_box.addButton("Cancel", QMessageBox.ButtonRole.RejectRole)
            msg_box.exec()

            # If the user clicked the 'Select File...' button
            if msg_box.clickedButton() == select_file_button:
                file_path, _ = QFileDialog.getOpenFileName(self, "Select Downloaded Update File", "", "Zip Files (*.zip)")
                if file_path:
                    # Process the user-selected zip file
                    self._process_zip_file(file_path)

        except Exception as e:
            # Catch any other unexpected errors
            QMessageBox.critical(self, "Update Error", f"An unexpected error occurred: {e}")

    def _process_zip_file(self, zip_path):
        try:
            with zipfile.ZipFile(zip_path, 'r') as zip_ref:
                zip_ref.extractall(self.update_dir)

            extracted_folder_name = ""
            for item in os.listdir(self.update_dir):
                if os.path.isdir(os.path.join(self.update_dir, item)) and "utomate" in item:
                    extracted_folder_name = item
                    break

            if not extracted_folder_name:
                raise Exception("Could not find the main folder in the downloaded zip.")

            extracted_path = os.path.join(self.update_dir, extracted_folder_name)
            dialog = UpdateDialog(extracted_path, self.base_directory, self)
            dialog.exec()
        
        except Exception as e:
            QMessageBox.critical(self, "Update Error", f"An error occurred while processing the file: {e}")
    def _update_workflow_tab(self, switch_to_tab: bool = False) -> None:
        """
        Enhanced workflow tab update with better canvas initialization.
        """
        # Clean up the old canvas
        old_canvas = self.workflow_scroll_area.takeWidget()
        if old_canvas:
            try:
                old_canvas.execute_step_requested.disconnect()
            except (TypeError, AttributeError):
                pass
            old_canvas.deleteLater()

        # Create new canvas
        try:
            if self.added_steps_data:
                workflow_tree = self._build_workflow_tree_data()
                if workflow_tree:
                    self.workflow_canvas = WorkflowCanvas(workflow_tree, self)
                    self.workflow_canvas.execute_step_requested.connect(self._handle_execute_this_request)
                else:
                    self.workflow_canvas = WorkflowCanvas([], self)
            else:
                self.workflow_canvas = WorkflowCanvas([], self)
            
            # Set up the canvas in scroll area
            self.workflow_scroll_area.setWidget(self.workflow_canvas)
            self.workflow_scroll_area.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
            self.workflow_scroll_area.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
            
            # Force proper sizing calculation
            if self.added_steps_data:
                self.workflow_canvas._adjust_canvas_size()
            
            if switch_to_tab:
                self.main_tab_widget.setCurrentWidget(self.workflow_scroll_area.parentWidget())
                self._log_to_console("Workflow tab updated and displayed")
            else:
                self._log_to_console("Workflow tab updated in background")
            
        except Exception as e:
            # Fallback: create empty canvas
            self.workflow_canvas = WorkflowCanvas([], self)
            self.workflow_scroll_area.setWidget(self.workflow_canvas)
            
            if switch_to_tab:
                QMessageBox.critical(self, "Workflow Error", f"Error building workflow: {e}")
            self._log_to_console(f"Workflow build error: {e}")

    def _build_workflow_tree_data(self) -> List[Dict[str, Any]]:
        """
        Parses the flat self.added_steps_data into a nested tree structure
        that supports IF/ELSE and LOOP/END branching. [CORRECTED VERSION]
        """
        def parse_block_recursive(flat_steps: List[Dict[str, Any]], index: int) -> Tuple[List[Dict[str, Any]], int]:
            nodes = []
            i = index
            while i < len(flat_steps):
                step_data = flat_steps[i]
                step_type = step_data.get("type")

                # --- Exit Condition: Stop parsing when we hit an end or else tag ---
                if step_type in ["group_end", "loop_end", "IF_END", "ELSE"]:
                    return nodes, i

                new_node = {'step_data': step_data, 'children': []}
                i += 1 # Move to the next step

                # --- Recursive Parsing for Block Types ---
                if step_type == "group_start":
                    # Parse children until a 'group_end' is found
                    children, end_index = parse_block_recursive(flat_steps, i)
                    new_node['children'] = children
                    i = end_index

                    # Consume the 'group_end' tag
                    if i < len(flat_steps) and flat_steps[i].get("type") == "group_end":
                        i += 1 # Move past the 'group_end' tag
                    nodes.append(new_node)
                    continue

                elif step_type == "IF_START" or step_type == "loop_start":
                    # Parse the main ("true") branch
                    children, next_index = parse_block_recursive(flat_steps, i)
                    new_node['children'] = children
                    i = next_index

                    # --- Correctly Handle IF-ELSE structure ---
                    if step_type == "IF_START" and i < len(flat_steps) and flat_steps[i].get("type") == "ELSE":
                        # The 'ELSE' is NOT a child. We record its steps in 'false_children'.
                        new_node['false_children'] = []
                        i += 1 # Consume the 'ELSE' tag

                        # Parse the 'else' branch until an 'IF_END' is found
                        false_children, end_index = parse_block_recursive(flat_steps, i)
                        # We store the actual steps, not the ELSE tag itself
                        new_node['false_children'] = false_children
                        i = end_index

                    # --- Find and attach the End Node ---
                    end_tag = "IF_END" if step_type == "IF_START" else "loop_end"
                    if i < len(flat_steps) and flat_steps[i].get("type") == end_tag:
                        # Attach the end node data to the start node
                        new_node['end_node'] = {'step_data': flat_steps[i]}
                        i += 1 # Consume the 'end_tag'

                # --- Add the fully constructed node (step, if, loop, or group) ---
                nodes.append(new_node)

            return nodes, i

        # Start the parsing from the beginning of the flat list
        root_nodes, _ = parse_block_recursive(self.added_steps_data, 0)
        return root_nodes

    def _get_image_filenames(self) -> List[str]:
            """Gets a sorted list of image names, including relative paths from subfolders."""
            relative_paths: List[str] = []
            if not os.path.exists(self.click_image_dir):
                return []
                
            for root, _, files in os.walk(self.click_image_dir):
                for filename in files:
                    if filename.lower().endswith(".txt"):
                        full_path = os.path.join(root, filename)
                        # Get the path relative to click_image_dir
                        relative_path = os.path.relpath(full_path, self.click_image_dir)
                        
                        # If the file is in the root, relpath is "filename.txt"
                        # If in subfolder, it's "Subfolder/filename.txt"
                        
                        # Remove the .txt extension
                        relative_path_no_ext = os.path.splitext(relative_path)[0]
                        
                        # Standardize on '/' for path separators
                        relative_paths.append(relative_path_no_ext.replace(os.sep, '/'))
                            
            return sorted(relative_paths)
        
    def _set_step_execution_status(self, step_data: Dict[str, Any], status: str):
            """Sets the execution status for a step in both tree and workflow views."""
            
            if status == "normal":
                if "execution_status" in step_data:
                    del step_data["execution_status"]
            else:
                step_data["execution_status"] = status
            
            # Update the workflow canvas if it exists
            if hasattr(self, 'workflow_canvas') and self.workflow_canvas:
                self.workflow_canvas.update()
    
    def _clear_all_execution_status(self):
        """Clears execution status from all steps."""
        for step_data in self.added_steps_data:
            if "execution_status" in step_data:
                del step_data["execution_status"]
            if "execution_result" in step_data:  # ADD THIS LINE
                del step_data["execution_result"]  # ADD THIS LINE
        
        # Update the workflow canvas
        if hasattr(self, 'workflow_canvas') and self.workflow_canvas:
            self.workflow_canvas.update()
            
    def _reset_loop_steps_status(self, loop_id: str):
        """Resets the execution status of all steps within a specific loop."""
        if not loop_id:
            return
            
        # Find the loop boundaries
        loop_start_index = -1
        loop_end_index = -1
        
        for i, step_data in enumerate(self.added_steps_data):
            if (step_data.get("type") == "loop_start" and 
                step_data.get("loop_id") == loop_id):
                loop_start_index = i
            elif (step_data.get("type") == "loop_end" and 
                  step_data.get("loop_id") == loop_id and 
                  loop_start_index != -1):
                loop_end_index = i
                break
        
        if loop_start_index == -1 or loop_end_index == -1:
            return
            
        # Reset status for all steps within the loop (excluding the loop_start and loop_end)
        for i in range(loop_start_index + 1, loop_end_index):
            step_data = self.added_steps_data[i]
            if "execution_status" in step_data:
                del step_data["execution_status"]
            
            # Also reset the visual status in the execution tree
            item_widget = self._find_qtreewidget_item(step_data)
            if item_widget:
                card = self.execution_tree.itemWidget(item_widget, 0)
                if card:
                    card.set_status("#D3D3D3")  # Normal gray border
                    card.clear_result()
        
        # Update the workflow canvas to reflect the changes
        if hasattr(self, 'workflow_canvas') and self.workflow_canvas:
            self.workflow_canvas.update()
            
        self._log_to_console(f"🔄 Loop '{loop_id}' iteration started - Reset status of {loop_end_index - loop_start_index - 1} steps within the loop")

    def _reset_nested_loop_steps_status(self, loop_id: str):
        """Resets execution status for steps in a loop, handling nested structures properly."""
        if not loop_id:
            return
            
        # Find all steps that belong to this loop (including nested structures)
        loop_steps = []
        current_loop_level = 0
        inside_target_loop = False
        
        for i, step_data in enumerate(self.added_steps_data):
            step_type = step_data.get("type")
            step_loop_id = step_data.get("loop_id")
            step_if_id = step_data.get("if_id")
            step_group_id = step_data.get("group_id")
            
            # Check if we're entering our target loop
            if step_type == "loop_start" and step_loop_id == loop_id:
                inside_target_loop = True
                current_loop_level = 0
                continue
                
            # Check if we're exiting our target loop
            if step_type == "loop_end" and step_loop_id == loop_id and inside_target_loop:
                break
                
            # If we're inside the target loop, track nesting and collect steps
            if inside_target_loop:
                # Track nesting level for other structures
                if step_type in ["loop_start", "IF_START", "group_start"]:
                    current_loop_level += 1
                elif step_type in ["loop_end", "IF_END", "group_end"]:
                    current_loop_level -= 1
                
                # Add this step to our reset list
                loop_steps.append((i, step_data))
        
        # Reset status for all collected steps
        reset_count = 0
        for step_index, step_data in loop_steps:
            if "execution_status" in step_data:
                del step_data["execution_status"]
                reset_count += 1
            if "execution_result" in step_data:  # ADD THIS LINE
                del step_data["execution_result"]  # ADD THIS LINE
            # Also reset the visual status in the execution tree
            item_widget = self._find_qtreewidget_item(step_data)
            if item_widget:
                card = self.execution_tree.itemWidget(item_widget, 0)
                if card:
                    card.set_status("#D3D3D3")  # Normal gray border
                    card.clear_result()
        
        # Update the workflow canvas to reflect the changes
        if hasattr(self, 'workflow_canvas') and self.workflow_canvas:
            self.workflow_canvas.update()
            
        if reset_count > 0:
            self._log_to_console(f"🔄 Loop '{loop_id}' new iteration - Reset status of {reset_count} steps within the loop")
            
    def _handle_step_drag_started(self, step_data: Dict[str, Any], original_index: int):
        """Handle when a step card starts being dragged."""
        self._log_to_console(f"Drag started for step at index {original_index}")

    def _handle_step_reorder(self, source_index: int, target_index: int):
        """Handle reordering of steps via drag and drop."""
        if source_index == target_index or source_index == -1 or target_index == -1:
            return
        
        # Clamp target_index to valid range
        target_index = max(0, min(target_index, len(self.added_steps_data)))
        
        # Perform the reordering
        self._reorder_steps_smart(source_index, target_index)

    def _reorder_steps_smart(self, source_index: int, target_index: int):
        """Smart reordering that respects block boundaries."""
        if not (0 <= source_index < len(self.added_steps_data)):
            return
        
        # Get the block boundaries for the source step
        source_start, source_end = self._find_block_indices(source_index)
        
        # Calculate the actual target position
        if target_index > source_end:
            # Moving down - adjust target to account for removed items
            actual_target = target_index - (source_end - source_start + 1)
        else:
            actual_target = target_index
        
        # Ensure target is within bounds
        actual_target = max(0, min(actual_target, len(self.added_steps_data) - (source_end - source_start + 1)))
        
        # Extract the block to move
        steps_to_move = self.added_steps_data[source_start:source_end + 1]
        
        # Remove from original position
        del self.added_steps_data[source_start:source_end + 1]
        
        # Insert at new position
        for i, step in enumerate(steps_to_move):
            self.added_steps_data.insert(actual_target + i, step)
        
        # Rebuild the tree and focus on the moved block
        self._rebuild_execution_tree(item_to_focus_data=steps_to_move[0])
        
        self._log_to_console(f"Moved step block from index {source_index} to {actual_target}")
    '''
    def _calculate_smart_insertion_index(self, selected_tree_item: Optional[QTreeWidgetItem], insert_mode: str) -> int:
        """Enhanced insertion calculation that properly handles block structures."""
        if selected_tree_item is None:
            # If no item is selected, insert at the end of the entire list.
            return len(self.added_steps_data)

        selected_item_data = self._get_item_data(selected_tree_item)
        if not selected_item_data:
            # If the item has no associated data, treat as inserting at the end.
            return len(self.added_steps_data)

        try:
            selected_flat_index = self.added_steps_data.index(selected_item_data)
        except ValueError as e:
            error_content = str(e)
            self._log_to_console(f"ValueError in insertion index calculation: {error_content}")
            print ("error:", str(ValueError))
            # If the selected item's data is not found in the flat list, insert at the end.
            return len(self.added_steps_data)
        
        selected_step_type = selected_item_data.get("type")

        if insert_mode == "before":
            return selected_flat_index
        elif insert_mode == "after":
            return selected_flat_index + 1
        
        # Fallback, should not be reached with "before" or "after" modes.
        return len(self.added_steps_data)
        '''
    def _calculate_smart_insertion_index(self, selected_tree_item: Optional[QTreeWidgetItem], insert_mode: str) -> int:
        """Enhanced insertion calculation that properly handles block structures."""
        if selected_tree_item is None:
            # If no item is selected, insert at the end of the entire list.
            return len(self.added_steps_data)

        selected_item_data = self._get_item_data(selected_tree_item)
        if not selected_item_data:
            # If the item has no associated data, treat as inserting at the end.
            return len(self.added_steps_data)

        # Use original_listbox_row_index for more reliable lookup
        selected_flat_index = selected_item_data.get("original_listbox_row_index")
        
        # If original_listbox_row_index is not available or invalid, try to find by identity
        if selected_flat_index is None or not (0 <= selected_flat_index < len(self.added_steps_data)):
            try:
                # Try to find by object identity first (fastest)
                for i, step_data in enumerate(self.added_steps_data):
                    if step_data is selected_item_data:
                        selected_flat_index = i
                        break
                else:
                    # If identity search fails, try equality comparison
                    selected_flat_index = self.added_steps_data.index(selected_item_data)
            except ValueError as e:
                error_content = str(e)
                self._log_to_console(f"ValueError in insertion index calculation: {error_content}")
                # If the selected item's data is not found in the flat list, insert at the end.
                return len(self.added_steps_data)
        
        # Verify the index is still valid
        if not (0 <= selected_flat_index < len(self.added_steps_data)):
            return len(self.added_steps_data)
            
        selected_step_type = selected_item_data.get("type")

        if insert_mode == "before":
            return selected_flat_index
        elif insert_mode == "after":
            return selected_flat_index + 1
        
        # Fallback, should not be reached with "before" or "after" modes.
        return len(self.added_steps_data)
    # In the MainWindow class, add this new method
# In the MainWindow class, REPLACE the existing edit_step_from_data method with this one.

# In the MainWindow class, REPLACE the existing edit_step_from_data method with this enhanced version:

    def edit_step_from_data(self, step_data: Dict[str, Any]):
        """
        Enhanced version that maintains workflow centering after parameter configuration.
        """
        # 1. Get the unique identifier for the step
        step_index = step_data.get("original_listbox_row_index")

        # 2. Basic validation
        if step_index is None:
            QMessageBox.warning(self, "Edit Error", "The selected workflow shape has no valid identifier.")
            return

        # 3. Check if the index is valid
        if not (0 <= step_index < len(self.added_steps_data)):
            QMessageBox.warning(self, "Edit Error", f"The step index '{step_index}' is out of bounds.")
            return

        # 4. Find the corresponding tree item
        item_to_edit = self.data_to_item_map.get(step_index)

        # 5. Edit the step and ensure proper centering afterward
        if item_to_edit:
            # Store the step data that we want to keep centered
            step_data_to_center = self.added_steps_data[step_index].copy()
            
            # Perform the edit operation
            self.edit_step_in_execution_tree(item_to_edit, 0)
            
            # After editing, the tree will rebuild automatically via the edit operation.
            # The _rebuild_execution_tree method will handle the centering using the
            # item_to_focus_data parameter that gets passed through the rebuild chain.
            
            # Additional safety: Schedule a backup centering operation
            def backup_center_operation():
                """Backup centering in case the main centering didn't work."""
                # Check if the workflow tab is visible
                workflow_tab_index = -1
                for i in range(self.main_tab_widget.count()):
                    if "Workflow" in self.main_tab_widget.tabText(i):
                        workflow_tab_index = i
                        break
                
                if (workflow_tab_index != -1 and 
                    self.main_tab_widget.currentIndex() == workflow_tab_index):
                    self._center_workflow_canvas_on_step(step_index)
            
            # Run backup centering after a longer delay to ensure everything is settled
            QTimer.singleShot(500, backup_center_operation)
            
        else:
            QMessageBox.warning(self, "Edit Error", "Could not find the corresponding UI element.")

# In MainWindow class, add this new method:

    def open_rearrange_steps_dialog(self):
        """Opens the dialog for reordering steps."""
        if not self.added_steps_data:
            QMessageBox.information(self, "No Steps", "There are no steps to rearrange.")
            return
            
        # Create an instance of our new dialog with the current steps
        dialog = RearrangeStepsDialog(self.added_steps_data, self)
        
        # If the user clicks "OK"
        if dialog.exec() == QDialog.DialogCode.Accepted:
            # Get the newly ordered list of steps from the dialog
            new_order = dialog.get_rearranged_steps()
            
            # Check if the order has actually changed
            if new_order != self.added_steps_data:
                self.added_steps_data = new_order
                
                # Rebuild the main execution tree to reflect the new order
                self._rebuild_execution_tree()
                
                self._log_to_console("Steps have been rearranged.")
            else:
                self._log_to_console("Step order remains unchanged.")
                
# In MainWindow class, REPLACE the set_wait_time method with this:

    def set_wait_time(self):
        """Opens an advanced dialog to set the wait time between execution steps."""
        
        # Create an instance of our new, more advanced dialog
        dialog = WaitTimeConfigDialog(
            global_variables=list(self.global_variables.keys()),
            initial_config=self.wait_time_between_steps,
            parent=self
        )
        
        if dialog.exec() == QDialog.DialogCode.Accepted:
            new_config = dialog.get_config()
            if new_config:
                self.wait_time_between_steps = new_config
                
                # Update button text to reflect the new setting
                if new_config['type'] == 'variable':
                    display_text = f"@{new_config['value']}"
                    self._log_to_console(f"Wait time will be determined by global variable '{display_text}'.")
                else:
                    display_text = f"{new_config['value']}s"
                    self._log_to_console(f"Wait time between steps set to {display_text}.")
                
                self.set_wait_time_button.setText(f"⏱️ Wait between Steps ({display_text})")
                    
    def _sync_counters_with_loaded_data(self):
        """Synchronizes the ID counters with the highest IDs found in loaded data."""
        max_loop_id = 0
        max_if_id = 0
        max_group_id = 0
        
        for step_data in self.added_steps_data:
            # Check loop IDs
            if "loop_id" in step_data:
                loop_id_str = step_data["loop_id"]
                if isinstance(loop_id_str, str) and loop_id_str.startswith("loop_"):
                    try:
                        loop_num = int(loop_id_str.split("_")[1])
                        max_loop_id = max(max_loop_id, loop_num)
                    except (IndexError, ValueError):
                        pass
            
            # Check IF IDs
            if "if_id" in step_data:
                if_id_str = step_data["if_id"]
                if isinstance(if_id_str, str) and if_id_str.startswith("if_"):
                    try:
                        if_num = int(if_id_str.split("_")[1])
                        max_if_id = max(max_if_id, if_num)
                    except (IndexError, ValueError):
                        pass
            
            # Check group IDs
            if "group_id" in step_data:
                group_id_str = step_data["group_id"]
                if isinstance(group_id_str, str) and group_id_str.startswith("group_"):
                    try:
                        group_num = int(group_id_str.split("_")[1])
                        max_group_id = max(max_group_id, group_num)
                    except (IndexError, ValueError):
                        pass
        
        # Update the counters to be the maximum found (next increment will be max+1)
        self.loop_id_counter = max_loop_id
        self.if_id_counter = max_if_id
        self.group_id_counter = max_group_id
        
        self._log_to_console(f"Synced counters - Loop: {self.loop_id_counter}, IF: {self.if_id_counter}, Group: {self.group_id_counter}")
# In MainWindow class
    def _clear_default_temp_file(self):
        """Specifically empties the default 'workflow_temp.json' file."""
        try:
            if os.path.exists(self.default_temp_file_path):
                with open(self.default_temp_file_path, 'w', encoding='utf-8') as f:
                    json.dump({"added_steps_data": [], "global_variables": {}}, f, indent=4)
                self._log_to_console(f"Default temp file '{os.path.basename(self.default_temp_file_path)}' cleared.")
        except Exception as e:
            self._log_to_console(f"Error clearing default temp file: {e}")
# In MainWindow class
    def _clear_temp_workflow_file(self):
        """Empties the currently active temporary workflow file."""
        try:
            # Use the currently active temp file path
            if os.path.exists(self.current_temp_file_path):
                with open(self.current_temp_file_path, 'w', encoding='utf-8') as f:
                    json.dump({"added_steps_data": [], "global_variables": {}}, f, indent=4)
                self._log_to_console(f"Temporary file '{os.path.basename(self.current_temp_file_path)}' cleared.")
        except Exception as e:
            self._log_to_console(f"Error clearing temporary file '{self.current_temp_file_path}': {e}")
            
    # Inside MainWindow class
# In MainWindow class
# In MainWindow class
    def _save_workflow_to_temp_file(self):
        """
        Saves the current workflow to the active temporary file.
        This now calls the general-purpose save method.
        """
        self._save_workflow_to_file(self.current_temp_file_path)
            
            
    # Inside MainWindow class
# In MainWindow class
    def _check_for_temp_workflow_recovery(self):
        """Checks if the default 'workflow_temp.json' exists and prompts the user to recover."""
        
        # This function now ONLY checks the default temp file path.
        if os.path.exists(self.default_temp_file_path):
            try:
                with open(self.default_temp_file_path, 'r', encoding='utf-8') as f:
                    temp_data = json.load(f)
                
                # Check if there's actual data in the default temp file
                has_temp_data = bool(temp_data.get("added_steps_data") or temp_data.get("global_variables"))

                if has_temp_data:
                    reply = QMessageBox.question(self, "Recover Unsaved Work",
                                                 "Unsaved 'untitled' work was detected. Do you want to recover it?",
                                                 QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No)
                    if reply == QMessageBox.StandardButton.Yes:
                        # Clear current state before loading temp
                        self._internal_clear_all_steps() 

                        self.added_steps_data = temp_data.get("added_steps_data", [])
                        self.global_variables = temp_data.get("global_variables", {})
                        # --- MODIFICATION STARTS HERE ---
                        self.group_expansion_states = temp_data.get("group_expansion_states", {})
                        # --- MODIFICATION ENDS HERE ---
                        self._sync_counters_with_loaded_data()
                        
                        # We are loading into an "untitled" session, so the current temp path
                        # IS the default temp path.
                        self.current_temp_file_path = self.default_temp_file_path
                        
                        self._rebuild_execution_tree()
                        self._update_variables_list_display()
                        self._log_to_console("Recovered 'untitled' workflow from temporary file.")
                        
                        return 
                
                # If temp_data was empty or user said No, clear the default temp file
                self._clear_default_temp_file() 
                
            except json.JSONDecodeError:
                self._log_to_console("Default temporary workflow file is corrupted, cannot recover. Clearing it.")
                self._clear_default_temp_file()
            except Exception as e:
                self._log_to_console(f"Error during default temporary workflow recovery: {e}. Clearing temp file.")
                self._clear_default_temp_file()
        else:
            # If temp file doesn't exist, create an empty one to start tracking
            self._clear_default_temp_file()
            
    def _handle_variable_double_click(self, item: QListWidgetItem) -> None:
        """
        Handles double-clicking a variable in the list. If the 'Data' tab is
        active, it attempts to display the variable's data in the table.
        Now inspects lists for worksheets.
        """
        # 1. Check if the "Data" tab is the active tab
        data_tab_index = -1
        for i in range(self.main_tab_widget.count()):
            if self.main_tab_widget.tabText(i) == "📊 Data":
                data_tab_index = i
                break
        
        if self.main_tab_widget.currentIndex() != data_tab_index:
            return # Do nothing if the data tab is not active

        # 2. Get the variable name and value
        var_name = item.text().split(' = ')[0]
        if var_name not in self.global_variables:
            return
            
        value = self.global_variables.get(var_name)

        df = None
        worksheet_to_display = None

        # 3. Check the type of the value
        try:
            if isinstance(value, pd.DataFrame):
                df = value
            elif isinstance(value, OpenpyxlWorksheet):
                worksheet_to_display = value
            elif isinstance(value, list):
                # --- NEW: Check first 5 items in the list ---
                for sub_item in value[:5]: # Slices list, safe for lists < 5 items
                    if isinstance(sub_item, OpenpyxlWorksheet):
                        worksheet_to_display = sub_item
                        self._log_to_console(f"Displaying worksheet found in list '@{var_name}'.")
                        break # Found one, no need to check further
            
            # 4. Convert worksheet to DataFrame if one was found
            if worksheet_to_display is not None:
                # Convert openpyxl.Worksheet to a pandas DataFrame
                data = worksheet_to_display.values
                # Get the first row as columns
                columns = next(data)[0:] 
                # Create the DataFrame
                df = pd.DataFrame(data, columns=columns)
            
            # 5. Display the DataFrame or clear the table
            if df is not None:
                self._display_dataframe_in_table(df)
            else:
                # Clear the table if the type is not displayable
                self.data_table_view.setModel(None)
                
        except Exception as e:
            self._log_to_console(f"Error displaying variable '{var_name}': {e}")
            self.data_table_view.setModel(None)
            
    def _display_dataframe_in_table(self, df: pd.DataFrame) -> None:
        """
        Converts a pandas DataFrame into a QStandardItemModel and displays it
        in the data_table_view.
        """
        try:
            # Create a new model
            model = QStandardItemModel(self)
            
            # Set headers
            model.setHorizontalHeaderLabels(df.columns.astype(str))
            
            # Set rows
            for i, row in df.iterrows():
                items = [
                    QStandardItem(str(value)) for value in row
                ]
                model.insertRow(i, items)
                
            # Apply the model to the table view
            self.data_table_view.setModel(model)
            
        except Exception as e:
            self._log_to_console(f"Error while populating data table: {e}")
            self.data_table_view.setModel(None)
            
# In MainWindow class
    def _reset_to_untitled_state(self):
        """
        Clears the UI and data, resets the temp file to the default 'untitled' one,
        and clears that default file.
        """
        # 1. Clear the UI and internal data
        self._internal_clear_all_steps()
        
        # 2. Reset the active temp file path back to the default "untitled" one
        self.current_temp_file_path = self.default_temp_file_path
        
        # 3. Clear the default temp file to ensure the new session is blank
        self._clear_default_temp_file()
        
        self._log_to_console("All steps cleared. Reset to 'untitled' state.")
        
        
        
    def center_on_step(self, step_index: int):
        """
        Programmatically centers the workflow view on a specific step.
        Useful for manual navigation and testing.
        """
        target_node_rect: Optional[QRect] = None
        
        for rect, _, _, node_step_data in self.nodes:
            node_index = node_step_data.get("original_listbox_row_index")
            if node_index == step_index:
                target_node_rect = rect
                break
        
        if not target_node_rect:
            return False
        
        try:
            # Get the center point of the target node
            node_center = target_node_rect.center()
            
            # Get viewport dimensions
            viewport_size = self.parent().viewport().size() if hasattr(self.parent(), 'viewport') else self.size()
            
            # Calculate required canvas offset to center the node
            target_offset_x = (viewport_size.width() // 2) - node_center.x()
            target_offset_y = (viewport_size.height() // 2) - node_center.y()
            
            # Apply the offset
            self.canvas_offset = QPoint(target_offset_x, target_offset_y)
            self.update()
            
            return True
            
        except Exception as e:
            if hasattr(self, 'main_window'):
                self.main_window._log_to_console(f"Error centering on step {step_index}: {e}")
            return False
            
# Add this new method to the MainWindow class:

# In main_app.py, inside the MainWindow class

    def _center_workflow_canvas_on_step(self, step_index: int) -> None:
        """
        Robustly centers the workflow canvas on a specific step by index.
        This method handles all the edge cases and ensures proper centering.
        """
        if not (hasattr(self, 'workflow_canvas') and self.workflow_canvas and 
                hasattr(self, 'workflow_scroll_area') and self.workflow_scroll_area.isVisible()):
            return

        try:
            # Find the target node in the workflow canvas
            target_rect = None
            target_step_data = None
            
            for rect, text, shape, node_step_data in self.workflow_canvas.nodes:
                node_index = node_step_data.get("original_listbox_row_index")
                if node_index == step_index:
                    target_rect = rect
                    target_step_data = node_step_data
                    break
            
            if not target_rect:
                self._log_to_console(f"Could not find workflow node for step {step_index}")
                return

            # Get scroll area components
            scroll_area = self.workflow_scroll_area
            viewport = scroll_area.viewport()
            canvas = self.workflow_canvas
            
            # Calculate the absolute position of the target node center
            canvas_offset = canvas.canvas_offset
            absolute_center_x = target_rect.center().x() + canvas_offset.x()
            absolute_center_y = target_rect.center().y() + canvas_offset.y()
            
            # Calculate the scroll positions needed to center the node
            viewport_center_x = viewport.width() // 2
            viewport_center_y = viewport.height() // 2
            
            target_scroll_x = absolute_center_x - viewport_center_x
            target_scroll_y = absolute_center_y - viewport_center_y
            
            # Get scroll bars and their ranges
            h_scrollbar = scroll_area.horizontalScrollBar()
            v_scrollbar = scroll_area.verticalScrollBar()
            
            # Clamp the scroll values to valid ranges
            final_scroll_x = max(h_scrollbar.minimum(), 
                               min(target_scroll_x, h_scrollbar.maximum()))
            final_scroll_y = max(v_scrollbar.minimum(), 
                               min(target_scroll_y, v_scrollbar.maximum()))
            
            # Apply the scrolling
            h_scrollbar.setValue(int(final_scroll_x))
            v_scrollbar.setValue(int(final_scroll_y))
            
            # Force a repaint to ensure the change is visible
            canvas.update()
            scroll_area.update()
            
            # --- LOGGING MODIFICATION ---
            # Get the node's position for logging
            node_pos = target_rect.topLeft()
            step_name = target_step_data.get("method_name", f"Step {step_index + 1}")
            
            if target_step_data.get("type") == 'group_start':
                group_name = target_step_data.get("group_name", "Unnamed")
                self._log_to_console(f"Canvas centered on Group '{group_name}' (Step {step_index + 1}) at canvas position ({node_pos.x()}, {node_pos.y()})")
            else:
                self._log_to_console(f"Workflow canvas centered on: {step_name} at canvas position ({node_pos.x()}, {node_pos.y()})")
            # --- END LOGGING MODIFICATION ---
            
        except Exception as e:
            self._log_to_console(f"Error centering workflow canvas on step {step_index}: {e}")        
            
    def _handle_view_workflow_click(self):
        """
        Handles the 'View Workflow' button click by switching to the workflow tab
        and centering on step 1 (the first step).
        """
        # First, update and switch to the workflow tab
        self._update_workflow_tab(switch_to_tab=True)
        
        # Then center on step 1 if there are any steps
        if self.added_steps_data:
            def center_on_step_1():
                """Centers the workflow on step 1 after tab switch is complete."""
                self._center_workflow_canvas_on_step(0)  # Step 1 is at index 0
                
            # Schedule the centering after the tab switch is complete
            QTimer.singleShot(300, center_on_step_1)
        else:
            self._log_to_console("No steps available to center on.")
            
            
    def get_variable_for_dialog(self, variable_name: str) -> Optional[Any]:
        """
        A callback function for dialogs to safely retrieve a global variable's object.
        
        This acts as a bridge between an isolated dialog (which doesn't have the
        ExecutionContext) and the main application's live data.
        
        Args:
            variable_name: The name of the variable to retrieve (e.g., "my_db_conn").

        Returns:
            The actual object (e.g., a pyodbc.Connection, a pd.DataFrame) or None if not found.
        """
        # 'self.global_variables' is the dictionary in your MainWindow
        # that stores the actual variable objects, keyed by their name.
        self._log_to_console(f"Dialog requested variable: '{variable_name}'")
        
        return self.global_variables.get(variable_name)
        
        
    def _save_workflow_to_file(self, file_path: str):
        """
        Saves the current workflow and global variables to a specified file.
        This is the new general-purpose save method.
        """
        try:
            os.makedirs(os.path.dirname(file_path), exist_ok=True)
            
            # Cleaning logic for robust saving
            variables_to_save = {}
            for var_name, var_value in self.global_variables.items():
                try:
                    json.dumps(var_value)
                    variables_to_save[var_name] = var_value
                except (TypeError, OverflowError):
                    variables_to_save[var_name] = None
            
            steps_to_save = []
            for step_data_dict in self.added_steps_data:
                step_data_to_save = json.loads(json.dumps(step_data_dict))
                step_data_to_save.pop("original_listbox_row_index", None)
                step_data_to_save.pop("execution_status", None)
                step_data_to_save.pop("execution_result", None)
                if step_data_to_save.get("type") == "step" and step_data_to_save.get("parameters_config"):
                    step_data_to_save["parameters_config"].pop("original_listbox_row_index", None)
                steps_to_save.append(step_data_to_save)

            # --- MODIFICATION STARTS HERE ---
            data_to_save = {
                "added_steps_data": steps_to_save,
                "global_variables": variables_to_save,
                "group_expansion_states": self.group_expansion_states # Add expansion states to the save data
            }
            # --- MODIFICATION ENDS HERE ---
            
            with open(file_path, 'w', encoding='utf-8') as f:
                json.dump(data_to_save, f, indent=4)
                
        except Exception as e:
            self._log_to_console(f"Error saving workflow to {file_path}: {e}")
            
    def _center_canvas_on_group(self, group_id: str):
        """Finds a group_start step by its ID and centers the canvas on it."""
        if not group_id:
            return

        # Find the index of the group_start step in the main data list
        target_index = -1
        for i, step_data in enumerate(self.added_steps_data):
            if step_data.get("type") == "group_start" and step_data.get("group_id") == group_id:
                target_index = i
                break
        
        if target_index != -1:
            # Use the existing robust centering method to do the work.
            # This will calculate the position and scroll the canvas.
            self._center_workflow_canvas_on_step(target_index)
            
            # This log message will now correctly fire after the centering action.
            self._log_to_console(f"Canvas centered on group '{group_id}'.")
        else:
            self._log_to_console(f"Warning: Could not find group_start with ID '{group_id}' to center on.")
            
# In main_app.py, add this new method to the MainWindow class

    def _handle_export_workflow_to_image(self):
        """
        Handles exporting the current workflow canvas to a PNG image file.
        """
        # 1. Check if there is a workflow to export
        if not hasattr(self, 'workflow_canvas') or not self.workflow_canvas.nodes:
            QMessageBox.information(self, "Nothing to Export", "The workflow canvas is empty.")
            return

        # 2. Suggest a default filename based on the current bot name
        bot_name = "Untitled Bot"
        if self.current_temp_file_path != self.default_temp_file_path:
            bot_name = os.path.splitext(os.path.basename(self.current_temp_file_path))[0]
        default_filename = os.path.join(os.path.expanduser("~"), "Downloads", f"{bot_name}_Workflow.png")

        # 3. Open the "Save File" dialog
        file_path, _ = QFileDialog.getSaveFileName(
            self,
            "Save Workflow Image",
            default_filename,
            "PNG Image (*.png);;JPEG Image (*.jpg)"
        )

        # 4. If the user selected a file path, proceed with saving
        if file_path:
            try:
                # 5. Call the new render method on the canvas
                pixmap = self.workflow_canvas.render_to_pixmap()

                # 6. Save the resulting QPixmap to the chosen file
                if pixmap.save(file_path):
                    self._log_to_console(f"Workflow successfully exported to: {file_path}")
                    QMessageBox.information(self, "Export Successful", f"Workflow image saved to:\n{file_path}")
                else:
                    raise IOError("Failed to save the image. Check file permissions or path.")

            except Exception as e:
                self._log_to_console(f"Error exporting workflow: {e}")
                QMessageBox.critical(self, "Export Error", f"Could not save the workflow image.\n\nError: {e}")
                
    def open_user_manual(self):
        """Constructs the path to the user manual and opens it in the default web browser."""
        try:
            # self.base_directory is already defined in your __init__ method
            manual_path = os.path.join(self.base_directory, "Help document", "index.html")

            if os.path.exists(manual_path):
                # The 'file://' prefix is important for ensuring it opens correctly as a local file
                webbrowser.open(f'file://{os.path.realpath(manual_path)}')
                self._log_to_console("Opening user manual...")
            else:
                error_message = f"User manual not found at the expected path: {manual_path}"
                self._log_to_console(f"ERROR: {error_message}")
                QMessageBox.warning(self, "File Not Found", error_message)
        except Exception as e:
            error_message = f"An unexpected error occurred while trying to open the user manual: {e}"
            self._log_to_console(f"CRITICAL: {error_message}")
            QMessageBox.critical(self, "Error", error_message)
if __name__ == "__main__":
    app = QApplication(sys.argv)
    
    # Apply a modern stylesheet
    app.setStyleSheet("""
        QMainWindow, QDialog {
            background-color: #f8f9fa;
        }
        QTabWidget::pane {
            border-top: 1px solid #dee2e6;
        }
        QTabBar::tab {
            background: #e9ecef;
            border: 1px solid #dee2e6;
            border-bottom-color: #dee2e6;
            border-top-left-radius: 4px;
            border-top-right-radius: 4px;
            min-width: 8ex;
            padding: 8px 12px;
            margin-right: 2px;
            font-size: 13px;
        }
        QTabBar::tab:selected, QTabBar::tab:hover {
            background: #ffffff;
        }
        QTabBar::tab:selected {
            border-color: #dee2e6;
            border-bottom-color: #ffffff;
        }
        QSplitter::handle {
            background: #ced4da;
        }
        QSplitter::handle:horizontal {
            width: 3px;
        }
        QSplitter::handle:vertical {
            height: 3px;
        }
        QGroupBox {
            font-weight: bold;
            border: 1px solid #ced4da;
            border-radius: 4px;
            margin-top: 1ex;
        }
        QGroupBox::title {
            subcontrol-origin: margin;
            subcontrol-position: top left;
            padding: 0 3px;
        }
        QTreeWidget {
            border: 1px solid #ced4da;
            background-color: #ffffff;
        }
        QListWidget {
            border: 1px solid #ced4da;
            background-color: #ffffff;
        }
        QLineEdit, QTextEdit, QComboBox {
            border: 1px solid #ced4da;
            border-radius: 4px;
            padding: 5px;
            background-color: #ffffff;
        }
        QPushButton {
            background-color: #007bff;
            color: white;
            border: none;
            padding: 8px 12px;
            border-radius: 4px;
            font-size: 13px;
        }
        QPushButton:hover {
            background-color: #0056b3;
        }
        QPushButton:pressed {
            background-color: #004085;
        }
        QPushButton:disabled {
            background-color: #c0c0c0;
            color: #6c757d;
        }
        QLabel#section-header {
            font-weight: bold;
            color: #343a40;
            padding: 4px 0;
            border-bottom: 1px solid #e0e0e0;
            margin-bottom: 4px;
        }
    """)
    
    window = MainWindow()
    window.show()
    sys.exit(app.exec())
