import pandas as pd
import clipboard
import os # Used for the example

class DataFrame:
    """
    A class to read and interact with Excel files using a pandas DataFrame.
    """
    
    def __init__(self):
        """
        Initializes the ExcelHelper.
        """
        df = None
        self.original_file_link = None
        self.original_sheetname = None

    def _check_df(self,df) -> bool:
        """Internal helper to check if a DataFrame is loaded."""
        if df is None:
            print("Error: No DataFrame loaded. Please call 'read_excel' first.")
            return False
        return True
        
    def _col_letter_to_index(self, letter: str) -> int:
            """
            Converts an Excel column letter (e.g., 'A', 'B', 'AA') to a 0-based index.
            """
            index = 0
            for char in letter.upper():
                if not 'A' <= char <= 'Z':
                    raise ValueError(f"Invalid column letter '{letter}'")
                index = index * 26 + (ord(char) - ord('A')) + 1
            return index - 1 # Adjust to 0-based index
            
    def put_range_to_clipboard(self, df,
                                 start_row: int, 
                                 end_row: int, 
                                 start_col_letter: str="A", 
                                 end_col_letter: str="A",
                                 index: bool = False,
                                 header: bool = False):
            """
            Copies a specified range of the DataFrame to the clipboard.
            Row indices are 0-based and [start_row:end_row] (exclusive of end_row).
            Column letters are 1-based (e.g., 'A', 'B') and inclusive.

            Args:
                start_row: The starting row index (0-based).
                end_row: The ending row index (exclusive).
                start_col_letter: The starting column letter (e.g., 'A').
                end_col_letter: The ending column letter (e.g., 'C'). Inclusive.
                index: Whether to include the DataFrame index in the clipboard.
                header: Whether to include the column headers in the clipboard.
            """
            if not self._check_df(df):
                return

            try:
                # Convert column letters to 0-based integer indices
                start_col_idx = self._col_letter_to_index(start_col_letter)
                end_col_idx = self._col_letter_to_index(end_col_letter)

                # Ensure start_col is not after end_col
                if start_col_idx > end_col_idx:
                    print(f"Error: Start column '{start_col_letter}' is after end column '{end_col_letter}'.")
                    return

                # Select the sub-dataframe using iloc
                # +1 on end_col_idx because Excel ranges are inclusive, 
                # but Python slicing is exclusive.
                sub_df = df.iloc[start_row:end_row, start_col_idx : end_col_idx + 1]
                
                # Use the built-in pandas to_clipboard method
                sub_df.to_clipboard(index=index, header=header)
                
                print(f"Copied range [rows {start_row}-{end_row-1}, cols {start_col_letter}-{end_col_letter}] to clipboard.")
            
            except (IndexError, ValueError) as e:
                print(f"Error: The specified range is invalid. Details: {e}")
            except Exception as e:
                print(f"An error occurred while copying to clipboard: {e}")

    def read_cell(self,df, row_idx: int, col_idx: int) -> any:
        """
        Reads the value of a single cell by its integer index.

        Args:
            row_idx: The row index (0-based).
            col_idx: The column index (0-based).

        Returns:
            The value of the cell, or None if an error occurs.
        """
        if not self._check_df(df):
            return None
        
        try:
            # .iat is the fastest way to access a single cell by integer location
            value = df.iat[row_idx, col_idx]
            return value
        except IndexError:
            print(f"Error: Cell at ({row_idx}, {col_idx}) is out of bounds.")
            return None

    def write_cell(self,df, row_idx: int, col_idx: int, value: any):
        """
        Writes a value to a single cell by its integer index.

        Args:
            row_idx: The row index (0-based).
            col_idx: The column index (0-based).
            value: The value to write to the cell.
        """
        if not self._check_df(df):
            return
            
        try:
            # .iat is the fastest way to write to a single cell by integer location
            df.iat[row_idx, col_idx] = value
            #print(f"Set cell ({row_idx}, {col_idx}) to '{value}'.")
            return df
        except IndexError:
            print(f"Error: Cell at ({row_idx}, {col_idx}) is out of bounds.")


            
    def save_excel(self, df, save_link: str = None, sheet_name: str = None, index: bool = False):
        """
        Saves the current DataFrame (self.df) to an Excel file.

        Args:
            save_path: The file path to save to. **If None, overwrites the
                       original file.**
            sheet_name: The sheet name to save to. **If None, uses the
                        original sheet name.**
            index: Whether to write the DataFrame's index as a column.
                   Defaults to False.
        """
        if not self._check_df():
            return

        # Determine save path
        path_to_save = save_link if save_link else self.original_file_link
        if not path_to_save:
            print("Error: No save path specified and no original file path available.")
            return

        # Determine sheet name
        sheet_to_save = sheet_name if sheet_name else self.original_sheetname
        if not sheet_to_save:
            sheet_to_save = 'Sheet1' # Default fallback

        try:
            self.df.to_excel(path_to_save, sheet_name=sheet_to_save, index=index)
            print(f"DataFrame successfully saved to '{path_to_save}' on sheet '{sheet_to_save}'.")
        except Exception as e:
            print(f"An error occurred while saving: {e}")

    # --- NEW METHOD ---
    def write_df_back_to_original(self, index: bool = False):
        """
        Saves the current DataFrame back to the original file and sheet.

        This is a convenience method that calls save_excel() with
        no 'save_path' or 'sheet_name', forcing it to use the
        original file details.

        Args:
            index: Whether to write the DataFrame's index as a column.
                   Defaults to False.
        """
        print("Attempting to save DataFrame back to original file...")
        # Calls save_excel with save_path=None and sheet_name=None
        self.save_excel(index=index)
        
    def filter_by_value(self,df, column_name: str, value_to_match: object) -> pd.DataFrame:
            """
            Filters the DataFrame to find rows where a specific column matches a given value.
            
            Args:
                column_name (str): The name of the column to filter.
                value_to_match (object): The value to match in the column.
            
            Returns:
                pd.DataFrame: A new DataFrame containing only the matching rows.
            """
            try:
                # This is the core filtering logic
                filtered_df = df[df[column_name] == value_to_match].copy()
                
                if filtered_df.empty:
                    print(f"Warning: No rows found where '{column_name}' == {value_to_match}")
                    
                return filtered_df.reset_index(drop=True)
            
            except KeyError:
                print(f"Error: Column '{column_name}' not found in the DataFrame.")
                return pd.DataFrame() # Return an empty DataFrame on error
            except Exception as e:
                print(f"An error occurred: {e}")
                return pd.DataFrame()
                
            
    def df_len(self, df) -> int:
        return len(df)

    def create_df_from_clipboard(self, header_str: str = None) -> pd.DataFrame:
        """
        Creates a DataFrame from the current system clipboard content.

        Args:
            header_str (str, optional): A string of column names separated by semicolons 
                                        (e.g., "Name;Age;Date"). 
                                        If provided, these will be used as headers and 
                                        the clipboard is assumed to contain data only.
                                        If None, the first line of the clipboard is used as the header.

        Returns:
            pd.DataFrame: The created DataFrame, or an empty DataFrame on failure.
        """
        try:
            # Get the current clipboard string to check if it's empty
            clip_text = clipboard.paste()
            if not clip_text or not clip_text.strip():
                print("Error: Clipboard is empty.")
                return pd.DataFrame()

            if header_str:
                # Case 1: User provided custom headers separated by semicolons
                # We treat the clipboard content as data only (header=None)
                headers = [h.strip() for h in header_str.split(';')]
                
                # We use sep='\t' as default for Excel copies, but allow pandas to infer if needed
                self.df = pd.read_clipboard(sep=None, names=headers, header=None, engine='python')
                print(f"DataFrame created from clipboard with custom headers: {headers}")
            else:
                # Case 2: No headers provided, infer from first line (default behavior)
                self.df = pd.read_clipboard(sep=None, engine='python')
                print("DataFrame created from clipboard (headers inferred from first line).")

            return self.df

        except Exception as e:
            print(f"An error occurred reading from clipboard: {e}")
            return pd.DataFrame()

    def remove_duplicates_df(self, df: pd.DataFrame, columns_str: str = None, keep: str = 'first') -> pd.DataFrame:
        """
        Removes duplicate rows from the DataFrame.

        Args:
            df (pd.DataFrame): The DataFrame to process.
            columns_str (str, optional): A semicolon-separated string of column names to base
                                         the deduplication on (e.g., "Name;Date").
                                         If None, all columns are used. Defaults to None.
            keep (str, optional): Which duplicate to keep. Can be 'first', 'last', or False
                                  (to drop all duplicates). Defaults to 'first'.

        Returns:
            pd.DataFrame: A new DataFrame with duplicates removed. Returns an empty DataFrame on error.
        """
        if not self._check_df(df):
            return pd.DataFrame()

        initial_rows = len(df)
        
        # Determine the subset of columns to check for duplicates
        subset_cols = None
        if columns_str:
            # Split the string by semicolon and strip whitespace from each column name
            subset_cols = [col.strip() for col in columns_str.split(';')]
            
            # Validate that all specified columns exist in the DataFrame
            missing_cols = [col for col in subset_cols if col not in df.columns]
            if missing_cols:
                #print(f"Error: The following columns were not found in the DataFrame: {missing_cols}")
                return df # Return original df on error

        try:
            # Use pandas' drop_duplicates method
            deduplicated_df = df.drop_duplicates(subset=subset_cols, keep=keep)
            
            final_rows = len(deduplicated_df)
            rows_removed = initial_rows - final_rows
            
            if subset_cols:
                pass
                #print(f"Removed {rows_removed} duplicate rows based on columns: {subset_cols}.")
            else:
                pass
                #print(f"Removed {rows_removed} duplicate rows based on all columns.")
            
            return deduplicated_df

        except Exception as e:
            print(f"An error occurred while removing duplicates: {e}")
            return df # Return original df on error

    def add_column_with_constant(self, df: pd.DataFrame, new_column_name: str, constant_value: any) -> pd.DataFrame:
        """
        Adds a new column to the DataFrame and fills it with a constant value.

        Args:
            df (pd.DataFrame): The DataFrame to modify.
            new_column_name (str): The name of the new column to be added.
            constant_value (any): The value to populate every row in the new column with.

        Returns:
            pd.DataFrame: The DataFrame with the new column added.
        """
        if not self._check_df(df):
            return df # Return original df on check failure

        if not new_column_name or not isinstance(new_column_name, str):
           
            print("Error: 'new_column_name' must be a non-empty string.")
            return df

        if new_column_name in df.columns:
            print(f"Warning: Column '{new_column_name}' already exists. It will be overwritten.")

        try:
            # Assign the constant value to the new column. Pandas handles broadcasting.
            df[new_column_name] = constant_value
            #print(f"Successfully added column '{new_column_name}' with constant value '{constant_value}'.")
            return df
        except Exception as e:
            print(f"An error occurred while adding the column: {e}")
            return df
    # --- END NEW METHOD ---