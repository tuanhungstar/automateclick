# File: Bot_module/Tessaract_OCR.py

import sys
from typing import Optional, List, Dict, Any
import pandas as pd
import os
from PIL import Image
import pytesseract

# --- PyQt6 Imports ---
from PyQt6.QtWidgets import (
    QDialog, QVBoxLayout, QFormLayout, QLineEdit, QPushButton, QDialogButtonBox,
    QComboBox, QWidget, QGroupBox, QMessageBox, QHBoxLayout, QRadioButton,
    QFileDialog
)
from PyQt6.QtCore import Qt, QThread, pyqtSignal

# --- Main App Imports (Fallback for standalone testing) ---
try:
    from my_lib.shared_context import ExecutionContext
except ImportError:
    print("Warning: Could not import main app libraries. Using fallbacks.")
    class ExecutionContext:
        def add_log(self, message: str): print(message)
        def get_variable(self, name: str):
            print(f"Fallback: Getting variable '{name}'")
            return None 
        # Added stub for future compatibility, although logic below is fixed to avoid relying on it
        def get_global_variables(self) -> List[str]: 
            return []

# --- Tesseract Extract Options (Subset of common options) ---
OCR_EXTRACTION_OPTIONS = {
    "Text (Default)": "string",
    "Data Frame (TSV/CSV)": "data",
    "Box Data": "box",
}

#
# --- HELPER: The GUI Dialog for Tesseract OCR Configuration ---
#
class _TessaractOCRDialog(QDialog):
    def __init__(self, global_variables: List[str], parent: Optional[QWidget] = None,
                 initial_config: Optional[Dict[str, Any]] = None,
                 initial_variable: Optional[str] = None):
        super().__init__(parent)
        self.setWindowTitle("Tesseract OCR Configuration")
        self.setMinimumWidth(650)
        self.global_variables = global_variables

        main_layout = QVBoxLayout(self)

        # 1. Tesseract Executable Path Configuration
        tesseract_group = QGroupBox("Tesseract Executable Path")
        tesseract_layout = QFormLayout(tesseract_group)
        
        self.tesseract_path_input = QLineEdit()
        self.tesseract_path_input.setPlaceholderText("Enter path or variable name (e.g., C:\\Program Files\\Tesseract-OCR\\tesseract.exe)")
        self.browse_tesseract_button = QPushButton("Browse")

        tess_path_layout = QHBoxLayout()
        tess_path_layout.addWidget(self.tesseract_path_input)
        tess_path_layout.addWidget(self.browse_tesseract_button)

        tesseract_layout.addRow("EXE Path (or Variable):", tess_path_layout)
        main_layout.addWidget(tesseract_group)

        # 2. Input File Configuration
        input_group = QGroupBox("Input File (Image or PDF)")
        input_layout = QFormLayout(input_group)
        self.file_input = QLineEdit()
        self.file_input.setPlaceholderText("Enter file path or global variable name")
        self.browse_file_button = QPushButton("Browse File...")

        file_path_layout = QHBoxLayout()
        file_path_layout.addWidget(self.file_input)
        file_path_layout.addWidget(self.browse_file_button)
        
        input_layout.addRow("File Path (or Variable):", file_path_layout)
        main_layout.addWidget(input_group)
        
        # 3. Extraction Options
        extract_group = QGroupBox("Extraction Options")
        extract_layout = QFormLayout(extract_group)
        self.extract_combo = QComboBox()
        self.extract_combo.addItems(OCR_EXTRACTION_OPTIONS.keys())
        self.language_input = QLineEdit("eng")
        self.language_input.setPlaceholderText("Tesseract language codes (e.g., eng, vie, eng+vie)")

        extract_layout.addRow("Extract Mode:", self.extract_combo)
        extract_layout.addRow("Language(s):", self.language_input)
        main_layout.addWidget(extract_group)

        # 4. Assign Results
        assign_group = QGroupBox("Assign Results to Variable")
        assign_layout = QFormLayout(assign_group)
        self.new_var_radio = QRadioButton("New Variable Name:"); self.new_var_input = QLineEdit("ocr_result_df")
        self.existing_var_radio = QRadioButton("Existing Variable:"); self.existing_var_combo = QComboBox()
        self.existing_var_combo.addItems(["-- Select --"] + self.global_variables)
        assign_layout.addRow(self.new_var_radio, self.new_var_input)
        assign_layout.addRow(self.existing_var_radio, self.existing_var_combo)
        self.new_var_radio.setChecked(True)
        main_layout.addWidget(assign_group)

        # Dialog Buttons
        self.button_box = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        main_layout.addWidget(self.button_box)

        # Connections
        self.browse_tesseract_button.clicked.connect(self._browse_for_tesseract_exe)
        self.browse_file_button.clicked.connect(self._browse_for_input_file)
        self.button_box.accepted.connect(self.accept)
        self.button_box.rejected.connect(self.reject)
        
        if initial_config: self._populate_from_initial_config(initial_config, initial_variable)

    def _browse_for_tesseract_exe(self):
        file_path, _ = QFileDialog.getOpenFileName(self, "Select Tesseract Executable", "", "Executables (*.exe);;All Files (*)")
        if file_path:
            self.tesseract_path_input.setText(file_path)
    
    def _browse_for_input_file(self):
        filters = "Image/PDF Files (*.jpg *.jpeg *.png *.pdf *.tiff);;All Files (*)"
        file_path, _ = QFileDialog.getOpenFileName(self, "Select Image or PDF File", "", filters)
        if file_path:
            self.file_input.setText(file_path)

    def _populate_from_initial_config(self, config, variable):
        self.tesseract_path_input.setText(config.get("tesseract_path", ""))
        self.file_input.setText(config.get("input_file", ""))
        self.extract_combo.setCurrentText(config.get("extract_mode", "Text (Default)"))
        self.language_input.setText(config.get("language", "eng"))

        # Assignment Config
        if variable:
            if variable in self.global_variables:
                self.existing_var_radio.setChecked(True); self.existing_var_combo.setCurrentText(variable)
            else:
                self.new_var_radio.setChecked(True); self.new_var_input.setText(variable)

    def get_executor_method_name(self) -> str: return "_execute_ocr"

    def get_assignment_variable(self) -> Optional[str]:
        if self.new_var_radio.isChecked():
            var_name = self.new_var_input.text().strip()
            if not var_name:
                QMessageBox.warning(self, "Input Error", "New variable name cannot be empty."); return None
            return var_name
        else:
            var_name = self.existing_var_combo.currentText()
            if var_name == "-- Select --":
                QMessageBox.warning(self, "Input Error", "Please select an existing variable."); return None
            return var_name

    def get_config_data(self) -> Optional[Dict[str, Any]]:
        tesseract_path = self.tesseract_path_input.text().strip()
        input_file = self.file_input.text().strip()

        if not tesseract_path:
            QMessageBox.warning(self, "Input Error", "Tesseract Executable Path is required."); return None
        if not input_file:
            QMessageBox.warning(self, "Input Error", "Input File Path is required."); return None
        
        return {
            "tesseract_path": tesseract_path,
            "input_file": input_file,
            "extract_mode": self.extract_combo.currentText(),
            "language": self.language_input.text().strip() or "eng",
        }

#
# --- The Public-Facing Module Class for Tesseract OCR ---
#
class Tessaract_OCR:
    """A module to perform Optical Character Recognition (OCR) using Tesseract."""
    def __init__(self, context: Optional[ExecutionContext] = None):
        self.context = context

    def _log(self, message: str):
        if self.context: self.context.add_log(message)
        else: print(message)

    def configure_data_hub(self, parent_window: QWidget, global_variables: List[str], **kwargs) -> QDialog:
        """Opens the configuration dialog for the Tesseract OCR tool."""
        self._log("Opening Tesseract OCR configuration...")
        return _TessaractOCRDialog(
            global_variables=global_variables,
            parent=parent_window,
            **kwargs
        )

    def _resolve_input(self, input_config: str, error_name: str) -> str:
        """Helper to check if input is a direct path or a global variable."""
        resolved_path = input_config
        
        # If the candidate path doesn't exist on the filesystem, try resolving it as a variable.
        if not os.path.exists(resolved_path):
            self._log(f"Attempting to resolve '{input_config}' as a variable...")
            # We assume if it's not a path, it is intended to be a variable name.
            var_value = self.context.get_variable(input_config)
            if var_value is not None and str(var_value).strip():
                resolved_path = str(var_value)
                self._log(f"{error_name} resolved from variable to: {resolved_path}")

        # Final check after resolution attempt
        if not resolved_path or not os.path.exists(resolved_path):
            raise FileNotFoundError(f"{error_name} not found. Path: {resolved_path}")
            
        return resolved_path

    def _execute_ocr(self, context: ExecutionContext, config_data: dict) -> pd.DataFrame:
        """
        Executes the Tesseract OCR process.
        """
        self.context = context
        tesseract_path_config = config_data["tesseract_path"]
        input_file_config = config_data["input_file"]
        extract_mode_key = config_data["extract_mode"]
        language = config_data["language"]
        
        ocr_result = None

        try:
            # 1. Resolve Tesseract Path (FIX APPLIED HERE)
            resolved_tess_path = self._resolve_input(tesseract_path_config, "Tesseract executable")

            # Set the Tesseract command path
            pytesseract.pytesseract.tesseract_cmd = resolved_tess_path
            self._log(f"Tesseract executable path set to: {resolved_tess_path}")

            # 2. Resolve Input File Path (FIX APPLIED HERE)
            resolved_input_file = self._resolve_input(input_file_config, "Input file")
            self._log(f"Processing input file: {resolved_input_file}")

            # 3. Determine Extraction Mode
            extract_mode = OCR_EXTRACTION_OPTIONS[extract_mode_key]

            # 4. Execute OCR
            if extract_mode == "string":
                # Returns a single string of all recognized text
                ocr_result = pytesseract.image_to_string(resolved_input_file, lang=language)
                
            elif extract_mode == "data":
                # Returns a pandas DataFrame containing recognized data (TSV structure)
                ocr_result = pytesseract.image_to_data(resolved_input_file, lang=language, output_type=pytesseract.Output.data_frame)
                
            elif extract_mode == "box":
                # Returns a pandas DataFrame containing box data (coordinates, text)
                box_data_str = pytesseract.image_to_boxes(resolved_input_file, lang=language)
                # Create a DataFrame from the box data string
                df_data = [line.split() for line in box_data_str.splitlines()]
                # Assuming the standard output format: char left bottom right top page
                ocr_result = pd.DataFrame(df_data, columns=['char', 'left', 'bottom', 'right', 'top', 'page'])
                
            else:
                raise ValueError(f"Unknown extraction mode: {extract_mode_key}")

            self._log(f"OCR execution successful with mode: {extract_mode_key}")

        except pytesseract.TesseractNotFoundError:
            raise RuntimeError(f"Tesseract executable not found. Check path: {resolved_tess_path}")
        except FileNotFoundError as e:
            raise RuntimeError(str(e))
        except Exception as e:
            error_message = f"FATAL ERROR during Tesseract OCR: {type(e).__name__}: {e}"
            self._log(error_message)
            raise RuntimeError(error_message)

        # 5. Format Output
        if isinstance(ocr_result, str):
            # If the result is a plain string, put it into a DataFrame for consistent output
            df = pd.DataFrame([ocr_result], columns=['Extracted_Text'])
        elif isinstance(ocr_result, pd.DataFrame):
            df = ocr_result
        else:
            df = pd.DataFrame([{"Error": "OCR result format unknown or unexpected."}])

        return df