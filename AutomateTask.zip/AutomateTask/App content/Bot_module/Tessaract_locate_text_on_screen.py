# File: Bot_module/Locate_text_on_screen.py

import sys
import os
import tempfile
import subprocess
import platform
from typing import Optional, List, Dict, Any
import pandas as pd
from PIL import Image, ImageGrab, ImageDraw
import pytesseract

# --- PyQt6 Imports ---
from PyQt6.QtWidgets import (
    QDialog, QVBoxLayout, QFormLayout, QLineEdit, QPushButton, QDialogButtonBox,
    QComboBox, QWidget, QGroupBox, QMessageBox, QHBoxLayout, QRadioButton,
    QFileDialog
)

# --- Main App Imports (Fallback) ---
try:
    from my_lib.shared_context import ExecutionContext
except ImportError:
    class ExecutionContext:
        def add_log(self, message: str): print(message)
        def get_variable(self, name: str): return None 
        def get_global_variables(self) -> List[str]: return []

#
# --- CONFIGURATION DIALOG (Runs on Main Thread - Safe) ---
#
class _LocateTextDialog(QDialog):
    def __init__(self, global_variables: List[str], parent: Optional[QWidget] = None,
                 initial_config: Optional[Dict[str, Any]] = None,
                 initial_variable: Optional[str] = None):
        super().__init__(parent)
        self.setWindowTitle("Locate Text Configuration")
        self.setMinimumWidth(600)
        self.global_variables = global_variables

        layout = QVBoxLayout(self)

        # 1. Tesseract Path
        tess_group = QGroupBox("Tesseract Executable")
        tess_layout = QHBoxLayout(tess_group)
        self.tess_path_input = QLineEdit()
        self.tess_path_input.setPlaceholderText("Path to tesseract.exe")
        browse_btn = QPushButton("Browse")
        browse_btn.clicked.connect(self._browse_tess)
        tess_layout.addWidget(self.tess_path_input)
        tess_layout.addWidget(browse_btn)
        layout.addWidget(tess_group)

        # 2. Target Text
        text_group = QGroupBox("Text to Find")
        text_layout = QFormLayout(text_group)
        self.text_input = QLineEdit()
        self.var_combo = QComboBox()
        self.var_combo.addItems(["-- Select Variable --"] + self.global_variables)
        self.var_combo.currentIndexChanged.connect(lambda: self.text_input.setText(self.var_combo.currentText()) if self.var_combo.currentIndex() > 0 else None)
        text_layout.addRow("Text:", self.text_input)
        text_layout.addRow("Variable:", self.var_combo)
        layout.addWidget(text_group)
        
        # 3. Settings
        set_group = QGroupBox("Settings")
        set_layout = QFormLayout(set_group)
        self.lang_input = QLineEdit("eng")
        # PSM 11 is critical for locating text scattered on a screen
        self.psm_input = QLineEdit("--psm 11") 
        set_layout.addRow("Language:", self.lang_input)
        set_layout.addRow("Config (PSM):", self.psm_input)
        layout.addWidget(set_group)

        # 4. Save Variable
        var_group = QGroupBox("Save Coordinates To")
        var_layout = QVBoxLayout(var_group)
        self.var_name_input = QLineEdit("text_location_df")
        var_layout.addWidget(self.var_name_input)
        layout.addWidget(var_group)

        # Buttons
        btns = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        btns.accepted.connect(self.accept)
        btns.rejected.connect(self.reject)
        layout.addWidget(btns)

        if initial_config:
            self.tess_path_input.setText(initial_config.get("tesseract_path", ""))
            self.text_input.setText(initial_config.get("target_text", ""))
            self.lang_input.setText(initial_config.get("language", "eng"))
            self.psm_input.setText(initial_config.get("tess_config", "--psm 11"))
        
        if initial_variable:
            self.var_name_input.setText(initial_variable)

    def _browse_tess(self):
        f, _ = QFileDialog.getOpenFileName(self, "Select Tesseract", "", "Exe (*.exe)")
        if f: self.tess_path_input.setText(f)

    def get_executor_method_name(self) -> str: return "_execute_locate"
    def get_assignment_variable(self) -> str: return self.var_name_input.text()
    
    def get_config_data(self) -> Dict[str, Any]:
        return {
            "tesseract_path": self.tess_path_input.text(),
            "target_text": self.text_input.text(),
            "language": self.lang_input.text(),
            "tess_config": self.psm_input.text()
        }

#
# --- EXECUTOR (Runs on Worker Thread - NO GUI WIDGETS ALLOWED) ---
#
class Locate_text_on_screen:
    def __init__(self, context: Optional[ExecutionContext] = None):
        self.context = context

    def _log(self, msg):
        if self.context: self.context.add_log(msg)
        else: print(msg)

    def configure_data_hub(self, parent_window: QWidget, global_variables: List[str], **kwargs) -> QDialog:
        return _LocateTextDialog(global_variables, parent_window, **kwargs)

    def _open_image_safe(self, image_path: str):
        """Opens image using system default viewer (Thread Safe)."""
        self._log(f"Opening result image: {image_path}")
        try:
            if platform.system() == "Windows":
                os.startfile(image_path)
            elif platform.system() == "Darwin":  # macOS
                subprocess.call(["open", image_path])
            else:  # Linux
                subprocess.call(["xdg-open", image_path])
        except Exception as e:
            self._log(f"Could not open image viewer: {e}")

    def _execute_locate(self, context: ExecutionContext, config: dict) -> pd.DataFrame:
        self.context = context
        tess_path = config["tesseract_path"]
        target_text = config["target_text"]
        
        # Resolve variables if needed
        if not os.path.exists(tess_path):
            val = self.context.get_variable(tess_path)
            if val: tess_path = str(val)
            
        val_text = self.context.get_variable(target_text)
        if val_text: target_text = str(val_text)

        pytesseract.pytesseract.tesseract_cmd = tess_path
        
        try:
            self._log("1. Taking screenshot...")
            screenshot = ImageGrab.grab()
            
            # Pre-processing (Scale x3 + Grayscale)
            self._log("2. Pre-processing image (Scale x3)...")
            w, h = screenshot.size
            # High-quality resize for better OCR
            processed = screenshot.resize((w * 3, h * 3), Image.Resampling.LANCZOS).convert('L')

            self._log(f"3. Running Tesseract (looking for '{target_text}')...")
            data = pytesseract.image_to_data(
                processed, 
                lang=config.get("language", "eng"), 
                config=config.get("tess_config", "--psm 11"), 
                output_type=pytesseract.Output.DICT
            )

            draw = ImageDraw.Draw(screenshot)
            results = []
            
            # Check results
            n_boxes = len(data['text'])
            for i in range(n_boxes):
                detected = data['text'][i].strip()
                if not detected: continue
                
                # Loose matching
                if target_text.lower() in detected.lower():
                    # Scale coordinates back down by 3
                    x = int(data['left'][i] / 3)
                    y = int(data['top'][i] / 3)
                    w = int(data['width'][i] / 3)
                    h = int(data['height'][i] / 3)
                    
                    draw.rectangle([x, y, x + w, y + h], outline="red", width=5)
                    results.append({"text": detected, "x": x, "y": y})
                    self._log(f"Found: {detected}")

            # --- THREAD SAFE DISPLAY ---
            # Save to temp file and open externally
            temp_dir = tempfile.gettempdir()
            temp_path = os.path.join(temp_dir, "ocr_debug_result.png")
            screenshot.save(temp_path)
            
            if not results:
                self._log("Text not found. Opening screenshot to verify what was seen.")
            else:
                self._log(f"Found {len(results)} matches. Opening result...")
                
            self._open_image_safe(temp_path)
            # ---------------------------

            return pd.DataFrame(results) if results else pd.DataFrame([{"error": "Not Found"}])

        except Exception as e:
            self._log(f"Error: {e}")
            raise RuntimeError(str(e))